<?php


if (!function_exists('rx_host_profile_cache_path')) {
    function rx_host_profile_cache_path()
    {
        $root = defined('REFACTORED_LEGACY_ROOT') ? REFACTORED_LEGACY_ROOT
              : (defined('APP_ROOT_PATH') ? APP_ROOT_PATH : dirname(__DIR__, 3));
        $cronbot = $root . DIRECTORY_SEPARATOR . 'cronbot';
        $runtime = $cronbot . DIRECTORY_SEPARATOR . '.runtime';
        if (@is_dir($runtime) || @mkdir($runtime, 0775, true) || @is_dir($runtime)) {
            return $runtime . DIRECTORY_SEPARATOR . 'host_profile.json';
        }
        if (@is_dir($cronbot)) {
            return $cronbot . DIRECTORY_SEPARATOR . 'host_profile.json';
        }
        return sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'rx_host_profile_' . md5((string) $root) . '.json';
    }
}

if (!function_exists('rx_exec_disabled')) {
    function rx_exec_disabled()
    {
        foreach (['exec', 'shell_exec'] as $fn) {
            if (!function_exists($fn)) {
                return true;
            }
        }
        $disabled = strtolower((string) ini_get('disable_functions'));
        if ($disabled === '') {
            return false;
        }
        foreach (['exec', 'shell_exec'] as $fn) {
            if (preg_match('/(^|,)\s*' . $fn . '\s*(,|$)/', $disabled)) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('rx_putenv_disabled')) {
    function rx_putenv_disabled()
    {
        if (!function_exists('putenv')) {
            return true;
        }
        $disabled = strtolower((string) ini_get('disable_functions'));
        if ($disabled === '') {
            return false;
        }
        return (bool) preg_match('/(^|,)\s*putenv\s*(,|$)/', $disabled);
    }
}

if (!function_exists('rx_mysql_show_value')) {
    function rx_mysql_show_value($pdo, $kind, $name)
    {
        try {
            if (!($pdo instanceof PDO)) {
                return 0;
            }
            $kind = ($kind === 'STATUS') ? 'STATUS' : 'VARIABLES';
            $name = preg_replace('/[^A-Za-z0-9_]/', '', (string) $name);
            if ($name === '') {
                return 0;
            }
            $stmt = $pdo->query("SHOW {$kind} LIKE '{$name}'");
            if ($stmt === false) {
                return 0;
            }
            $row = $stmt->fetch(PDO::FETCH_NUM);
            return (is_array($row) && isset($row[1])) ? $row[1] : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }
}

if (!function_exists('rx_resize_for_profile')) {
    function rx_resize_for_profile($maxConnections, $profile)
    {
        $maxConnections = (int) $maxConnections;
        if ($profile === 'vps') {
            return [
                'cron_db_budget'    => ($maxConnections > 0) ? max(20, (int) floor($maxConnections * 0.20)) : 20,
                'cron_time_budget'  => 120,
                'broadcast_workers' => 4,
                'payment_workers'   => 4,
            ];
        }
        return [
            'cron_db_budget'    => ($maxConnections > 0) ? max(4, min(8, (int) floor($maxConnections * 0.06))) : 6,
            'cron_time_budget'  => 22,
            'broadcast_workers' => 1,
            'payment_workers'   => 1,
        ];
    }
}

if (!function_exists('rx_detect_host_profile')) {
    function rx_detect_host_profile()
    {
        $maxConn = 0;
        $maxUsed = 0;
        $maxUser = -1;
        try {
            $pdo = function_exists('getDatabaseConnection') ? getDatabaseConnection() : ($GLOBALS['pdo'] ?? null);
            if ($pdo instanceof PDO) {
                $maxConn = (int) rx_mysql_show_value($pdo, 'VARIABLES', 'max_connections');
                $maxUser = (int) rx_mysql_show_value($pdo, 'VARIABLES', 'max_user_connections');
                $maxUsed = (int) rx_mysql_show_value($pdo, 'STATUS', 'Max_used_connections');
            }
        } catch (\Throwable $e) {
        }

        $execDisabled = rx_exec_disabled();
        $cpanel       = @is_dir('/usr/local/cpanel');

        $isShared = $cpanel
            || $execDisabled
            || ($maxUser > 0 && $maxUser <= 50);
        $profile = $isShared ? 'shared' : 'vps';

        return array_merge([
            'profile'              => $profile,
            'max_connections'      => $maxConn,
            'max_used_connections' => $maxUsed,
            'max_user_connections' => $maxUser,
            'exec_disabled'        => $execDisabled ? 1 : 0,
            'cpanel'               => $cpanel ? 1 : 0,
            'detected_at'          => time(),
        ], rx_resize_for_profile($maxConn, $profile));
    }
}

if (!function_exists('rx_host_profile')) {
    function rx_host_profile()
    {
        static $cache = null;
        if (is_array($cache)) {
            return $cache;
        }

        $path     = rx_host_profile_cache_path();
        $resolved = null;

        if ($path !== '' && @is_file($path)) {
            $age = time() - (int) @filemtime($path);
            if ($age >= 0 && $age < 604800) {
                $raw     = @file_get_contents($path);
                $decoded = ($raw !== false) ? json_decode($raw, true) : null;
                if (is_array($decoded) && isset($decoded['profile'])) {
                    $resolved = $decoded;
                }
            }
        }

        if ($resolved === null) {
            try {
                $resolved = rx_detect_host_profile();
            } catch (\Throwable $e) {
                $resolved = array_merge(['profile' => 'shared', 'max_connections' => 0], rx_resize_for_profile(0, 'shared'));
            }
        }

        try {
            $s = function_exists('select') ? select('setting', '*') : null;
            if (is_array($s)) {
                $override = isset($s['host_profile']) ? strtolower(trim((string) $s['host_profile'])) : '';
                if (($override === 'shared' || $override === 'vps') && $override !== ($resolved['profile'] ?? '')) {
                    $resolved = array_merge($resolved, ['profile' => $override], rx_resize_for_profile((int) ($resolved['max_connections'] ?? 0), $override));
                }
                if (isset($s['cron_db_budget']) && (int) $s['cron_db_budget'] > 0) {
                    $resolved['cron_db_budget'] = (int) $s['cron_db_budget'];
                }
                if (isset($s['cron_time_budget']) && (int) $s['cron_time_budget'] > 0) {
                    $resolved['cron_time_budget'] = (int) $s['cron_time_budget'];
                }
            }
        } catch (\Throwable $e) {
        }

        if ($path !== '') {
            $new     = json_encode($resolved, JSON_UNESCAPED_UNICODE);
            $current = (@is_file($path)) ? (string) @file_get_contents($path) : '';
            if ($new !== false && $new !== $current) {
                @file_put_contents($path, $new, LOCK_EX);
            }
        }

        $cache = $resolved;
        return $cache;
    }
}

if (!function_exists('rx_cron_db_budget')) {
    function rx_cron_db_budget()
    {
        $p = rx_host_profile();
        return max(1, (int) ($p['cron_db_budget'] ?? 6));
    }
}

if (!function_exists('rx_cron_time_budget')) {
    function rx_cron_time_budget()
    {
        $p = rx_host_profile();
        return max(5, (int) ($p['cron_time_budget'] ?? 22));
    }
}

if (!function_exists('rx_release_unpaid_discount')) {

    function rx_release_unpaid_discount($userId, $discountCode = null, $referenceTime = null) {
        global $pdo;
        $userId = trim((string)$userId);
        if ($userId === '' || !isset($pdo)) return false;
        try {
            if ($referenceTime !== null && (int)$referenceTime > 0) {
                $low = (string)((int)$referenceTime - 900);
                $high = (string)((int)$referenceTime + 900);
            } else {
                $low = (string)(time() - 1800);
                $high = (string)(time() + 60);
            }
            $params = [':u' => $userId, ':lo' => $low, ':hi' => $high];
            $codeClause = '';
            if ($discountCode !== null && trim((string)$discountCode) !== '') {
                $codeClause = ' AND code = :c';
                $params[':c'] = trim((string)$discountCode);
            }
            $stmt = $pdo->prepare(
                "SELECT id, code FROM Giftcodeconsumed
                  WHERE id_user = :u
                    AND kind = 'sell'
                    AND (released IS NULL OR released = 0)
                    AND consumed_at <> ''
                    AND CAST(consumed_at AS UNSIGNED) BETWEEN :lo AND :hi" . $codeClause . "
                  ORDER BY id DESC LIMIT 1"
            );
            $stmt->execute($params);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!is_array($row) || empty($row['code'])) return false;

            $code = (string)$row['code'];
            $rowId = (int)$row['id'];

            $marked = $pdo->prepare('UPDATE Giftcodeconsumed SET released = 1 WHERE id = :id AND (released IS NULL OR released = 0)');
            $marked->execute([':id' => $rowId]);
            if ($marked->rowCount() < 1) return false;

            $ds = $pdo->prepare('SELECT usedDiscount FROM DiscountSell WHERE codeDiscount = :c LIMIT 1');
            $ds->execute([':c' => $code]);
            $dsRow = $ds->fetch(PDO::FETCH_ASSOC);
            if (is_array($dsRow)) {
                $used = (int)($dsRow['usedDiscount'] ?? 0) - 1;
                if ($used < 0) $used = 0;
                $pdo->prepare('UPDATE DiscountSell SET usedDiscount = :v WHERE codeDiscount = :c')
                    ->execute([':v' => (string)$used, ':c' => $code]);
            }
            return true;
        } catch (Throwable $e) {
            return false;
        }
    }
}


if (!function_exists('balance_atomic_charge')) {

    function balance_atomic_charge($userId, $delta, $allowNegativeUpTo = 0) {
        global $pdo;
        $delta = (float) $delta;
        if ($delta <= 0) return ['ok' => false, 'reason' => 'invalid-delta', 'new_balance' => null];
        $allowNegativeUpTo = max(0.0, (float) $allowNegativeUpTo);


        $minBalance = $delta - $allowNegativeUpTo;
        try {
            $stmt = $pdo->prepare("UPDATE user SET Balance = Balance - :d WHERE id = :u AND Balance >= :m");
            $stmt->execute([':d' => $delta, ':u' => $userId, ':m' => $minBalance]);
            if ($stmt->rowCount() < 1) {
                return ['ok' => false, 'reason' => 'insufficient-or-stale', 'new_balance' => null];
            }
            if (function_exists('clearSelectCacheRow')) {
                clearSelectCacheRow('user', 'id', $userId);
            }
            $sel = $pdo->prepare("SELECT Balance FROM user WHERE id = :u");
            $sel->execute([':u' => $userId]);
            $newBal = $sel->fetchColumn();
            return ['ok' => true, 'reason' => 'charged', 'new_balance' => (float) $newBal];
        } catch (Throwable $e) {
            error_log('balance_atomic_charge failed: ' . $e->getMessage());
            return ['ok' => false, 'reason' => 'db-error', 'new_balance' => null];
        }
    }
}


if (!function_exists('nm_validateSellDiscount')) {
    function nm_validateSellDiscount($code, $section, $codeProduct, $codePanel, $user, $from_id)
    {
        global $pdo;
        $code = trim((string)$code);
        $sections = ['buy', 'extend', 'volume', 'time', 'charge', 'all'];
        $section = in_array($section, $sections, true) ? $section : 'all';
        $res = ['ok' => false, 'reason' => '', 'row' => null, 'value_type' => 'percent', 'value' => 0.0, 'label' => ''];

        if ($code === '') {
            $res['reason'] = '❌ کد تخفیف را وارد کنید.';
            return $res;
        }

        if ($section !== 'charge' && intval($user['pricediscount'] ?? 0) != 0) {
            $res['reason'] = faoxima_textbot_get('dyn_errors_exclusive_discount_conflict', '❌ شما تخفیف اختصاصی دارید و امکان استفاده از کد تخفیف وجود ندارد.');
            return $res;
        }

        $agent       = (string)($user['agent'] ?? 'f');
        $codeProduct = ($codeProduct === '' || $codeProduct === null) ? 'all' : $codeProduct;
        $codePanel   = ($codePanel === '' || $codePanel === null) ? '/all' : $codePanel;

        try {
            $stmt = $pdo->prepare(
                "SELECT * FROM DiscountSell
                  WHERE codeDiscount = :code
                    AND (code_product = :cp OR code_product = 'all')
                    AND (code_panel = :cpan OR code_panel = '/all')
                    AND (agent = :agent OR agent = 'allusers' OR agent = 'all')
                    AND (COALESCE(NULLIF(section, ''), type, 'all') = :section
                         OR COALESCE(NULLIF(section, ''), type, 'all') = 'all')
                    AND (status IS NULL OR status = '' OR status = 'active')
                    AND (target_user IS NULL OR target_user = '' OR target_user = :uid)
                  LIMIT 1"
            );
            $stmt->execute([
                ':code'   => $code,
                ':cp'     => $codeProduct,
                ':cpan'   => $codePanel,
                ':agent'  => $agent,
                ':section' => $section,
                ':uid'    => (string)$from_id,
            ]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            error_log('nm_validateSellDiscount query failed: ' . $e->getMessage());
            $res['reason'] = '❌ خطا در بررسی کد تخفیف.';
            return $res;
        }

        if (!$row) {
            $res['reason'] = '❌ کد تخفیف نامعتبر است یا برای این بخش فعال نیست.';
            return $res;
        }

        if (intval($row['time']) != 0 && time() >= intval($row['time'])) {
            $res['reason'] = faoxima_textbot_get('dyn_errors_discount_expired', '❌ زمان کد تخفیف به پایان رسیده است.');
            return $res;
        }

        if (intval($row['limitDiscount']) > 0 && intval($row['usedDiscount']) >= intval($row['limitDiscount'])) {
            $res['reason'] = '❌ ظرفیت استفاده از این کد تخفیف به پایان رسیده است.';
            return $res;
        }

        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM Giftcodeconsumed WHERE id_user = :u AND code = :c");
            $stmt->execute([':u' => (string)$from_id, ':c' => $code]);
            $usedByUser = (int)$stmt->fetchColumn();
        } catch (Throwable $e) {
            $usedByUser = 0;
        }
        $useUser = intval($row['useuser']);
        if ($useUser > 0 && $usedByUser >= $useUser) {
            $res['reason'] = '⭕️ سقف استفاده شما از این کد تخفیف پر شده است.';
            return $res;
        }

        if ((string)($row['usefirst'] ?? '') === '1') {
            $invoiceCount = MiniDiscount::completedPurchaseCount((string)$from_id);
            if (intval($invoiceCount) != 0) {
                $res['reason'] = '❌ این کد تخفیف فقط برای اولین خرید قابل استفاده است.';
                return $res;
            }
        }

        $vt = strtolower(trim((string)($row['value_type'] ?? '')));
        if (!in_array($vt, ['percent', 'amount', 'free'], true)) {
            $tcol = strtolower(trim((string)($row['type'] ?? '')));
            $vt = in_array($tcol, ['percent', 'amount', 'free'], true) ? $tcol : 'percent';
        }
        $val = (float)$row['price'];
        if ($vt === 'percent' && ($val <= 0 || $val > 100)) {
            $res['reason'] = '❌ درصد کد تخفیف نامعتبر است.';
            return $res;
        }
        if ($vt === 'amount' && $val <= 0) {
            $res['reason'] = '❌ مبلغ کد تخفیف نامعتبر است.';
            return $res;
        }

        $label = $vt === 'free'
            ? 'رایگان'
            : ($vt === 'amount' ? number_format($val) . ' تومان' : (string)$row['price'] . ' درصد');

        $res['ok']         = true;
        $res['row']        = $row;
        $res['value_type'] = $vt;
        $res['value']      = $val;
        $res['label']      = $label;
        return $res;
    }
}

if (!function_exists('nm_applySellDiscountToPrice')) {
    function nm_applySellDiscountToPrice($row, $price)
    {
        $price = (float)$price;
        $vt = strtolower(trim((string)($row['value_type'] ?? '')));
        if (!in_array($vt, ['percent', 'amount', 'free'], true)) {
            $tcol = strtolower(trim((string)($row['type'] ?? '')));
            $vt = in_array($tcol, ['percent', 'amount', 'free'], true) ? $tcol : 'percent';
        }
        $val = (float)($row['price'] ?? 0);
        if ($vt === 'free')   return 0.0;
        if ($vt === 'amount') return max(0.0, $price - $val);
        return max(0.0, $price - ($price * $val / 100));
    }
}

if (!function_exists('nm_markSellDiscountUsed')) {
    function nm_markSellDiscountUsed($code, $from_id, $username = '', $reportContext = '')
    {
        global $connect, $setting, $otherreport;
        $code = trim((string)$code);
        if ($code === '') return;

        try {
            $row = select("DiscountSell", "*", "codeDiscount", $code, "select");
            if ($row != false) {
                $value = intval($row['usedDiscount']) + 1;
                update("DiscountSell", "usedDiscount", $value, "codeDiscount", $code);
            }
        } catch (Throwable $e) {
            error_log('nm_markSellDiscountUsed update failed: ' . $e->getMessage());
        }

        try {
            $now  = (string)time();
            $kind = 'sell';
            $stmt = $connect->prepare("INSERT INTO Giftcodeconsumed (id_user, code, kind, consumed_at) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $from_id, $code, $kind, $now);
            $stmt->execute();
            $stmt->close();
        } catch (Throwable $e) {
            try {
                $stmt = $connect->prepare("INSERT INTO Giftcodeconsumed (id_user, code) VALUES (?, ?)");
                $stmt->bind_param("ss", $from_id, $code);
                $stmt->execute();
                $stmt->close();
            } catch (Throwable $e2) {
            }
        }

        if (isset($setting['Channel_Report']) && strlen((string)$setting['Channel_Report']) > 0) {
            $uname = $username !== '' ? "@{$username} " : '';
            $ctx   = $reportContext !== '' ? " (بخش: {$reportContext})" : '';
            $text_report = "⭕️ کاربر {$uname}با آیدی عددی {$from_id} از کد تخفیف {$code}{$ctx} استفاده کرد.";
            telegram('sendmessage', [
                'chat_id' => $setting['Channel_Report'],
                'message_thread_id' => $otherreport ?? null,
                'text' => $text_report,
                'parse_mode' => "HTML",
            ]);
        }
    }
}

if (!function_exists('nm_pending_charge_bonus')) {
    function nm_pending_charge_bonus($user)
    {
        $pv4 = (string)($user['Processing_value_four'] ?? '');
        if (strpos($pv4, 'chg|') !== 0) return 0;
        $parts = explode('|', $pv4);
        $bonus = isset($parts[1]) ? intval($parts[1]) : 0;
        return max(0, $bonus);
    }
}

if (!function_exists('balance_atomic_credit')) {

    function balance_atomic_credit($userId, $delta) {
        global $pdo;
        if (!is_numeric($delta)) return false;
        $delta = (float) $delta;
        if (!is_finite($delta) || $delta <= 0) return false;
        if ($userId === null || trim((string) $userId) === '') return false;
        if (!($pdo instanceof PDO)) return false;
        try {
            $stmt = $pdo->prepare("UPDATE user SET Balance = Balance + :d WHERE id = :u");
            $stmt->execute([':d' => $delta, ':u' => $userId]);
            if ($stmt->rowCount() < 1) {
                error_log('balance_atomic_credit: no row updated for user ' . $userId);
                return false;
            }
            if (function_exists('clearSelectCacheRow')) {
                clearSelectCacheRow('user', 'id', $userId);
            }
            return true;
        } catch (Throwable $e) {
            error_log('balance_atomic_credit failed: ' . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('wallet_ledger_record')) {

    function wallet_ledger_record($userId, string $direction, $amount, string $category, ?string $description = null, ?string $idOrder = null, ?string $refTable = null, ?string $refId = null): bool {
        global $pdo;
        $amount = (int) round((float) $amount);
        if ($amount <= 0 || !in_array($direction, ['credit', 'debit'], true)) return false;
        try {
            $balanceAfter = null;
            $sel = $pdo->prepare("SELECT Balance FROM user WHERE id = :u");
            $sel->execute([':u' => $userId]);
            $bal = $sel->fetchColumn();
            if ($bal !== false) {
                $balanceAfter = (int) $bal;
            }
            $stmt = $pdo->prepare(
                "INSERT INTO wallet_ledger (id_user, direction, amount, balance_after, category, description, id_order, ref_table, ref_id) "
                . "VALUES (:id_user, :direction, :amount, :balance_after, :category, :description, :id_order, :ref_table, :ref_id)"
            );
            $stmt->execute([
                ':id_user' => $userId,
                ':direction' => $direction,
                ':amount' => $amount,
                ':balance_after' => $balanceAfter,
                ':category' => $category,
                ':description' => $description,
                ':id_order' => $idOrder,
                ':ref_table' => $refTable,
                ':ref_id' => $refId,
            ]);
            return true;
        } catch (Throwable $e) {
            error_log('wallet_ledger_record failed: ' . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('rx_refund_payment_once')) {

    function rx_refund_payment_once($orderId, $userId, $amount, string $description, $invoiceId = null): string
    {
        global $pdo;
        $amount = is_numeric($amount) ? (int) round((float) $amount) : 0;
        $orderId = (string) $orderId;
        $userId = (string) $userId;
        if (!($pdo instanceof PDO) || $amount <= 0 || $orderId === '' || $userId === '') {
            if (function_exists('rx_log_event')) {
                rx_log_event('REFUND_REJECTED', 'invalid refund input', ['id_order' => $orderId, 'id_user' => $userId, 'amount' => $amount]);
            }
            return 'failed';
        }
        $invoiceId = ($invoiceId === null || (string) $invoiceId === '') ? null : (string) $invoiceId;
        $ownTx = !$pdo->inTransaction();
        try {
            if ($ownTx) {
                $pdo->beginTransaction();
            }
            $note = '[auto-refund: ' . $description . ' at ' . date('Y-m-d H:i:s') . ']';
            $claim = $pdo->prepare(
                "UPDATE Payment_report SET direct_payment_done = 1, "
                . "dec_not_confirmed = CASE WHEN dec_not_confirmed IS NULL OR dec_not_confirmed = '' THEN :n1 ELSE CONCAT(dec_not_confirmed, ' | ', :n2) END "
                . "WHERE id_order = :o AND (direct_payment_done IS NULL OR direct_payment_done = 0) "
                . "AND (dec_not_confirmed IS NULL OR dec_not_confirmed NOT LIKE '%auto-refund%')"
            );
            $claim->execute([':n1' => $note, ':n2' => $note, ':o' => $orderId]);
            if ($claim->rowCount() < 1) {
                if ($ownTx) {
                    $pdo->rollBack();
                }
                if (function_exists('rx_log_event')) {
                    rx_log_event('REFUND_DUPLICATE_SKIPPED', 'refund already applied or payment already fulfilled', ['id_order' => $orderId, 'id_user' => $userId]);
                }
                return 'duplicate';
            }
            if (!balance_atomic_credit($userId, $amount)) {
                throw new RuntimeException('balance_atomic_credit returned false');
            }
            if (!function_exists('wallet_ledger_record')
                || !wallet_ledger_record($userId, 'credit', $amount, 'refund', $description, $orderId, $invoiceId !== null ? 'invoice' : 'Payment_report', $invoiceId ?? $orderId)) {
                throw new RuntimeException('wallet_ledger_record failed');
            }
            if ($ownTx) {
                $pdo->commit();
            }
            if (function_exists('clearSelectCache')) {
                clearSelectCache('Payment_report');
            }
            if (function_exists('rx_log_event')) {
                rx_log_event('REFUND_APPLIED', $description, ['id_order' => $orderId, 'id_user' => $userId, 'amount' => $amount, 'id_invoice' => $invoiceId]);
            }
            return 'refunded';
        } catch (Throwable $e) {
            if ($ownTx && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('rx_refund_payment_once failed for ' . $orderId . ': ' . $e->getMessage());
            if (function_exists('rx_log_event')) {
                rx_log_event('REFUND_FAILED', $e->getMessage(), ['id_order' => $orderId, 'id_user' => $userId, 'amount' => $amount, 'id_invoice' => $invoiceId]);
            }
            return 'failed';
        }
    }
}

if (!function_exists('rx_refund_invoice_once')) {

    function rx_refund_invoice_once(string $invoiceId, string $claimSql, array $claimParams, $userId, $amount, string $description): string
    {
        global $pdo;
        $amount = is_numeric($amount) ? (int) round((float) $amount) : -1;
        $userId = (string) $userId;
        if (!($pdo instanceof PDO) || $invoiceId === '' || $userId === '' || $amount < 0) {
            return 'failed';
        }
        $ownTx = !$pdo->inTransaction();
        try {
            if ($ownTx) {
                $pdo->beginTransaction();
            }
            $claim = $pdo->prepare($claimSql);
            $claim->execute($claimParams);
            if ($claim->rowCount() < 1) {
                if ($ownTx) {
                    $pdo->rollBack();
                }
                return 'claimed';
            }
            if ($amount > 0) {
                if (!balance_atomic_credit($userId, $amount)) {
                    throw new RuntimeException('balance_atomic_credit returned false');
                }
                if (!function_exists('wallet_ledger_record')
                    || !wallet_ledger_record($userId, 'credit', $amount, 'refund', $description, null, 'invoice', $invoiceId)) {
                    throw new RuntimeException('wallet_ledger_record failed');
                }
            }
            if ($ownTx) {
                $pdo->commit();
            }
            if (function_exists('clearSelectCacheRow')) {
                clearSelectCacheRow('invoice', 'id_invoice', $invoiceId);
            }
            if (function_exists('rx_log_event')) {
                rx_log_event('REFUND_APPLIED', $description, ['id_invoice' => $invoiceId, 'id_user' => $userId, 'amount' => $amount]);
            }
            return 'refunded';
        } catch (Throwable $e) {
            if ($ownTx && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('rx_refund_invoice_once failed for ' . $invoiceId . ': ' . $e->getMessage());
            if (function_exists('rx_log_event')) {
                rx_log_event('REFUND_FAILED', $e->getMessage(), ['id_invoice' => $invoiceId, 'id_user' => $userId, 'amount' => $amount]);
            }
            return 'failed';
        }
    }
}

if (!function_exists('rx_cashback_credit_once')) {

    function rx_cashback_credit_once($orderId, $userId, $amount, string $cashbackKey, string $description): string
    {
        global $pdo;
        $amount = is_numeric($amount) ? (int) floor((float) $amount) : 0;
        $orderId = (string) $orderId;
        $userId = (string) $userId;
        if ($amount <= 0) {
            return 'skipped';
        }
        if (!($pdo instanceof PDO) || $orderId === '' || $userId === '' || $cashbackKey === '') {
            return 'failed';
        }
        $ownTx = !$pdo->inTransaction();
        try {
            if ($ownTx) {
                $pdo->beginTransaction();
            }
            $lockSql = "SELECT id_user, direct_payment_done FROM Payment_report WHERE id_order = :o";
            if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql') {
                $lockSql .= " FOR UPDATE";
            }
            $lock = $pdo->prepare($lockSql);
            $lock->execute([':o' => $orderId]);
            $payment = $lock->fetch(PDO::FETCH_ASSOC);
            if (!is_array($payment) || (int) ($payment['direct_payment_done'] ?? 0) !== 1 || (string) ($payment['id_user'] ?? '') !== $userId) {
                if ($ownTx) {
                    $pdo->rollBack();
                }
                if (function_exists('rx_log_event')) {
                    rx_log_event('CASHBACK_SKIPPED', 'payment not fulfilled or owner mismatch', ['id_order' => $orderId, 'id_user' => $userId, 'key' => $cashbackKey]);
                }
                return 'skipped';
            }
            $dup = $pdo->prepare("SELECT COUNT(*) FROM wallet_ledger WHERE id_order = :o AND category = 'cashback' AND ref_table = 'cashback' AND ref_id = :k");
            $dup->execute([':o' => $orderId, ':k' => $cashbackKey]);
            if ((int) $dup->fetchColumn() > 0) {
                if ($ownTx) {
                    $pdo->rollBack();
                }
                if (function_exists('rx_log_event')) {
                    rx_log_event('CASHBACK_DUPLICATE_SKIPPED', 'cashback already paid', ['id_order' => $orderId, 'id_user' => $userId, 'key' => $cashbackKey]);
                }
                return 'duplicate';
            }
            if (!balance_atomic_credit($userId, $amount)) {
                throw new RuntimeException('balance_atomic_credit returned false');
            }
            if (!function_exists('wallet_ledger_record')
                || !wallet_ledger_record($userId, 'credit', $amount, 'cashback', $description, $orderId, 'cashback', $cashbackKey)) {
                throw new RuntimeException('wallet_ledger_record failed');
            }
            if ($ownTx) {
                $pdo->commit();
            }
            return 'credited';
        } catch (Throwable $e) {
            if ($ownTx && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('rx_cashback_credit_once failed for ' . $orderId . ': ' . $e->getMessage());
            if (function_exists('rx_log_event')) {
                rx_log_event('CASHBACK_FAILED', $e->getMessage(), ['id_order' => $orderId, 'id_user' => $userId, 'amount' => $amount, 'key' => $cashbackKey]);
            }
            return 'failed';
        }
    }
}

if (!function_exists('rx_bulk_gift_state_path')) {

    function rx_bulk_gift_state_path(string $batchId): string
    {
        $root = defined('REFACTORED_LEGACY_ROOT') ? REFACTORED_LEGACY_ROOT : getcwd();
        return rtrim((string) $root, '/\\') . '/cronbot/bulk_gift_' . preg_replace('/[^a-f0-9]/', '', $batchId) . '.json';
    }
}

if (!function_exists('rx_bulk_gift_save')) {

    function rx_bulk_gift_save(string $path, array $state): bool
    {
        $tmp = $path . '.' . getmypid() . '.tmp';
        if (@file_put_contents($tmp, json_encode($state, JSON_UNESCAPED_UNICODE), LOCK_EX) === false) {
            return false;
        }
        if (!@rename($tmp, $path)) {
            @unlink($tmp);
            return false;
        }
        return true;
    }
}

if (!function_exists('rx_bulk_gift_chunk')) {

    function rx_bulk_gift_chunk(PDO $pdo, string $batchId, int $amount, array $chunk, string $description): array
    {
        $out = ['credited' => 0, 'already' => 0, 'missing' => 0, 'failed' => []];
        if (empty($chunk)) {
            return $out;
        }
        $ph = implode(',', array_fill(0, count($chunk), '?'));
        try {
            $pdo->beginTransaction();
            $doneStmt = $pdo->prepare("SELECT id_user FROM wallet_ledger WHERE id_order = ? AND category = 'admin_gift' AND id_user IN ($ph)");
            $doneStmt->execute(array_merge([$batchId], $chunk));
            $already = array_flip(array_map('strval', $doneStmt->fetchAll(PDO::FETCH_COLUMN)));
            $existStmt = $pdo->prepare("SELECT id FROM user WHERE id IN ($ph)");
            $existStmt->execute($chunk);
            $existing = array_flip(array_map('strval', $existStmt->fetchAll(PDO::FETCH_COLUMN)));
            $todo = [];
            foreach ($chunk as $id) {
                if (isset($already[$id])) {
                    $out['already']++;
                } elseif (!isset($existing[$id])) {
                    $out['missing']++;
                } else {
                    $todo[] = $id;
                }
            }
            if (!empty($todo)) {
                $ph2 = implode(',', array_fill(0, count($todo), '?'));
                $up = $pdo->prepare("UPDATE user SET Balance = Balance + ? WHERE id IN ($ph2)");
                $up->execute(array_merge([$amount], $todo));
                $ins = $pdo->prepare(
                    "INSERT INTO wallet_ledger (id_user, direction, amount, balance_after, category, description, id_order, ref_table, ref_id) "
                    . "SELECT id, 'credit', ?, Balance, 'admin_gift', ?, ?, 'bulk_gift', ? FROM user WHERE id IN ($ph2)"
                );
                $ins->execute(array_merge([$amount, $description, $batchId, $batchId], $todo));
                if ($up->rowCount() !== count($todo) || $ins->rowCount() !== count($todo)) {
                    throw new RuntimeException('bulk gift row count mismatch');
                }
            }
            $pdo->commit();
            $out['credited'] = count($todo);
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if (function_exists('rx_log_event')) {
                rx_log_event('BULK_GIFT_CHUNK_FALLBACK', $e->getMessage(), ['batch' => $batchId, 'size' => count($chunk)]);
            }
            $out = ['credited' => 0, 'already' => 0, 'missing' => 0, 'failed' => []];
            foreach ($chunk as $id) {
                try {
                    $pdo->beginTransaction();
                    $one = $pdo->prepare("SELECT COUNT(*) FROM wallet_ledger WHERE id_order = ? AND category = 'admin_gift' AND id_user = ?");
                    $one->execute([$batchId, $id]);
                    if ((int) $one->fetchColumn() > 0) {
                        $pdo->rollBack();
                        $out['already']++;
                        continue;
                    }
                    if (!balance_atomic_credit($id, $amount)) {
                        $pdo->rollBack();
                        $exists = $pdo->prepare("SELECT COUNT(*) FROM user WHERE id = ?");
                        $exists->execute([$id]);
                        if ((int) $exists->fetchColumn() === 0) {
                            $out['missing']++;
                        } else {
                            $out['failed'][$id] = 'credit failed';
                        }
                        continue;
                    }
                    if (!wallet_ledger_record($id, 'credit', $amount, 'admin_gift', $description, $batchId, 'bulk_gift', $batchId)) {
                        throw new RuntimeException('ledger failed');
                    }
                    $pdo->commit();
                    $out['credited']++;
                } catch (Throwable $inner) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $out['failed'][$id] = $inner->getMessage();
                }
            }
        }
        if (function_exists('clearSelectCache')) {
            clearSelectCache('user');
        }
        return $out;
    }
}

if (!function_exists('rx_bulk_gift_run')) {

    function rx_bulk_gift_run(string $batchId, float $timeBudget = 20.0, int $chunkSize = 500): array
    {
        global $pdo;
        $path = rx_bulk_gift_state_path($batchId);
        $state = is_file($path) ? json_decode((string) @file_get_contents($path), true) : null;
        if (!is_array($state) || !isset($state['ids']) || !is_array($state['ids'])) {
            return ['status' => 'missing', 'batch' => $batchId];
        }
        if (($state['status'] ?? '') === 'done') {
            return $state;
        }
        if (!($pdo instanceof PDO)) {
            $state['status'] = 'partial';
            return $state;
        }
        $lock = @fopen($path . '.lock', 'c');
        if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
            if ($lock !== false) {
                fclose($lock);
            }
            $state['status'] = 'busy';
            return $state;
        }
        $state = json_decode((string) @file_get_contents($path), true);
        if (!is_array($state) || ($state['status'] ?? '') === 'done') {
            flock($lock, LOCK_UN);
            fclose($lock);
            return is_array($state) ? $state : ['status' => 'missing', 'batch' => $batchId];
        }
        $amount = (int) ($state['amount'] ?? 0);
        $ids = array_map('strval', $state['ids']);
        $total = count($ids);
        $pos = (int) ($state['pos'] ?? 0);
        foreach (['credited', 'already', 'missing'] as $k) {
            $state[$k] = (int) ($state[$k] ?? 0);
        }
        $state['failed'] = is_array($state['failed'] ?? null) ? $state['failed'] : [];
        $description = 'شارژ همگانی توسط ادمین';
        $started = microtime(true);
        $state['status'] = 'running';
        rx_bulk_gift_save($path, $state);
        while ($pos < $total && $amount > 0) {
            if ((microtime(true) - $started) > $timeBudget) {
                break;
            }
            $chunk = array_slice($ids, $pos, max(1, $chunkSize));
            $res = rx_bulk_gift_chunk($pdo, $batchId, $amount, $chunk, $description);
            $state['credited'] += $res['credited'];
            $state['already'] += $res['already'];
            $state['missing'] += $res['missing'];
            foreach ($res['failed'] as $fid => $reason) {
                $state['failed'][(string) $fid] = (string) $reason;
            }
            $pos += count($chunk);
            $state['pos'] = $pos;
            rx_bulk_gift_save($path, $state);
            if (function_exists('rx_log_event')) {
                rx_log_event('BULK_GIFT_CHUNK', 'chunk processed', [
                    'batch' => $batchId,
                    'pos' => $pos,
                    'total' => $total,
                    'credited' => $res['credited'],
                    'already' => $res['already'],
                    'missing' => $res['missing'],
                    'failed_ids' => array_keys($res['failed']),
                ]);
            }
        }
        $state['status'] = $pos >= $total ? 'done' : 'partial';
        if ($state['status'] === 'done') {
            $state['finished_at'] = time();
        }
        rx_bulk_gift_save($path, $state);
        flock($lock, LOCK_UN);
        fclose($lock);
        return $state;
    }
}

if (!function_exists('rx_bulk_gift_credited_ids')) {

    function rx_bulk_gift_credited_ids(string $batchId): array
    {
        global $pdo;
        if (!($pdo instanceof PDO)) {
            return [];
        }
        $stmt = $pdo->prepare("SELECT id_user FROM wallet_ledger WHERE id_order = :b AND category = 'admin_gift'");
        $stmt->execute([':b' => $batchId]);
        return array_map('strval', $stmt->fetchAll(PDO::FETCH_COLUMN));
    }
}

if (!function_exists('affiliate_should_pay_commission')) {

    function affiliate_should_pay_commission(array $affiliatesSettings, int $paidInvoiceCount): bool {
        if (($affiliatesSettings['status_commission'] ?? '') !== 'oncommission') return false;
        if (($affiliatesSettings['porsant_one_buy'] ?? '') === 'on_buy_porsant') {
            return $paidInvoiceCount <= 1;
        }
        return true;
    }
}

if (!function_exists('affiliate_paid_invoice_count')) {

    function affiliate_paid_invoice_count($buyerId): int {
        global $pdo;
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM invoice WHERE name_product != 'سرویس تست' AND id_user = :id_user AND Status != 'Unpaid'");
        $stmt->bindValue(':id_user', $buyerId);
        $stmt->execute();
        return (int) $stmt->fetchColumn();
    }
}

if (!function_exists('payAffiliateCommissionForPurchase')) {

    function payAffiliateCommissionForPurchase($buyerId, $referrerId, float $purchasePrice, ?int $paidInvoiceCount = null): ?float {
        global $pdo, $setting;
        $affiliatesSettings = select('affiliates', '*', null, null, 'select');
        if (!is_array($affiliatesSettings)) return null;
        if (empty($referrerId) || (int) $referrerId === 0) return null;

        if ($paidInvoiceCount === null) {
            $paidInvoiceCount = affiliate_paid_invoice_count($buyerId);
        }

        if (!affiliate_should_pay_commission($affiliatesSettings, $paidInvoiceCount)) {
            return null;
        }

        $rate = (float) ($setting['affiliatespercentage'] ?? 0);
        $rate = min(100, max(0, $rate));
        $commission = ($purchasePrice * $rate) / 100;
        if ($commission <= 0) return null;

        $referrer = select('user', '*', 'id', $referrerId, 'select');
        if (empty($referrer)) return null;

        if (function_exists('balance_atomic_credit')) {
            balance_atomic_credit($referrerId, $commission);
        } else {
            $stmt = $pdo->prepare("UPDATE user SET Balance = Balance + :d WHERE id = :u");
            $stmt->execute([':d' => $commission, ':u' => $referrerId]);
        }
        if (function_exists('wallet_ledger_record')) {
            wallet_ledger_record($referrerId, 'credit', $commission, 'affiliate_commission', faoxima_textbot_get('dyn_purchase_affiliate_commission_ledger_note', 'پورسانت خرید زیرمجموعه'), null, 'user', (string) $buyerId);
        }

        if ((int) ($setting['scorestatus'] ?? 0) === 1 && function_exists('sendmessage')) {
            $admin_ids = $GLOBALS['admin_ids'] ?? [];
            if (!in_array($referrerId, $admin_ids)) {
                sendmessage($referrerId, faoxima_textbot_get('dyn_purchase_score_earned_2', "📌شما 2 امتیاز جدید کسب کردید."), null, 'html');
                update('user', 'score', (int) $referrer['score'] + 2, 'id', $referrerId);
            }
        }

        return $commission;
    }
}


function StatusPayment($paymentid)
{
    $row = select("PaySetting", "ValuePay", "NamePay", "api_nowpayment", "select");
    $apinowpayments = is_array($row) ? trim((string)($row['ValuePay'] ?? '')) : '';
    if ($apinowpayments === '' || $apinowpayments === '0') {
        $row = select("PaySetting", "ValuePay", "NamePay", "marchent_tronseller", "select");
        $apinowpayments = is_array($row) ? trim((string)($row['ValuePay'] ?? '')) : '';
    }
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.nowpayments.io/v1/payment/' . $paymentid,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'x-api-key:' . $apinowpayments
        ),
    ));
    $response = curl_exec($curl);
    $response = json_decode($response, true);
    curl_close($curl);
    return $response;
}
if (!function_exists('rx_normalize_channel_chat_id')) {
    function rx_normalize_channel_chat_id($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        if (preg_match('/^-\d{5,}$/', $value)) {
            return $value;
        }
        if (preg_match('/^@[A-Za-z][A-Za-z0-9_]{3,31}$/', $value)) {
            return $value;
        }
        if (preg_match('~^(?:https?://)?(?:www\.)?(?:t\.me|telegram\.me|telegram\.dog)/(?:s/)?([A-Za-z][A-Za-z0-9_]{3,31})/?(?:\?.*)?$~i', $value, $m)
            && strtolower($m[1]) !== 'joinchat') {
            return '@' . $m[1];
        }
        if (preg_match('/^[A-Za-z][A-Za-z0-9_]{3,31}$/', $value)) {
            return '@' . $value;
        }
        return '';
    }
}

if (!function_exists('rx_channel_member_state')) {
    function rx_channel_member_state($channel, $userId)
    {
        $chatId = rx_normalize_channel_chat_id($channel);
        $response = null;
        if ($chatId !== '') {
            for ($attempt = 1; $attempt <= 2; $attempt++) {
                $response = telegram('getChatMember', [
                    'chat_id' => $chatId,
                    'user_id' => $userId
                ]);
                if (is_array($response) && !empty($response['ok'])) {
                    $status = (string) ($response['result']['status'] ?? '');
                    if (in_array($status, ['member', 'creator', 'administrator'], true)) {
                        return 'MEMBER';
                    }
                    if ($status === 'restricted') {
                        return !empty($response['result']['is_member']) ? 'MEMBER' : 'NOT_MEMBER';
                    }
                    if (in_array($status, ['left', 'kicked'], true)) {
                        return 'NOT_MEMBER';
                    }
                    $response = ['ok' => false, 'error_code' => 0, 'description' => 'unexpected member status: ' . $status];
                    break;
                }
                $errorCode = is_array($response) ? (int) ($response['error_code'] ?? 0) : 0;
                $retryAfter = is_array($response) ? (int) ($response['parameters']['retry_after'] ?? 0) : 0;
                if ($attempt === 1 && $errorCode === 429 && $retryAfter <= 2) {
                    sleep(max(1, $retryAfter));
                    continue;
                }
                if ($attempt === 1 && $errorCode >= 500) {
                    usleep(500000);
                    continue;
                }
                break;
            }
        } else {
            $response = ['ok' => false, 'error_code' => 0, 'description' => 'invalid channel identifier'];
        }
        $errorCode = is_array($response) ? (int) ($response['error_code'] ?? 0) : 0;
        $description = is_array($response) ? (string) ($response['description'] ?? '') : 'empty response';
        $parameters = is_array($response) && isset($response['parameters']) ? $response['parameters'] : null;
        $logContext = [
            'status' => $errorCode,
            'body' => (string) $channel . '|' . $description,
            'channel' => (string) $channel,
            'chat_id' => $chatId,
            'user_id' => (string) $userId,
            'error_code' => $errorCode,
            'description' => $description,
            'retry_after' => is_array($parameters) ? (int) ($parameters['retry_after'] ?? 0) : 0,
            'parameters' => $parameters !== null ? json_encode($parameters) : '',
        ];
        if (function_exists('rx_log_event')) {
            rx_log_event('CHANNEL_CHECK_FAILED', 'getChatMember did not return a usable result', $logContext);
        } else {
            error_log('[CHANNEL_CHECK_FAILED] ' . json_encode($logContext));
        }
        return 'CHECK_FAILED';
    }
}

function channel(array $id_channel, &$check_failed = null)
{
    global $from_id;
    $channel_link = [];
    $failed = [];
    foreach ($id_channel as $channel) {
        $channel = trim((string) $channel);
        if ($channel === '') {
            continue;
        }
        $state = rx_channel_member_state($channel, $from_id);
        if ($state === 'NOT_MEMBER') {
            $channel_link[] = $channel;
        } elseif ($state === 'CHECK_FAILED') {
            $failed[] = $channel;
        }
    }
    if (func_num_args() < 2) {
        return array_merge($channel_link, $failed);
    }
    $check_failed = $failed;
    return $channel_link;
}
function isValidDate($date)
{
    return (strtotime($date) != false);
}
function tronadoExtractPaymentToken($payment)
{
    if (!is_array($payment)) {
        return '';
    }
    $candidate = $payment['Token'] ?? ($payment['Data']['Token'] ?? '');
    return trim((string) $candidate);
}

function tronadoNormalizeOrderTokenResponse($decoded)
{
    if (!is_array($decoded)) {
        return $decoded;
    }
    if (array_key_exists('Token', $decoded)) {
        return $decoded;
    }
    if (isset($decoded['Data']) && is_array($decoded['Data'])) {
        $normalized = $decoded['Data'];
        if (!array_key_exists('ErrorMessage', $normalized) && isset($decoded['Message'])) {
            $normalized['ErrorMessage'] = $decoded['Message'];
        }
        return $normalized;
    }

    // A rejected GetOrderToken comes back as
    //   {"IsSuccessful":false,"Code":-31,"Message":"Please specify your Tron Wallet Address.","Data":null}
    // Data is null there, so isset() skips the branch above and the reason was dropped: the
    // seller only ever saw the generic "پاسخ نامعتبر از سرویس ترونادو" with nothing to act on.
    if (!array_key_exists('ErrorMessage', $decoded)
        && isset($decoded['Message'])
        && trim((string) $decoded['Message']) !== '') {
        $decoded['ErrorMessage'] = (string) $decoded['Message'];
    }

    return $decoded;
}

// Base58Check TRON address: 25 bytes, version byte 0x41, double-SHA-256 checksum - the rule
// Tronado's GetOrderToken enforces. A shape regex cannot catch a typo or a re-cased address.
// Pure PHP (no gmp/bcmath).
function tronadoIsValidTronAddress($address)
{
    if (!is_string($address)) {
        return false;
    }
    $address = trim($address);
    if (strlen($address) !== 34 || $address[0] !== 'T') {
        return false;
    }

    $alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    $bytes = [];
    for ($i = 0; $i < 34; $i++) {
        $carry = strpos($alphabet, $address[$i]);
        if ($carry === false) {
            return false;
        }
        for ($j = 0, $n = count($bytes); $j < $n; $j++) {
            $carry += $bytes[$j] * 58;
            $bytes[$j] = $carry & 0xFF;
            $carry >>= 8;
        }
        while ($carry > 0) {
            $bytes[] = $carry & 0xFF;
            $carry >>= 8;
        }
    }
    $bytes = array_reverse($bytes);
    if (count($bytes) !== 25 || $bytes[0] !== 0x41) {
        return false;
    }

    $raw = '';
    foreach ($bytes as $byte) {
        $raw .= chr($byte);
    }

    return hash_equals(substr(hash('sha256', hash('sha256', substr($raw, 0, 21), true), true), 0, 4), substr($raw, 21, 4));
}

// The offline hash-checker matches a payment's recipient against its TRX wallet case-insensitively
// and does not know Tronado's payout transactions. If Tronado paid into that same wallet, one Tronado
// payout could be submitted again as proof for an offline TRX invoice and credited twice - so the two
// wallets must never be the same address.
function tronadoWalletsCollide($tronadoWallet, $offlineTrxWallet)
{
    $a = trim((string) $tronadoWallet);
    $b = trim((string) $offlineTrxWallet);
    return $a !== '' && $b !== '' && strcasecmp($a, $b) === 0;
}

function tronadoResolveWalletAddress()
{
    // Tronado pays into its own wallet only. There is deliberately no fallback to the crypto
    // wallets section: that TRX wallet is also watched by the offline hash-checker, which does not
    // know Tronado's payout transactions, so a buyer could submit a Tronado payout hash as proof
    // for an offline invoice and be credited twice for one payment.
    $walletSetting = select("PaySetting", "*", "NamePay", "walletaddress", "select");
    return trim((string) ($walletSetting['ValuePay'] ?? ''));
}

function tronadoCurlJson($endpoint, array $payload, $apiKey = null)
{
    $headers = ['Content-Type: application/json'];
    if ($apiKey !== null) {
        $headers[] = 'x-api-key: ' . $apiKey;
    }

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $endpoint,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        CURLOPT_HTTPHEADER => $headers,
    ));

    $response = curl_exec($curl);
    $curlErrno = curl_errno($curl);
    $curlError = curl_error($curl);
    $curlInfo = curl_getinfo($curl);
    $statusCode = $curlInfo['http_code'] ?? null;
    curl_close($curl);

    if ($response === false) {
        error_log('Tronado request failed: ' . json_encode([
            'url' => $endpoint,
            'error' => $curlError,
            'errno' => $curlErrno,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return null;
    }

    $decoded = json_decode($response, true);
    if (!is_array($decoded)) {
        error_log('Tronado invalid response: ' . json_encode([
            'url' => $endpoint,
            'status_code' => $statusCode,
            'raw_response' => $response,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return null;
    }

    return $decoded;
}

function tronadoGetTronPriceToman()
{
    $config = defined('TRONADO_API_CONFIGURATION') ? TRONADO_API_CONFIGURATION : [];
    $baseUrl = rtrim((string) ($config['base_url'] ?? 'https://bot.tronado.cloud'), '/');
    $path = '/' . ltrim((string) ($config['price_toman_path'] ?? '/Tron/GetPriceToToman'), '/');

    $decoded = tronadoCurlJson($baseUrl . $path, []);
    if (!is_array($decoded) || !isset($decoded['TronPriceToman']) || !is_numeric($decoded['TronPriceToman'])) {
        return null;
    }

    return (float) $decoded['TronPriceToman'];
}

function trnado($order_id, $price)
{
    global $domainhosts;

    $apitronseller = trim((string) select("PaySetting", "*", "NamePay", "apiternado", "select")['ValuePay']);
    $walletaddress = tronadoResolveWalletAddress();
    $wageFromBusinessPercentage = (int) select("PaySetting", "*", "NamePay", "wageFromBusinessPercentageTronado", "select")['ValuePay'];

    if ($apitronseller === '') {
        return [
            'success' => false,
            'error' => 'کلید API ترونادو تنظیم نشده است',
        ];
    }

    if ($walletaddress === '') {
        return [
            'success' => false,
            'error' => 'آدرس کیف پول ترونادو تنظیم نشده است. از منوی ترونادو «💼 آدرس کیف پول ترونادو» آن را ثبت کنید.',
        ];
    }

    $tronPriceToman = tronadoGetTronPriceToman();
    if ($tronPriceToman === null || $tronPriceToman <= 0) {
        return [
            'success' => false,
            'error' => 'دریافت قیمت ترون از ترونادو با خطا مواجه شد',
        ];
    }

    $tronAmount = round(((float) $price) / $tronPriceToman, 6);

    $endpoints = defined('TRONADO_ORDER_TOKEN_ENDPOINTS') ? TRONADO_ORDER_TOKEN_ENDPOINTS : [];
    if (empty($endpoints)) {
        $endpoints = ['https://bot.tronado.cloud/api/v5/GetOrderToken'];
    }

    $callbackUrl = 'https://' . $domainhosts . '/payment/tronado.php';
    $requestPayload = [
        'PaymentID' => (string) $order_id,
        'WalletAddress' => $walletaddress,
        'TronAmount' => $tronAmount,
        'CallbackUrl' => $callbackUrl,
    ];

    $endpoint = $endpoints[0] . '?wageFromBusinessPercentage=' . $wageFromBusinessPercentage;

    $rawDecodedResponse = tronadoCurlJson($endpoint, $requestPayload, $apitronseller);
    $decodedResponse = tronadoNormalizeOrderTokenResponse($rawDecodedResponse);

    if (!is_array($decodedResponse) || !array_key_exists('Token', $decodedResponse) || trim((string) $decodedResponse['Token']) === '') {
        $errorText = is_array($decodedResponse) ? (string) ($decodedResponse['ErrorMessage'] ?? 'پاسخ نامعتبر از سرویس ترونادو') : 'پاسخ نامعتبر از سرویس ترونادو';
        if (!tronadoIsValidTronAddress($walletaddress)) {
            // Most often an address saved upper-cased by an older version; Base58 is case sensitive.
            $errorText .= ' | آدرس کیف پول ترونادو ذخیره‌شده معتبر نیست؛ از منوی ترونادو «💼 آدرس کیف پول ترونادو» آن را دوباره ثبت کنید.';
        }
        $errorPayload = [
            'success' => false,
            'error' => $errorText,
            'url' => $endpoint,
        ];

        error_log('Tronado GetOrderToken failed: ' . json_encode($errorPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        return $errorPayload;
    }

    return $decodedResponse;
}

function tonpayRateLimitStatePath()
{
    $root = defined('REFACTORED_LEGACY_ROOT') ? REFACTORED_LEGACY_ROOT
          : (defined('APP_ROOT_PATH') ? APP_ROOT_PATH : dirname(__DIR__, 3));
    $runtime = $root . DIRECTORY_SEPARATOR . 'cronbot' . DIRECTORY_SEPARATOR . '.runtime';
    if (@is_dir($runtime) || @mkdir($runtime, 0775, true) || @is_dir($runtime)) {
        return $runtime . DIRECTORY_SEPARATOR . 'tonpay_ratelimit.json';
    }
    return sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'rx_tonpay_ratelimit_' . md5((string) $root) . '.json';
}

function tonpayRateLimitRedisEval($script, array $keys, array $args)
{
    if (!function_exists('getRedisConnection')) {
        return null;
    }
    $client = getRedisConnection();
    if ($client === null) {
        return null;
    }
    $keys = array_map('rx_redis_key', array_values($keys));
    try {
        if ($client instanceof \Redis) {
            $result = $client->eval($script, array_merge($keys, $args), count($keys));
        } else {
            $result = $client->eval($script, count($keys), ...array_merge($keys, $args));
        }
    } catch (\Throwable $e) {
        if (function_exists('rx_redis_mark_unavailable')) {
            rx_redis_mark_unavailable('exception');
        }
        return null;
    }
    return ($result === false || $result === null) ? null : (int) $result;
}

function tonpayRateLimitFileMutate(callable $mutator)
{
    $path = tonpayRateLimitStatePath();
    $isNew = !is_file($path);
    $fh = @fopen($path, 'c+');
    if ($fh === false) {
        return null;
    }
    if ($isNew) {
        @chmod($path, 0664);
    }
    if (!@flock($fh, LOCK_EX)) {
        @fclose($fh);
        return null;
    }
    $state = json_decode((string) stream_get_contents($fh), true);
    if (!is_array($state)) {
        $state = [];
    }
    $result = $mutator($state);
    @ftruncate($fh, 0);
    @rewind($fh);
    @fwrite($fh, (string) json_encode($state));
    @fflush($fh);
    @flock($fh, LOCK_UN);
    @fclose($fh);
    return $result;
}

function tonpayRateLimitAcquire()
{
    $limit = 50;
    $windowMs = 60000;
    $nowMs = (int) floor(microtime(true) * 1000);

    $script = "local now = tonumber(ARGV[1]) "
        . "local blocked = tonumber(redis.call('get', KEYS[2]) or '0') or 0 "
        . "if blocked > now then return 0 end "
        . "redis.call('zremrangebyscore', KEYS[1], '-inf', now - tonumber(ARGV[2])) "
        . "if redis.call('zcard', KEYS[1]) >= tonumber(ARGV[3]) then return 0 end "
        . "redis.call('zadd', KEYS[1], now, ARGV[4]) "
        . "redis.call('pexpire', KEYS[1], tonumber(ARGV[2])) "
        . "return 1";
    $member = $nowMs . ':' . bin2hex(random_bytes(4));
    $redisResult = tonpayRateLimitRedisEval(
        $script,
        ['faoxima:tonpay:ratelimit:window', 'faoxima:tonpay:ratelimit:blocked'],
        [$nowMs, $windowMs, $limit, $member]
    );
    if ($redisResult !== null) {
        return $redisResult === 1;
    }

    $fileResult = tonpayRateLimitFileMutate(function (array &$state) use ($limit, $windowMs, $nowMs) {
        if ((int) ($state['blocked_until'] ?? 0) > $nowMs) {
            return false;
        }
        $hits = [];
        foreach ((array) ($state['hits'] ?? []) as $hit) {
            if ((int) $hit > $nowMs - $windowMs) {
                $hits[] = (int) $hit;
            }
        }
        if (count($hits) >= $limit) {
            $state['hits'] = $hits;
            return false;
        }
        $hits[] = $nowMs;
        $state['hits'] = $hits;
        return true;
    });
    if ($fileResult === null) {
        error_log('TonPay rate limiter storage unavailable; request allowed without local accounting');
        return true;
    }
    return $fileResult;
}

function tonpayRateLimitBlock($seconds)
{
    $seconds = max(1, min(600, (int) $seconds));
    $untilMs = (int) floor(microtime(true) * 1000) + ($seconds * 1000);

    $script = "local cur = tonumber(redis.call('get', KEYS[1]) or '0') or 0 "
        . "if tonumber(ARGV[1]) > cur then redis.call('set', KEYS[1], ARGV[1], 'PX', tonumber(ARGV[2])) end "
        . "return 1";
    if (tonpayRateLimitRedisEval($script, ['faoxima:tonpay:ratelimit:blocked'], [$untilMs, $seconds * 1000]) !== null) {
        return;
    }

    tonpayRateLimitFileMutate(function (array &$state) use ($untilMs) {
        if ($untilMs > (int) ($state['blocked_until'] ?? 0)) {
            $state['blocked_until'] = $untilMs;
        }
        return true;
    });
}

function tonpayParseRetryAfter($value)
{
    $value = trim((string) $value);
    if ($value === '') {
        return 60;
    }
    if (ctype_digit($value)) {
        return (int) $value;
    }
    $ts = strtotime($value);
    return $ts === false ? 60 : max(1, $ts - time());
}

function tonpayErrorCode($decoded)
{
    $detail = is_array($decoded) ? ($decoded['detail'] ?? null) : null;
    if (is_array($detail) && isset($detail['code']) && is_scalar($detail['code'])) {
        return trim((string) $detail['code']);
    }
    return '';
}

function tonpayNormalizeError($decoded, $fallbackMessage)
{
    $statusCode = is_array($decoded) ? (int) ($decoded['status_code'] ?? 0) : 0;
    $detail = is_array($decoded) ? ($decoded['detail'] ?? null) : null;
    $code = tonpayErrorCode($decoded);
    $message = '';
    if (is_array($detail)) {
        if (isset($detail['message']) && is_scalar($detail['message'])) {
            $message = trim((string) $detail['message']);
        } elseif (isset($detail[0]['msg']) && is_scalar($detail[0]['msg'])) {
            $message = trim((string) $detail[0]['msg']);
        }
    } elseif (is_scalar($detail)) {
        $message = trim((string) $detail);
    }
    if ($code === '' && $statusCode === 429) {
        $code = 'RATE_LIMIT_EXCEEDED';
    }
    return [
        'success' => false,
        'error_code' => $code,
        'error' => $message !== '' ? $message : (string) $fallbackMessage,
        'status_code' => $statusCode,
        'rate_limited' => $code === 'RATE_LIMIT_EXCEEDED',
    ];
}

function tonpayIsRateLimited($response)
{
    if (!is_array($response)) {
        return false;
    }
    return !empty($response['rate_limited'])
        || (int) ($response['status_code'] ?? 0) === 429
        || tonpayErrorCode($response) === 'RATE_LIMIT_EXCEEDED'
        || (string) ($response['error_code'] ?? '') === 'RATE_LIMIT_EXCEEDED';
}

function tonpayRedactUrl($url)
{
    $url = (string) $url;
    $cut = strcspn($url, '?#');
    return $cut < strlen($url) ? substr($url, 0, $cut) . '?[redacted]' : $url;
}

function tonpayMaskSecret($secret)
{
    $secret = trim((string) $secret);
    $length = strlen($secret);
    if ($length === 0) {
        return '';
    }
    if ($length < 12) {
        return str_repeat('•', 6);
    }
    return substr($secret, 0, 4) . '…' . substr($secret, -4);
}

function tonpayNormalizeBuyerChatId($buyerChatId)
{
    if (is_int($buyerChatId)) {
        return $buyerChatId > 0 ? $buyerChatId : null;
    }
    if (is_string($buyerChatId)) {
        $buyerChatId = trim($buyerChatId);
        if ($buyerChatId !== '' && strlen($buyerChatId) <= 15 && ctype_digit($buyerChatId) && (int) $buyerChatId > 0) {
            return (int) $buyerChatId;
        }
    }
    return null;
}

function tonpayValidPaymentUrl($url)
{
    if (!is_string($url)) {
        return '';
    }
    $url = trim($url);
    if ($url === '' || filter_var($url, FILTER_VALIDATE_URL) === false) {
        return '';
    }
    return strtolower((string) parse_url($url, PHP_URL_SCHEME)) === 'https' ? $url : '';
}

function tonpayPaymentMode()
{
    $row = select("PaySetting", "ValuePay", "NamePay", "tonpay_payment_mode", "select");
    $mode = is_array($row) ? strtolower(trim((string) ($row['ValuePay'] ?? ''))) : '';
    return $mode === 'web' ? 'web' : 'bot';
}

function tonpaySelectPaymentUrl($botUrl, $webUrl, $logOrderId = null)
{
    $botUrl = is_scalar($botUrl) ? trim((string) $botUrl) : '';
    $webUrl = tonpayValidPaymentUrl($webUrl);
    if (tonpayPaymentMode() !== 'web') {
        return $botUrl;
    }
    if ($webUrl !== '') {
        return $webUrl;
    }
    if ($logOrderId !== null) {
        error_log('TonPay web payment url missing, falling back to bot url: ' . json_encode([
            'order_id' => (string) $logOrderId,
            'has_bot_url' => $botUrl !== '',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }
    return $botUrl;
}

function tonpayStoreWebInvoiceUrl($orderId, $webUrl)
{
    global $pdo;
    $webUrl = tonpayValidPaymentUrl($webUrl);
    if ($webUrl === '' || !($pdo instanceof PDO)) {
        return false;
    }
    try {
        $stmt = $pdo->prepare("UPDATE Payment_report SET tonpay_web_invoice_url = ? WHERE id_order = ?");
        $stmt->execute([$webUrl, (string) $orderId]);
        return true;
    } catch (Throwable $e) {
        error_log('TonPay store web invoice url failed: ' . json_encode([
            'order_id' => (string) $orderId,
            'error' => $e->getMessage(),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return false;
    }
}

function tonpayAmountsMatch($requestAmount, $expectedPrice)
{
    if (!is_numeric($requestAmount) || !is_numeric($expectedPrice)) {
        return false;
    }
    $received = (float) $requestAmount;
    $expected = (float) $expectedPrice;
    if ($received != floor($received) || $expected != floor($expected)) {
        return false;
    }
    return (int) $received === (int) $expected;
}

function tonpayLogAmountMismatch($source, $orderId, $invoiceId, $expectedPrice, $requestAmount)
{
    error_log('TonPay amount mismatch: ' . json_encode([
        'source' => (string) $source,
        'order_id' => (string) $orderId,
        'invoice_id' => (string) $invoiceId,
        'expected_amount' => is_scalar($expectedPrice) ? (string) $expectedPrice : null,
        'received_request_amount' => is_scalar($requestAmount) ? (string) $requestAmount : null,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function tonpayTerminalLocalStatus($remoteStatus)
{
    $map = [
        'expired' => 'expire',
        'canceled' => 'cancelled',
        'cancelled' => 'cancelled',
        'rejected' => 'reject',
    ];
    $remoteStatus = strtolower(trim(is_scalar($remoteStatus) ? (string) $remoteStatus : ''));
    return $map[$remoteStatus] ?? null;
}

function tonpaySyncTerminalStatus($orderId, $remoteStatus)
{
    global $pdo;
    $localStatus = tonpayTerminalLocalStatus($remoteStatus);
    if ($localStatus === null || !($pdo instanceof PDO)) {
        return false;
    }
    try {
        $stmt = $pdo->prepare(
            "UPDATE Payment_report
                SET payment_Status = ?
              WHERE id_order = ?
                AND Payment_Method = 'tonpay'
                AND payment_Status IN ('Unpaid','pending','waiting')"
        );
        $stmt->execute([$localStatus, (string) $orderId]);
        return $stmt->rowCount() > 0;
    } catch (Throwable $e) {
        error_log('TonPay terminal status sync failed: ' . json_encode([
            'order_id' => (string) $orderId,
            'error' => $e->getMessage(),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return false;
    }
}

function tonpayCurlJson($method, $endpoint, array $payload, $apiKey)
{
    if (!tonpayRateLimitAcquire()) {
        error_log('TonPay request skipped by local rate limiter: ' . json_encode([
            'url' => $endpoint,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return [
            'detail' => [
                'code' => 'RATE_LIMIT_EXCEEDED',
                'message' => 'سقف درخواست‌های تون‌پی موقتاً پر شده است؛ لطفاً کمی بعد دوباره تلاش کنید',
            ],
            'status_code' => 429,
            'rate_limited' => true,
            'local_rate_limited' => true,
        ];
    }

    $headers = ['Content-Type: application/json'];
    if ($apiKey !== null) {
        $headers[] = 'X-API-Key: ' . $apiKey;
    }

    $retryAfter = '';
    $curl = curl_init();
    $opts = array(
        CURLOPT_URL => $endpoint,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_HEADERFUNCTION => function ($ch, $headerLine) use (&$retryAfter) {
            if (stripos($headerLine, 'Retry-After:') === 0) {
                $retryAfter = trim(substr($headerLine, strlen('Retry-After:')));
            }
            return strlen($headerLine);
        },
    );
    if ($method === 'POST') {
        $opts[CURLOPT_POSTFIELDS] = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    curl_setopt_array($curl, $opts);

    $response = curl_exec($curl);
    $curlErrno = curl_errno($curl);
    $curlError = curl_error($curl);
    $curlInfo = curl_getinfo($curl);
    $statusCode = $curlInfo['http_code'] ?? null;
    curl_close($curl);

    if ($response === false) {
        error_log('TonPay request failed: ' . json_encode([
            'url' => $endpoint,
            'error' => $curlError,
            'errno' => $curlErrno,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return null;
    }

    $decoded = json_decode($response, true);
    if ((int) $statusCode === 429 || tonpayErrorCode($decoded) === 'RATE_LIMIT_EXCEEDED') {
        tonpayRateLimitBlock(tonpayParseRetryAfter($retryAfter));
        error_log('TonPay rate limit response: ' . json_encode([
            'url' => $endpoint,
            'status_code' => $statusCode,
            'retry_after' => $retryAfter,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        if (!is_array($decoded)) {
            $decoded = ['detail' => ['code' => 'RATE_LIMIT_EXCEEDED', 'message' => 'Rate limit exceeded']];
        }
        $decoded['rate_limited'] = true;
    }
    if (!is_array($decoded)) {
        error_log('TonPay invalid response: ' . json_encode([
            'url' => $endpoint,
            'status_code' => $statusCode,
            'raw_response' => $response,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return null;
    }

    $decoded['status_code'] = $statusCode;
    return $decoded;
}

function tonpayApiKey()
{
    return trim((string) select("PaySetting", "*", "NamePay", "apitonpay", "select")['ValuePay']);
}

function tonpayCreateInvoice($order_id, $amount, $buyer_chat_id = null)
{
    global $domainhosts;

    $apiKey = tonpayApiKey();
    if ($apiKey === '') {
        return [
            'success' => false,
            'error' => 'کلید API تون‌پی تنظیم نشده است',
            'error_code' => 'MISSING_API_KEY',
            'status_code' => 0,
        ];
    }

    $callbackUrl = 'https://' . $domainhosts . '/payment/tonpay.php';
    $requestPayload = [
        'amount' => (int) $amount,
        'order_id' => (string) $order_id,
        'callback_url' => $callbackUrl,
    ];
    $buyerChatId = tonpayNormalizeBuyerChatId($buyer_chat_id);
    if ($buyerChatId !== null) {
        $requestPayload['buyer_chat_id'] = $buyerChatId;
    }

    $endpoint = 'https://tonpays.online/api/v1/invoices/create';
    $decoded = tonpayCurlJson('POST', $endpoint, $requestPayload, $apiKey);

    $invoiceId = is_array($decoded) && is_scalar($decoded['invoice_id'] ?? null) ? trim((string) $decoded['invoice_id']) : '';
    $invoiceUrl = is_array($decoded) && is_scalar($decoded['invoice_url'] ?? null) ? trim((string) $decoded['invoice_url']) : '';
    if ($invoiceId === '' || $invoiceUrl === '') {
        $errorPayload = tonpayNormalizeError($decoded, 'پاسخ نامعتبر از سرویس تون‌پی');
        error_log('TonPay create invoice failed: ' . json_encode([
            'order_id' => (string) $order_id,
            'status_code' => $errorPayload['status_code'],
            'error_code' => $errorPayload['error_code'],
            'error' => $errorPayload['error'],
            'buyer_chat_id_sent' => $buyerChatId !== null,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return $errorPayload;
    }

    $decoded['invoice_id'] = $invoiceId;
    $decoded['invoice_url'] = $invoiceUrl;
    $decoded['web_invoice_url'] = tonpayValidPaymentUrl($decoded['web_invoice_url'] ?? null);
    return $decoded;
}

function tonpayCheckInvoice($invoice_id)
{
    $apiKey = tonpayApiKey();
    if ($apiKey === '') {
        return null;
    }

    $endpoint = 'https://tonpays.online/api/v1/invoices/check/' . rawurlencode((string) $invoice_id);
    return tonpayCurlJson('GET', $endpoint, [], $apiKey);
}

const ATLASPAY_BASE_URL = 'https://api.atlaspay.space/api/v1';

function atlaspayApiKey()
{
    return trim((string) select("PaySetting", "*", "NamePay", "apiatlaspay", "select")['ValuePay']);
}

function atlaspayCurlJson($method, $endpoint, array $payload, $apiKey)
{
    $headers = ['Content-Type: application/json'];
    if ($apiKey !== null) {
        $headers[] = 'X-API-Key: ' . $apiKey;
    }

    $curl = curl_init();
    $opts = array(
        CURLOPT_URL => $endpoint,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
    );
    if ($method === 'POST') {
        $opts[CURLOPT_POSTFIELDS] = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    curl_setopt_array($curl, $opts);

    $response = curl_exec($curl);
    $curlErrno = curl_errno($curl);
    $curlError = curl_error($curl);
    $curlInfo = curl_getinfo($curl);
    $statusCode = $curlInfo['http_code'] ?? null;
    curl_close($curl);

    if ($response === false) {
        error_log('AtlasPay request failed: ' . json_encode([
            'url' => $endpoint,
            'error' => $curlError,
            'errno' => $curlErrno,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return null;
    }

    $decoded = json_decode($response, true);
    if (!is_array($decoded)) {
        error_log('AtlasPay invalid response: ' . json_encode([
            'url' => $endpoint,
            'status_code' => $statusCode,
            'raw_response' => $response,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return null;
    }

    $decoded['status_code'] = $statusCode;
    return $decoded;
}

function atlaspayCreateOrder($order_id, $amount, $telegramId = null)
{
    $apiKey = atlaspayApiKey();
    if ($apiKey === '') {
        return [
            'success' => false,
            'error' => 'کلید API اطلس‌پی تنظیم نشده است',
        ];
    }

    $requestPayload = [
        'merchantOrderRef' => (string) $order_id,
        'baseAmountToman' => (int) $amount,
    ];
    if ($telegramId !== null) {
        $requestPayload['customerTelegramId'] = (int) $telegramId;
    }

    $endpoint = ATLASPAY_BASE_URL . '/orders';
    $decoded = atlaspayCurlJson('POST', $endpoint, $requestPayload, $apiKey);

    if (!is_array($decoded) || empty($decoded['orderId']) || empty($decoded['customerStartLink'])) {
        $errorPayload = [
            'success' => false,
            'error' => is_array($decoded) ? ($decoded['message'] ?? 'پاسخ نامعتبر از سرویس اطلس‌پی') : 'پاسخ نامعتبر از سرویس اطلس‌پی',
            'raw' => $decoded,
        ];
        error_log('AtlasPay create order failed: ' . json_encode($errorPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return $errorPayload;
    }

    return $decoded;
}

function atlaspayCheckOrder($atlaspayOrderId)
{
    $apiKey = atlaspayApiKey();
    if ($apiKey === '') {
        return null;
    }

    $endpoint = ATLASPAY_BASE_URL . '/orders/' . rawurlencode((string) $atlaspayOrderId);
    return atlaspayCurlJson('GET', $endpoint, [], $apiKey);
}

function atlaspayVerifyOrder($atlaspayOrderId)
{
    $apiKey = atlaspayApiKey();
    if ($apiKey === '') {
        return null;
    }

    $endpoint = ATLASPAY_BASE_URL . '/orders/' . rawurlencode((string) $atlaspayOrderId) . '/verify';
    return atlaspayCurlJson('POST', $endpoint, [], $apiKey);
}

function atlaspayCancelOrder($atlaspayOrderId)
{
    $apiKey = atlaspayApiKey();
    if ($apiKey === '') {
        return null;
    }

    $endpoint = ATLASPAY_BASE_URL . '/orders/' . rawurlencode((string) $atlaspayOrderId) . '/cancel';
    return atlaspayCurlJson('POST', $endpoint, [], $apiKey);
}

function atlaspayBalance()
{
    $apiKey = atlaspayApiKey();
    if ($apiKey === '') {
        return null;
    }

    return atlaspayCurlJson('GET', ATLASPAY_BASE_URL . '/balance', [], $apiKey);
}

function atlaspayAccount()
{
    $apiKey = atlaspayApiKey();
    if ($apiKey === '') {
        return null;
    }

    return atlaspayCurlJson('GET', ATLASPAY_BASE_URL . '/account', [], $apiKey);
}

const BLUPAL_RIAL_PER_TOMAN = 10;

function blupalCurlJson($method, $endpoint, array $payload, $apiKey)
{
    $headers = ['Content-Type: application/json'];
    if ($apiKey !== null) {
        $headers[] = 'X-API-Key: ' . $apiKey;
    }

    $curl = curl_init();
    $opts = array(
        CURLOPT_URL => $endpoint,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 8,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_USERAGENT => 'Faoxima-BluPal-Client/1.0',
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
    );
    if ($method === 'POST') {
        $opts[CURLOPT_POSTFIELDS] = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    curl_setopt_array($curl, $opts);

    $response = curl_exec($curl);
    $curlErrno = curl_errno($curl);
    $curlError = curl_error($curl);
    $curlInfo = curl_getinfo($curl);
    $statusCode = $curlInfo['http_code'] ?? null;
    curl_close($curl);

    if ($response === false) {
        error_log('BluPal request failed: ' . json_encode([
            'url' => $endpoint,
            'error' => $curlError,
            'errno' => $curlErrno,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return null;
    }

    $decoded = json_decode($response, true);
    if (!is_array($decoded)) {
        error_log('BluPal invalid response: ' . json_encode([
            'url' => $endpoint,
            'status_code' => $statusCode,
            'raw_response' => $response,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return null;
    }

    $decoded['status_code'] = $statusCode;
    return $decoded;
}

function blupalApiKey()
{
    return trim((string) select("PaySetting", "*", "NamePay", "apiblupal", "select")['ValuePay']);
}

function blupalTomanToRial($tomanAmount)
{
    return (int) round(((float) $tomanAmount) * BLUPAL_RIAL_PER_TOMAN);
}

function blupalRialToToman($rialAmount)
{
    return (int) round(((float) $rialAmount) / BLUPAL_RIAL_PER_TOMAN);
}

function blupalCreateInvoice($order_id, $amountToman)
{
    global $domainhosts;

    $apiKey = blupalApiKey();
    if ($apiKey === '') {
        return [
            'success' => false,
            'error' => 'کلید API بلوپال تنظیم نشده است',
        ];
    }

    $requestPayload = [
        'amount' => blupalTomanToRial($amountToman),
    ];

    $endpoint = 'https://blupal.net/api/v1/invoices/create';
    $decoded = blupalCurlJson('POST', $endpoint, $requestPayload, $apiKey);

    if (!is_array($decoded) || empty($decoded['success']) || empty($decoded['invoice_id']) || empty($decoded['payment_link'])) {
        $errorPayload = [
            'success' => false,
            'error' => is_array($decoded) ? ($decoded['message'] ?? ($decoded['error'] ?? 'پاسخ نامعتبر از سرویس بلوپال')) : 'پاسخ نامعتبر از سرویس بلوپال',
            'raw' => $decoded,
        ];
        error_log('BluPal create invoice failed: ' . json_encode($errorPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return $errorPayload;
    }

    return $decoded;
}

function blupalCheckInvoice($invoice_id)
{
    $apiKey = blupalApiKey();
    if ($apiKey === '') {
        return null;
    }

    $endpoint = 'https://blupal.net/api/v1/invoices/' . rawurlencode((string) $invoice_id);
    return blupalCurlJson('GET', $endpoint, [], $apiKey);
}

function cubepayCurlJson($method, $endpoint, array $payload, $apiToken)
{
    $headers = ['Content-Type: application/json'];
    if ($apiToken !== null && $apiToken !== '') {
        $headers[] = 'Authorization: Bearer ' . $apiToken;
    }

    $curl = curl_init();
    $opts = array(
        CURLOPT_URL => $endpoint,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
    );
    if ($method === 'POST') {
        $opts[CURLOPT_POSTFIELDS] = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    curl_setopt_array($curl, $opts);

    $response = curl_exec($curl);
    $curlErrno = curl_errno($curl);
    $curlError = curl_error($curl);
    $curlInfo = curl_getinfo($curl);
    $statusCode = $curlInfo['http_code'] ?? null;
    curl_close($curl);

    if ($response === false) {
        error_log('CubePay request failed: ' . json_encode([
            'url' => $endpoint,
            'error' => $curlError,
            'errno' => $curlErrno,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return null;
    }

    $decoded = json_decode($response, true);
    if (!is_array($decoded)) {
        error_log('CubePay invalid response: ' . json_encode([
            'url' => $endpoint,
            'status_code' => $statusCode,
            'raw_response' => $response,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return null;
    }

    $decoded['status_code'] = $statusCode;
    return $decoded;
}

function cubepayApiToken()
{
    return trim((string) select("PaySetting", "*", "NamePay", "apicubepay", "select")['ValuePay']);
}

/**
 * کارمزد کیوب‌پی از کیف پول فروشنده کم می‌شود. این تابع اجازه می‌دهد آن هزینه
 * روی فاکتور گذاشته شود تا کاربر پرداختش کند:
 *
 *   عدد 0 تا 100  → درصدی که به مبلغ فاکتور اضافه می‌شود (اعشار مجاز، مثلاً 9.9)
 *   عدد بالای 100 → مبلغ ثابت به تومان
 *   صفر (پیش‌فرض) → غیرفعال؛ کارمزد را خود فروشنده می‌پردازد
 *
 * فقط مبلغ فاکتور درگاه بزرگ‌تر می‌شود. اعتباری که به کاربر داده می‌شود عوض
 * نمی‌شود، چون payment/cubepay.php با Payment_report.price کار می‌کند که همان
 * مبلغ درخواستی کاربر است.
 */
function cubepayPayableAmount($amount_toman)
{
    $amount = (int) $amount_toman;
    $raw = str_replace([',', '،'], '', (string) getPaySettingValue('feecubepay', '0'));
    $fee = is_numeric($raw) ? (float) $raw : 0.0;

    if ($fee <= 0 || $amount <= 0) {
        return $amount;
    }

    return $fee <= 100
        ? (int) ceil($amount * (1 + $fee / 100))
        : $amount + (int) round($fee);
}

function cubepayCreatePayment($order_id, $amount_toman, $customer_user_id = null, $description = '')
{
    global $domainhosts;

    $apiToken = cubepayApiToken();
    if ($apiToken === '') {
        return [
            'success' => false,
            'message' => 'توکن API کیوب‌پی تنظیم نشده است',
        ];
    }

    $callbackUrl = 'https://' . $domainhosts . '/payment/cubepay.php';
    $requestPayload = [
        'order_id' => (string) $order_id,
        'price_amount' => cubepayPayableAmount($amount_toman),
        'callback_url' => $callbackUrl,
        'redirect_after_payment' => false,
    ];

    // Forward the buyer ID already supplied by the bot or authenticated API caller.
    $buyerId = (is_int($customer_user_id) || is_string($customer_user_id))
        ? trim((string) $customer_user_id) : '';
    if (preg_match('/\A[1-9][0-9]{0,15}\z/D', $buyerId)) {
        $requestPayload['customer_user_id'] = $buyerId;
        try {
            // The lookup is scoped to the same buyer. Missing username is normal.
            $buyerRow = select('user', 'username', 'id', $buyerId, 'select');
            $buyerUsernameValue = is_array($buyerRow) ? ($buyerRow['username'] ?? null) : $buyerRow;
            $buyerUsername = is_string($buyerUsernameValue)
                ? ltrim(trim($buyerUsernameValue), '@') : '';
            if (preg_match('/\A[A-Za-z0-9_]{1,64}\z/D', $buyerUsername)
                && !in_array(strtolower($buyerUsername), ['none', 'null', 'undefined'], true)) {
                $requestPayload['customer_username'] = $buyerUsername;
            }
        } catch (Throwable $buyerMetadataError) {
            // Optional display metadata cannot interrupt payment creation.
            // The numeric buyer ID is still sent if the profile lookup fails.
        }
    }

    $endpoint = 'https://cubevps.ir/pay/create-order.php';
    $decoded = cubepayCurlJson('POST', $endpoint, $requestPayload, $apiToken);

    if (!is_array($decoded) || empty($decoded['success']) || empty($decoded['pay_page_url'])) {
        $errorPayload = [
            'success' => false,
            'message' => is_array($decoded) ? ($decoded['message'] ?? 'پاسخ نامعتبر از سرویس کیوب‌پی') : 'پاسخ نامعتبر از سرویس کیوب‌پی',
            'raw' => $decoded,
        ];
        error_log('CubePay create payment failed: ' . json_encode($errorPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return $errorPayload;
    }

    $method = (string) ($decoded['method'] ?? 'choice');
    $normalized = [
        'success' => true,
        'method' => $method,
        'authority' => (string) ($decoded['authority'] ?? ''),
        'payment_link' => (string) $decoded['pay_page_url'],
    ];

    // مسیرِ کارتی: کیوب‌پی اطلاعات کارتِ همین فاکتور و تنظیمِ show_card_in_bot
    // فروشنده را هم برمی‌گرداند. اگر هم کارت و هم ارز دیجیتال فعال باشد، در این
    // لحظه هنوز کارتی اختصاص نیافته (مشتری انتخاب نکرده) و این بلوک رد می‌شود.
    if (!empty($decoded['card']['number'])) {
        $normalized['card'] = $decoded['card'];
        $normalized['pay_amount_toman'] = (int) ($decoded['pay_amount_toman'] ?? 0);
        $normalized['expires_in_minutes'] = (int) ($decoded['expires_in_minutes'] ?? 30);
        $normalized['show_card_in_bot'] = !empty($decoded['show_card_in_bot']);
    }

    return $normalized;
}

function cubepayCheckOrderStatus($order_id)
{
    $apiToken = cubepayApiToken();
    if ($apiToken === '') {
        return null;
    }

    $endpoint = 'https://cubevps.ir/pay/check-order-status.php?order_id=' . rawurlencode((string) $order_id);
    return cubepayCurlJson('GET', $endpoint, [], $apiToken);
}

function cubepayVerifyPayment($authority)
{
    $apiToken = cubepayApiToken();
    if ($apiToken === '') {
        return null;
    }

    $endpoint = 'https://cubevps.ir/smspay/api/verify-payment.php';
    return cubepayCurlJson('POST', $endpoint, ['authority' => (string) $authority], $apiToken);
}

function cubepayResolveOrderStatus($order_id, $authority = '')
{
    $orderId = (string) $order_id;
    $authority = trim((string) $authority);

    $check = cubepayCheckOrderStatus($orderId);
    if (is_array($check) && !empty($check['success'])) {
        return $check;
    }

    if ($authority === '') {
        return $check;
    }

    $verify = cubepayVerifyPayment($authority);
    if (!is_array($verify)) {
        return $check;
    }

    return [
        'success' => !empty($verify['success']),
        'method' => 'card',
        'status' => !empty($verify['success']) ? 'verified' : (string) ($verify['message'] ?? 'pending'),
        'order_id' => (string) ($verify['order_id'] ?? $orderId),
        'amount' => $verify['amount'] ?? null,
    ];
}

function cubepayVerifyCryptoCallbackSignature($orderId, $status, $amount, $sig)
{
    $apiToken = cubepayApiToken();
    if ($apiToken === '') {
        return false;
    }
    $expectedSig = hash_hmac('sha256', $orderId . '|' . $status . '|' . $amount, $apiToken);
    return hash_equals($expectedSig, (string) $sig);
}

/**
 * Variza — automated card-to-card gateway (https://variza.ir).
 *
 * Same role as cubepayCreatePayment(): create a payment link for an order and
 * return a normalized array. Verification is push-only (payment/variza_webhook.php),
 * so there is no verify/status counterpart here.
 */
function varizaApiToken()
{
    return trim((string) select("PaySetting", "*", "NamePay", "apivariza", "select")['ValuePay']);
}

function varizaCreatePayment($order_id, $amount_toman)
{
    global $domainhosts;

    $apiToken = varizaApiToken();
    if ($apiToken === '' || $apiToken === '0') {
        return [
            'success' => false,
            'message' => 'توکن API واریزا تنظیم نشده است',
        ];
    }

    $payload = [
        'amount' => (int) $amount_toman,
        'return_url' => 'https://' . $domainhosts . '/payment/variza_return.php?order=' . $order_id,
        'title' => 'Faoxima order ' . $order_id,
        'expires_in' => '1h',
    ];

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => 'https://variza.ir/api/v1/pay',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Accept: application/json',
            'Authorization: Bearer ' . $apiToken,
        ],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    ]);
    $response = curl_exec($curl);
    $curlErrno = curl_errno($curl);
    $curlError = curl_error($curl);
    $statusCode = (int) (curl_getinfo($curl, CURLINFO_HTTP_CODE) ?? 0);
    curl_close($curl);

    if ($response === false) {
        error_log('Variza create payment failed: ' . json_encode([
            'error' => $curlError,
            'errno' => $curlErrno,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return [
            'success' => false,
            'message' => 'خطا در ارتباط با سرویس واریزا',
        ];
    }

    $decoded = json_decode($response, true);
    if (!is_array($decoded) || $statusCode < 200 || $statusCode >= 300) {
        error_log('Variza invalid response: ' . json_encode([
            'status_code' => $statusCode,
            'raw_response' => $response,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return [
            'success' => false,
            'message' => is_array($decoded) ? ($decoded['message'] ?? 'پاسخ نامعتبر از سرویس واریزا') : 'پاسخ نامعتبر از سرویس واریزا',
            'raw' => $decoded,
        ];
    }

    $slug = trim((string) ($decoded['slug'] ?? ''));
    $payUrl = trim((string) ($decoded['pay_url'] ?? ''));
    if ($slug === '' || $payUrl === '') {
        error_log('Variza missing slug/pay_url: ' . json_encode($decoded, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return [
            'success' => false,
            'message' => 'پاسخ نامعتبر از سرویس واریزا',
            'raw' => $decoded,
        ];
    }

    return [
        'success' => true,
        'slug' => $slug,
        'pay_url' => $payUrl,
    ];
}
/**
 * AbanGateway — automated card-to-card gateway (https://abangateway.ir).
 *
 * The buyer transfers straight to the seller's own card and the payment is
 * confirmed from the bank's SMS, so there is no receipt to approve. Two
 * settings drive it, both handed out by AbanGateway's Telegram bot when the
 * seller connects this bot: the gateway address and the connection key. The
 * address is a prefix — `/create` and `/verify` are appended here.
 *
 * Settlement is push + pull: AbanGateway calls payment/abangateway.php when
 * the money lands, and that file asks abangatewayVerifyPayment() before it
 * credits anything. Nothing in the push itself is trusted.
 */
function abangatewayEndpoint()
{
    $row = select("PaySetting", "ValuePay", "NamePay", "urlabangateway", "select");
    $url = is_array($row) ? rtrim(trim((string) ($row['ValuePay'] ?? '')), '/') : '';
    // https only: the key rides in a header on every call.
    if ($url === '' || stripos($url, 'https://') !== 0 || filter_var($url, FILTER_VALIDATE_URL) === false) {
        return null;
    }
    return $url;
}

function abangatewayApiKey()
{
    $row = select("PaySetting", "ValuePay", "NamePay", "apiabangateway", "select");
    $key = is_array($row) ? trim((string) ($row['ValuePay'] ?? '')) : '';
    return ($key === '0') ? '' : $key;
}

/**
 * On, with an https address and a key. The buyer's button and the mini app's
 * method list both ask this, so a half-configured gateway is never offered.
 */
function abangatewayIsReady()
{
    $row = select("PaySetting", "ValuePay", "NamePay", "statusabangateway", "select");
    $status = is_array($row) ? (string) ($row['ValuePay'] ?? '') : '';
    return $status === 'onabangateway' && abangatewayEndpoint() !== null && abangatewayApiKey() !== '';
}

/**
 * The buyer's payment page for an authority this bot was given, or null.
 *
 * The page lives on the gateway's own origin at /pay/{invoice}, and the
 * authority is "abn_" + that invoice id, so the link can be rebuilt from the
 * stored authority without keeping a second column for it.
 */
function abangatewayPayUrlFor($authority)
{
    $authority = trim((string) $authority);
    $endpoint = abangatewayEndpoint();
    if ($endpoint === null || !preg_match('/^abn_([A-Za-z0-9_]{6,64})$/', $authority, $match)) {
        return null;
    }
    $parts = parse_url($endpoint);
    if (!is_array($parts) || empty($parts['host'])) {
        return null;
    }
    $origin = 'https://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');
    return $origin . '/pay/' . $match[1];
}

function abangatewayRequest($path, array $payload)
{
    $endpoint = abangatewayEndpoint();
    $apiKey = abangatewayApiKey();
    if ($endpoint === null || $apiKey === '') {
        return [
            'ok' => false,
            'status_code' => 0,
            'data' => null,
            'message' => 'آدرس درگاه یا کلید اتصال آبان گیت وی تنظیم نشده است',
        ];
    }

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $endpoint . $path,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Accept: application/json',
            'Authorization: Bearer ' . $apiKey,
        ],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    ]);
    $response = curl_exec($curl);
    $curlErrno = curl_errno($curl);
    $curlError = curl_error($curl);
    $statusCode = (int) (curl_getinfo($curl, CURLINFO_HTTP_CODE) ?? 0);
    curl_close($curl);

    if ($response === false) {
        error_log('AbanGateway request failed: ' . json_encode([
            'path' => $path,
            'error' => $curlError,
            'errno' => $curlErrno,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return [
            'ok' => false,
            'status_code' => 0,
            'data' => null,
            'message' => 'خطا در ارتباط با آبان گیت وی',
        ];
    }

    $decoded = json_decode($response, true);
    if (!is_array($decoded)) {
        error_log('AbanGateway invalid response: ' . json_encode([
            'path' => $path,
            'status_code' => $statusCode,
            'raw_response' => mb_substr((string) $response, 0, 500),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return [
            'ok' => false,
            'status_code' => $statusCode,
            'data' => null,
            'message' => 'پاسخ نامعتبر از آبان گیت وی',
        ];
    }

    // A refusal says why in `message`; a rejected key says it in `error`.
    $message = (string) ($decoded['message'] ?? ($decoded['error'] ?? ''));
    return [
        'ok' => $statusCode >= 200 && $statusCode < 300,
        'status_code' => $statusCode,
        'data' => $decoded,
        'message' => $message,
    ];
}

function abangatewayCreatePayment($order_id, $amount_toman, $user_id = null)
{
    global $domainhosts;

    $payload = [
        // Toman, like every other gateway here; AbanGateway converts once.
        'amount' => (int) $amount_toman,
        'order_id' => (string) $order_id,
        'callback_url' => 'https://' . $domainhosts . '/payment/abangateway.php?order=' . rawurlencode((string) $order_id),
    ];
    if ($user_id !== null && $user_id !== '') {
        $payload['user_id'] = (string) $user_id;
    }

    $answer = abangatewayRequest('/create', $payload);
    $data = is_array($answer['data']) ? $answer['data'] : [];

    if (!$answer['ok'] || empty($data['success'])) {
        return [
            'success' => false,
            'message' => $answer['message'] !== '' ? $answer['message'] : 'ساخت لینک پرداخت در آبان گیت وی ناموفق بود',
            'status_code' => $answer['status_code'],
        ];
    }

    $authority = trim((string) ($data['authority'] ?? ''));
    $payUrl = trim((string) ($data['payment_link'] ?? ''));
    if ($authority === '' || stripos($payUrl, 'https://') !== 0) {
        error_log('AbanGateway missing authority/payment_link: ' . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return [
            'success' => false,
            'message' => 'پاسخ نامعتبر از آبان گیت وی',
        ];
    }

    return [
        'success' => true,
        'authority' => $authority,
        'pay_url' => $payUrl,
    ];
}

/**
 * Ask the gateway, server to server, whether this order was paid.
 *
 * `paid` is true only when the gateway says so AND names the same order AND
 * reports at least the billed amount. The amount comes back in Rial.
 */
function abangatewayVerifyPayment($authority, $order_id, $billed_toman)
{
    $answer = abangatewayRequest('/verify', [
        'authority' => (string) $authority,
        'order_id' => (string) $order_id,
    ]);
    $data = is_array($answer['data']) ? $answer['data'] : [];

    $result = [
        'paid' => false,
        'reachable' => $answer['status_code'] > 0,
        'status_code' => $answer['status_code'],
        'message' => $answer['message'],
        'amount_rial' => (int) ($data['amount'] ?? 0),
    ];
    if (!$answer['ok'] || empty($data['success'])) {
        return $result;
    }
    if ((string) ($data['order_id'] ?? '') !== (string) $order_id) {
        $result['message'] = 'order mismatch';
        return $result;
    }
    if ($result['amount_rial'] < ((int) $billed_toman) * 10) {
        $result['message'] = 'amount mismatch';
        return $result;
    }
    $result['paid'] = true;
    return $result;
}
function formatBytes($bytes, $precision = 2): string
{
    $base = log($bytes, 1024);
    $power = $bytes > 0 ? floor($base) : 0;
    $suffixes = ['بایت', 'کیلوبایت', 'مگابایت', 'گیگابایت', 'ترابایت'];
    return round(pow(1024, $base - $power), $precision) . ' ' . $suffixes[$power];
}
function rxInvoiceVolumeUnit(array $invoice): string
{
    $unit = strtoupper(trim((string) ($invoice['Volume_unit'] ?? '')));
    if ($unit === 'MB' || $unit === 'GB') {
        return $unit;
    }
    return (($invoice['name_product'] ?? '') === 'سرویس تست') ? 'MB' : 'GB';
}
function rxVolumeToBytes($value, string $unit): float
{
    $amount = is_numeric($value) ? (float) $value : 0.0;
    return $amount * ($unit === 'MB' ? pow(1024, 2) : pow(1024, 3));
}
function formatInvoiceVolume(array $invoice, $precision = 2): string
{
    $value = is_numeric($invoice['Volume'] ?? null) ? (float) $invoice['Volume'] : 0.0;
    if ($value == 0.0) {
        return 'نامحدود';
    }
    return formatBytes(rxVolumeToBytes($value, rxInvoiceVolumeUnit($invoice)), $precision);
}
function rxServiceListStatusSuffix(array $invoice): string
{
    return in_array(strtolower((string) ($invoice['Status'] ?? '')), ['disabled', 'disablebyadmin'], true) ? ' | غیرفعال' : '';
}
function rxServiceListBaseLabel(array $invoice): string
{
    $product = trim((string) ($invoice['name_product'] ?? ''));
    return $product !== '' ? $product : (string) ($invoice['username'] ?? '');
}
function rxServiceListLabelKey(array $invoice, bool $withNote): string
{
    return rxServiceListBaseLabel($invoice) . ($withNote ? "\x1F" . trim((string) ($invoice['note'] ?? '')) : '');
}
function rxServiceListDuplicateKeys(array $rows, bool $withNote): array
{
    $counts = [];
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }
        $key = rxServiceListLabelKey($row, $withNote);
        $counts[$key] = ($counts[$key] ?? 0) + 1;
    }
    $duplicates = [];
    foreach ($counts as $key => $count) {
        if ($count > 1) {
            $duplicates[$key] = true;
        }
    }
    return $duplicates;
}
function rxServiceListUserDuplicateKeys($userId, array $statuses, bool $withNote): array
{
    global $pdo;
    if (!($pdo instanceof PDO) || $statuses === []) {
        return [];
    }
    try {
        $placeholders = implode(',', array_fill(0, count($statuses), '?'));
        $stmt = $pdo->prepare("SELECT name_product, username, note FROM invoice WHERE id_user = ? AND Status IN ($placeholders)");
        $stmt->execute(array_merge([(string) $userId], array_values($statuses)));
        return rxServiceListDuplicateKeys($stmt->fetchAll(PDO::FETCH_ASSOC), $withNote);
    } catch (Throwable $e) {
        return [];
    }
}
function rxServiceListLabel(array $invoice, array $duplicateKeys = [], bool $withNote = false): string
{
    $label = rxServiceListBaseLabel($invoice);
    $username = (string) ($invoice['username'] ?? '');
    if ($username !== '' && $label !== $username && isset($duplicateKeys[rxServiceListLabelKey($invoice, $withNote)])) {
        $short = mb_strlen($username) > 12 ? '…' . mb_substr($username, -10) : $username;
        $label .= ' (' . $short . ')';
    }
    return $label;
}
function formatOnlineAtLabel($onlineAt, $isOnline = null)
{
    if ($isOnline === true && (empty($onlineAt) || $onlineAt === null)) {
        return "Online (بدون زمان)";
    }

    if ($onlineAt === null || $onlineAt === '') {
        return "—";
    }

    if (is_string($onlineAt)) {
        $onlineAt = trim($onlineAt);
        if ($onlineAt === '') {
            return "—";
        }
        $lowered = strtolower($onlineAt);
        if ($lowered === 'online') {
            return 'آنلاین';
        }
        if ($lowered === 'offline') {
            return 'آفلاین';
        }
    }

    try {
        if (is_numeric($onlineAt)) {
            $dateTime = new DateTime('@' . intval($onlineAt));
            $dateTime->setTimezone(new DateTimeZone('Asia/Tehran'));
        } else {
            $dateTime = new DateTime((string) $onlineAt, new DateTimeZone('UTC'));
            $dateTime->setTimezone(new DateTimeZone('Asia/Tehran'));
        }
        return jdate('Y/m/d H:i:s', $dateTime->getTimestamp());
    } catch (Exception $e) {
        return (string) $onlineAt;
    }
}
function rx_build_smart_random_username($telegramUsername, $telegramId)
{
    $hasUsername = is_string($telegramUsername) && $telegramUsername !== '' && !in_array(strtolower($telegramUsername), ['not_username', 'none'], true);
    if ($hasUsername) {
        $suffix = str_pad((string) rand(0, 999), 3, '0', STR_PAD_LEFT);
        $base = substr(str_replace('_', '-', strtolower($telegramUsername)), 0, 28);
        return $base . '-' . $suffix;
    }
    $letters = '';
    for ($i = 0; $i < 3; $i++) {
        $letters .= chr(rand(97, 122));
    }
    return 'u' . $telegramId . '-' . $letters;
}

function generateUsername($from_id, $Metode, $username, $randomString, $text, $namecustome, $usernamecustom)
{
    $username = str_replace('_', '-', (string) $username);
    $text = str_replace('_', '-', (string) $text);
    $namecustome = str_replace('_', '-', (string) $namecustome);
    $usernamecustom = str_replace('_', '-', (string) $usernamecustom);
    $setting = select("setting", "*", null, null, "select");
    $user = select("user", "*", "id", $from_id, "select");
    if ($user == false) {
        $user = array();
        $user = array(
            'number_username' => '',
        );
    }
    $telegramUsernameMissing = trim($username) === '' || in_array(strtolower($username), ['not_username', 'not-username', 'none'], true);
    $telegramUsernameBase = $telegramUsernameMissing ? $namecustome : $username;
    if ($telegramUsernameBase === '' || strtolower($telegramUsernameBase) === 'none') {
        $telegramUsernameBase = 'u' . $from_id;
    }
    $panelCustomBase = trim($namecustome) !== '' && strtolower($namecustome) !== 'none' ? $namecustome : 'u' . $from_id;
    $requestedBase = trim($text) !== '' ? $text : $telegramUsernameBase;
    if ($Metode == "آیدی عددی + حروف و عدد رندوم") {
        return $from_id . "-" . $randomString;
    } elseif ($Metode == "نام کاربری + حروف و عدد رندوم") {
        return $telegramUsernameBase . "-" . $randomString;
    } elseif ($Metode == "نام کاربری + عدد به ترتیب") {
        return $telegramUsernameBase . "-" . $user['number_username'];
    } elseif ($Metode == "نام کاربری دلخواه")
        return $requestedBase;
    elseif ($Metode == "نام کاربری دلخواه + عدد رندوم") {
        $random_number = rand(1000000, 9999999);
        return $requestedBase . "-" . $random_number;
    } elseif ($Metode == "متن دلخواه کاربر + رندوم") {
        return $requestedBase;
    } elseif ($Metode == "متن دلخواه + عدد رندوم") {
        return $panelCustomBase . "-" . $randomString;
    } elseif ($Metode == "متن دلخواه + عدد ترتیبی") {
        return $panelCustomBase . "-" . $setting['numbercount'];
    } elseif ($Metode == "آیدی عددی+عدد ترتیبی") {
        return $from_id . "-" . $user['number_username'];
    } elseif ($Metode == "آیدی عددی") {
        return (string) $from_id;
    } elseif ($Metode == "متن دلخواه نماینده + عدد ترتیبی") {
        if (trim($usernamecustom) === '' || strtolower($usernamecustom) === "none") {
            return $panelCustomBase . "-" . $setting['numbercount'];
        }
        return $usernamecustom . "-" . $user['number_username'];
    }
    return $from_id . "-" . $randomString;
}
function outputlunk($text)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $text);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $timeoutInfo = function_exists('faoxima_panel_timeout_info') ? faoxima_panel_timeout_info() : ['timeout' => 20, 'connect_timeout' => 8];
    curl_setopt($ch, CURLOPT_TIMEOUT, (int) $timeoutInfo['timeout']);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, (int) $timeoutInfo['connect_timeout']);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36';
    curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
    $response = curl_exec($ch);
    if ($response === false) {
        $error = curl_error($ch);
        return null;
    } else {
        return $response;
    }

    curl_close($ch);
}
function outputlunksub($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "$url/info");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $timeoutInfo = function_exists('faoxima_panel_timeout_info') ? faoxima_panel_timeout_info() : ['timeout' => 20, 'connect_timeout' => 8];
    curl_setopt($ch, CURLOPT_TIMEOUT, (int) $timeoutInfo['timeout']);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, (int) $timeoutInfo['connect_timeout']);
    $userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36';
    curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);


    $headers = array();
    $headers[] = 'Accept: application/json';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    return $result;
    curl_close($ch);
}
function normalizeServiceConfigs($configs, $subscriptionUrl = null)
{
    $normalized = [];

    if (is_array($configs)) {
        foreach ($configs as $item) {
            if (!is_string($item)) {
                continue;
            }
            $item = trim($item);
            if ($item === '') {
                continue;
            }
            $normalized[] = $item;
        }
    } elseif (is_string($configs)) {
        $parts = preg_split("/\r\n|\n|\r/", $configs);
        if (is_array($parts)) {
            foreach ($parts as $part) {
                $part = trim($part);
                if ($part === '') {
                    continue;
                }
                $normalized[] = $part;
            }
        }
    }

    $subscriptionUrl = is_string($subscriptionUrl) ? trim($subscriptionUrl) : '';
    if (empty($normalized) && $subscriptionUrl !== '') {
        if (preg_match('/^https?:/i', $subscriptionUrl)) {
            $fetched = outputlunk($subscriptionUrl);
            if (is_string($fetched) && $fetched !== '') {
                if (isBase64($fetched)) {
                    $fetched = base64_decode($fetched);
                }
                $parts = preg_split("/\r\n|\n|\r/", $fetched);
                if (is_array($parts)) {
                    foreach ($parts as $part) {
                        $part = trim($part);
                        if ($part === '') {
                            continue;
                        }
                        $normalized[] = $part;
                    }
                }
            }
        } else {
            $normalized[] = $subscriptionUrl;
        }
    }

    return array_values($normalized);
}
if (!function_exists('rxEnsureManagePanel')) {
    function rxEnsureManagePanel()
    {
        global $ManagePanel;

        if (isset($ManagePanel) && is_object($ManagePanel)) {
            return $ManagePanel;
        }

        if (!class_exists('ManagePanel', false)) {
            $rxPanelsFile = REFACTORED_LEGACY_ROOT . '/panels.php';
            if (!is_file($rxPanelsFile)) {
                if (function_exists('rx_log_event')) {
                    rx_log_event('MANAGE_PANEL_UNAVAILABLE', 'panels.php not found', ['path' => $rxPanelsFile]);
                }
                return null;
            }
            $rxPrevErrorLog = ini_get('error_log');
            try {
                require_once $rxPanelsFile;
            } catch (Throwable $e) {
                if (function_exists('rx_log_event')) {
                    rx_log_event('MANAGE_PANEL_UNAVAILABLE', 'Loading panels.php threw', [
                        'class' => get_class($e),
                        'err' => $e->getMessage(),
                        'file' => $e->getFile(),
                        'line' => $e->getLine(),
                    ]);
                }
            }
            if ($rxPrevErrorLog !== false) {
                ini_set('error_log', $rxPrevErrorLog);
            }
        }

        if (!class_exists('ManagePanel', false)) {
            return null;
        }

        try {
            $ManagePanel = new ManagePanel();
        } catch (Throwable $e) {
            if (function_exists('rx_log_event')) {
                rx_log_event('MANAGE_PANEL_UNAVAILABLE', 'ManagePanel construction threw', [
                    'class' => get_class($e),
                    'err' => $e->getMessage(),
                ]);
            }
            return null;
        }

        return $ManagePanel;
    }
}
if (!function_exists('rxEnsurePaymentRuntime')) {
    function rxEnsurePaymentRuntime()
    {
        global $setting, $textbotlang, $datatextbot;

        try {
            if (!is_array($setting) && function_exists('select')) {
                $rxSetting = select("setting", "*");
                if (is_array($rxSetting)) {
                    $setting = $rxSetting;
                }
            }

            if ((!is_array($textbotlang) || $textbotlang === []) && function_exists('languagechange')) {
                $rxLang = languagechange(REFACTORED_LEGACY_ROOT . '/text.json');
                if (is_array($rxLang) && $rxLang !== []) {
                    $textbotlang = $rxLang;
                }
            }

            if (!is_array($datatextbot)) {
                $datatextbot = [];
            }
            $rxMissingKeys = array_diff(['textafterpay', 'textaftertext', 'textmanual', 'textselectlocation', 'text_wgdashboard'], array_keys($datatextbot));
            if ($rxMissingKeys !== []) {
                $rxTextRows = isset($GLOBALS['_rx_textbot_rows']) && is_array($GLOBALS['_rx_textbot_rows'])
                    ? $GLOBALS['_rx_textbot_rows']
                    : (function_exists('select') ? select("textbot", "*", null, null, "fetchAll") : []);
                foreach ($rxMissingKeys as $rxKey) {
                    $datatextbot[$rxKey] = '';
                }
                foreach ((array) $rxTextRows as $rxRow) {
                    $rxId = (string) ($rxRow['id_text'] ?? '');
                    if (in_array($rxId, $rxMissingKeys, true)) {
                        $datatextbot[$rxId] = (string) ($rxRow['text'] ?? '');
                    } elseif ($rxId !== '' && !array_key_exists($rxId, $datatextbot) && trim((string) ($rxRow['text'] ?? '')) !== '') {
                        $datatextbot[$rxId] = (string) $rxRow['text'];
                    }
                }
            }

            if (!function_exists('createServiceInfoCard') && is_file(REFACTORED_LEGACY_ROOT . '/infocard.php')) {
                require_once REFACTORED_LEGACY_ROOT . '/infocard.php';
            }
        } catch (Throwable $e) {
            if (function_exists('rx_log_event')) {
                rx_log_event('PAYMENT_RUNTIME_INIT_FAILED', $e->getMessage(), [
                    'class' => get_class($e),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                ]);
            }
        }
    }
}
function DirectPayment($order_id, $image = 'images.jpg', $rxToken = null)
{
    global $pdo, $ManagePanel, $textbotlang, $keyboardextendfnished, $keyboard, $Confirm_pay, $from_id, $message_id, $datatextbot, $update;
    rxEnsurePaymentRuntime();
    $order_id = (string) $order_id;
    $rxPf = rx_pf_begin($order_id, $rxToken !== null ? (string) $rxToken : null);
    if (empty($rxPf['proceed'])) {
        return $rxPf['result'];
    }
    $rxToken = (string) $rxPf['token'];
    $rxPhase = (string) $rxPf['phase'];
    $rxBeforeState = rx_pf_decode($rxPf['record']['before_state'] ?? null);
    $rxTargetState = rx_pf_decode($rxPf['record']['target_state'] ?? null);
    $buyreport =select("topicid", "idreport", "report", "buyreport", "select")['idreport'];
    $admin_ids = select("admin", "id_admin", null, null, "FETCH_COLUMN");
    $otherservice = select("topicid", "idreport", "report", "otherservice", "select")['idreport'];
    $otherreport = select("topicid", "idreport", "report", "otherreport", "select")['idreport'];
    $errorreport = select("topicid", "idreport", "report", "errorreport", "select")['idreport'];
    $porsantreport = select("topicid", "idreport", "report", "porsantreport", "select")['idreport'];
    $setting = select("setting", "*");
    $Payment_report = select("Payment_report", "*", "id_order", $order_id, "select", ['cache' => false]);
    if (!is_array($Payment_report)) {
        return rx_pf_abort($order_id, $rxToken, 'payment_report_unavailable', true);
    }
    $_receipt_report_chat = trim((string)($Payment_report['report_chat_id'] ?? ''));
    $_receipt_report_msg = (int)($Payment_report['report_message_id'] ?? 0);
    $_receipt_report_thread = (int)($Payment_report['report_thread_id'] ?? 0);
    if ($_receipt_report_chat !== '' && $_receipt_report_msg > 0) {
        $_receipt_chat_id = $_receipt_report_chat;
        $message_id = $_receipt_report_msg;
    } else {
        $_receipt_chat_id = $update['callback_query']['message']['chat']['id'] ?? $from_id;
        $_receipt_report_thread = (int)($update['callback_query']['message']['message_thread_id'] ?? 0);
    }
    $paymentNote = formatPaymentReportNote($Payment_report['dec_not_confirmed'] ?? null);
    $format_price_cart = number_format($Payment_report['price']);
    $Balance_id = select("user", "*", "id", $Payment_report['id_user'], "select");
    $steppay = explode("|", $Payment_report['id_invoice']);
    update("user", "Processing_value", "0", "id", $Balance_id['id']);
    update("user", "Processing_value_one", "0", "id", $Balance_id['id']);
    update("user", "Processing_value_tow", "0", "id", $Balance_id['id']);
    update("user", "Processing_value_four", "0", "id", $Balance_id['id']);
    if ($steppay[0] == "getconfigafterpay") {
        $__invUsername = isset($steppay[1]) ? trim((string)$steppay[1]) : '';
        $__invOwner = trim((string)($Payment_report['id_user'] ?? ''));
        $get_invoice = false;
        $__invLookupError = false;
        if ($__invUsername !== '' && $__invOwner !== '') {
            try {
                $stmt = $pdo->prepare("SELECT * FROM invoice WHERE username = :u AND id_user = :uid AND Status IN ('unpaid', 'Unpaid') ORDER BY id_invoice DESC LIMIT 1");
                $stmt->execute([':u' => $__invUsername, ':uid' => $__invOwner]);
                $get_invoice = $stmt->fetch(PDO::FETCH_ASSOC);
            } catch (Throwable $__e) { $get_invoice = false; $__invLookupError = true; }
            if (!$get_invoice) {
                try {
                    $stmt = $pdo->prepare("SELECT * FROM invoice WHERE LOWER(username) = LOWER(:u) AND id_user = :uid AND Status IN ('unpaid', 'Unpaid') ORDER BY id_invoice DESC LIMIT 1");
                    $stmt->execute([':u' => $__invUsername, ':uid' => $__invOwner]);
                    $get_invoice = $stmt->fetch(PDO::FETCH_ASSOC);
                } catch (Throwable $__e) { $get_invoice = false; $__invLookupError = true; }
            }
        }
        // اگه با هیچ روشی پیدا نشد، قبل از اینکه به refund برسیم به ادمین گزارش بدیم و مستقیم برگردیم
        if (!$get_invoice && $__invLookupError) {
            if (function_exists('error_log')) {
                @error_log("[DirectPayment] invoice lookup error for order={$order_id} user={$Balance_id['id']} steppay[1]={$__invUsername} — retryable");
            }
            return rx_pf_abort($order_id, $rxToken, 'invoice_lookup_error', true);
        }
        if (!$get_invoice) {
            if (function_exists('error_log')) {
                @error_log("[DirectPayment] invoice NOT FOUND for order={$order_id} user={$Balance_id['id']} steppay[1]={$__invUsername} — aborting WITHOUT refund (so cryptocheck stuck-refund can handle it cleanly)");
            }
            $__setting = function_exists('select') ? select('setting', '*', null, null, 'select') : [];
            $__errReport = function_exists('select') ? (select('topicid', 'idreport', 'report', 'errorreport', 'select')['idreport'] ?? null) : null;
            $__txt = "⚠️ <b>فاکتور پیدا نشد برای ساخت سرویس</b>\n"
                   . "<blockquote>🛒 کد سفارش: <code>{$order_id}</code></blockquote>\n"
                   . "<blockquote>👤 کاربر: <code>{$Balance_id['id']}</code></blockquote>\n"
                   . "<blockquote>🔎 username موردنظر: <code>" . htmlspecialchars($__invUsername) . "</code></blockquote>\n"
                   . "ℹ️ DirectPayment بدون refund برگشت — لطفاً دستی بررسی کنید.";
            if (!empty($__setting['Channel_Report']) && function_exists('telegram')) {
                @telegram('sendmessage', [
                    'chat_id' => $__setting['Channel_Report'],
                    'message_thread_id' => $__errReport,
                    'text' => $__txt,
                    'parse_mode' => 'HTML',
                ]);
            }
            return rx_pf_abort($order_id, $rxToken, 'invoice_not_found', false);
        }
        $userAgent = $Balance_id['agent'] ?? 'f';
        $stmt = $pdo->prepare("SELECT * FROM product WHERE name_product = :name AND (FIND_IN_SET(:loc, Location) > 0 OR Location = '/all') AND (FIND_IN_SET(:agent, REPLACE(agent, ' ', '')) > 0 OR agent IN ('all', 'allusers'))");
        $stmt->execute([':name' => $get_invoice['name_product'], ':loc' => $get_invoice['Service_location'], ':agent' => $userAgent]);
        $info_product = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($get_invoice['name_product'] == "🛍 حجم دلخواه" || $get_invoice['name_product'] == "⚙️ سرویس دلخواه") {
            $info_product['data_limit_reset'] = "no_reset";
            $info_product['Volume_constraint'] = $get_invoice['Volume'];
            $info_product['name_product'] = $textbotlang['users']['customsellvolume']['title'];
            $info_product['code_product'] = "customvolume";
            $info_product['Service_time'] = $get_invoice['Service_time'];
            $info_product['price_product'] = $get_invoice['price_product'];
        } else {
            $stmt = $pdo->prepare("SELECT * FROM product WHERE name_product = :name AND (FIND_IN_SET(:loc, Location) > 0 OR Location = '/all') AND (FIND_IN_SET(:agent, REPLACE(agent, ' ', '')) > 0 OR agent IN ('all', 'allusers'))");
            $stmt->execute([':name' => $get_invoice['name_product'], ':loc' => $get_invoice['Service_location'], ':agent' => $userAgent]);
            $info_product = $stmt->fetch(PDO::FETCH_ASSOC);
        }
        $username_ac = $get_invoice['username'];
        $randomString = bin2hex(random_bytes(2));
        $marzban_list_get = select("marzban_panel", "*", "name_panel", $get_invoice['Service_location'], "select");

        // [panel-missing guard] اگه پنل پیدا نشد، اصلاً نباید بریم سراغ createUser چون قطعاً "Panel Not Found" برمی‌گردونه.
        // قبل از refund، به ادمین گزارش بدیم تا دلیل واقعی (مثلاً پنل حذف شده، نام عوض شده، Service_location خراب) مشخص بشه.
        if (!is_array($marzban_list_get) || empty($marzban_list_get['name_panel'])) {
            if (function_exists('error_log')) {
                @error_log("[DirectPayment] panel missing for order={$order_id} user={$Balance_id['id']} location='" . (string)($get_invoice['Service_location'] ?? '') . "' invoice={$get_invoice['id_invoice']} — aborting WITHOUT refund");
            }
            $__setting2 = function_exists('select') ? select('setting', '*', null, null, 'select') : [];
            $__errReport2 = function_exists('select') ? (select('topicid', 'idreport', 'report', 'errorreport', 'select')['idreport'] ?? null) : null;
            $__txt2 = "⚠️ <b>پنل برای ساخت سرویس پیدا نشد</b>\n"
                    . "<blockquote>🛒 کد سفارش: <code>{$order_id}</code></blockquote>\n"
                    . "<blockquote>👤 کاربر: <code>{$Balance_id['id']}</code></blockquote>\n"
                    . "<blockquote>📍 لوکیشن ذخیره‌شده در فاکتور: <code>" . htmlspecialchars((string)($get_invoice['Service_location'] ?? '')) . "</code></blockquote>\n"
                    . "<blockquote>🧾 شناسه فاکتور: <code>{$get_invoice['id_invoice']}</code></blockquote>\n"
                    . "ℹ️ DirectPayment بدون refund برگشت — لطفاً پنل را در دیتابیس بررسی کنید.";
            if (!empty($__setting2['Channel_Report']) && function_exists('telegram')) {
                @telegram('sendmessage', [
                    'chat_id' => $__setting2['Channel_Report'],
                    'message_thread_id' => $__errReport2,
                    'text' => $__txt2,
                    'parse_mode' => 'HTML',
                ]);
            }
            return rx_pf_abort($order_id, $rxToken, 'panel_not_found', true);
        }

        // [idempotent-refund guard] اگر این فاکتور قبلاً refund خورده (نشانه auto-refund تو dec_not_confirmed)،
        // دیگه نباید دوباره کیف پول رو شارژ کنیم — همینجا برمی‌گردیم و فقط لاگ می‌زنیم.
        // این جلوی double/triple-credit موقع retry گیر کردن سرویس رو می‌گیره.
        $__alreadyRefunded = false;
        try {
            $__pr = select("Payment_report", "dec_not_confirmed", "id_order", $order_id, "select");
            $__decNote = is_array($__pr) ? (string)($__pr['dec_not_confirmed'] ?? '') : '';
            if ($__decNote !== '' && stripos($__decNote, 'auto-refund') !== false) {
                $__alreadyRefunded = true;
            }
        } catch (Throwable $__e) { $__alreadyRefunded = false; }
        if ($__alreadyRefunded) {
            return rx_pf_abort($order_id, $rxToken, 'already_refunded', false);
        }

        // [username normalize] اگر یوزرنیم فاکتور خالی/کوتاه‌تر از 3 کاراکتر بود، یکی معتبر بساز.
        // این از خطای پنل "Username must be at least 3 characters long" جلوگیری می‌کنه.
        if (!is_string($username_ac) || trim($username_ac) === '' || strlen(trim($username_ac)) < 3) {
            if ($rxPhase === 'reconcile') {
                return rx_pf_manual_review($order_id, $rxToken, 'buy_username_changed_during_reconciliation', ['username' => (string) $username_ac]);
            }
            $username_ac = preg_replace('/[^A-Za-z0-9-]/', '', str_replace('_', '-', (string)$Balance_id['id'])) . '-' . bin2hex(random_bytes(4));
            if (strlen($username_ac) < 3) $username_ac = 'u' . bin2hex(random_bytes(4));
            // فقط وقتی id_invoice معتبره update کن (جلوی خطای "Column id_invoice cannot be null" گرفته میشه)
            if (!empty($get_invoice['id_invoice'])) {
                try { update("invoice", "username", $username_ac, "id_invoice", $get_invoice['id_invoice']); } catch (Throwable $__e) { /* fail-open */ }
                try { update("Payment_report", "id_invoice", "getconfigafterpay|" . $username_ac, "id_order", $order_id); } catch (Throwable $__e) {}
            }
        }

        // [duplicate-username guard - REMOVED]
        // پچ قبلی یک حلقه pre-check با DataUser داشت که باعث می‌شد:
        //   - چندین API call به panel قبل از createUser → کند و گاهی timeout
        //   - اگر createUser قبلی نیمه‌کاره موفق بوده (yوزر ساخته شده ولی bot جواب نگرفته)، DataUser می‌گفت "exists" و یوزرنیم عوض می‌شد
        //   - هر retry یوزرنیم جدید → چندین یوزر زامبی توی پنل + سرویس نهایی هیچ‌وقت تحویل نشد
        // الان فقط روی duplicate-error واقعی از createUser (در پایین) retry می‌کنیم، که هم سریع‌تر و هم دقیق‌تره.
        // این رفتار همون چیزیه که در wallet-payment موفق عمل می‌کنه.
        $date = strtotime("+" . $get_invoice['Service_time'] . "days");
        if (intval($get_invoice['Service_time']) == 0) {
            $timestamp = 0;
        } else {
            $timestamp = strtotime(date("Y-m-d H:i:s", $date));
        }
        $datac = array(
            'expire' => $timestamp,
            'data_limit' => $get_invoice['Volume'] * pow(1024, 3),
            'from_id' => $Balance_id['id'],
            'username' => $Balance_id['username'],
            'type' => 'buy'
        );
        if (function_exists('nmPanelNationalEnabled') && nmPanelNationalEnabled($marzban_list_get)) {
            if ($rxPhase === 'reconcile') {
                return rx_pf_manual_review($order_id, $rxToken, 'national_stock_buy_unverifiable', ['username' => (string) $username_ac]);
            }
            if (!rx_pf_prepare($order_id, $rxToken, null, ['national_stock' => true, 'username' => (string) $username_ac])) {
                return rx_pf_abort($order_id, $rxToken, 'fulfillment_prepare_failed', true);
            }
            if (is_array($info_product) && nmStockCompleteBuyFromInventory($Balance_id['id'], $Balance_id, $marzban_list_get, $info_product, $get_invoice['id_invoice'], $username_ac, false, 'paid_national_buy')) {
                $rxCompletion = rx_pf_complete($order_id, $rxToken, ['national_stock' => true, 'username' => (string) $username_ac]);
                if ($rxCompletion !== 'completed') {
                    return rx_pf_completion_outcome($order_id, $rxToken, $rxCompletion);
                }
                sendmessage($Balance_id['id'], $textbotlang['users']['selectoption'], $keyboard, 'HTML');
                return rx_pf_result('completed', 'national_stock');
            }
            $__refundNs = rx_refund_payment_once($order_id, $Balance_id['id'], $Payment_report['price'], 'بازگشت وجه - موجودی انبار ملی تمام شده', (string)$get_invoice['id_invoice']);
            if ($__refundNs === 'refunded') {
                sendmessage($Balance_id['id'], "❌ وضعیت نت ملی فعال است اما موجودی انبار برای این محصول تمام شده است. مبلغ پرداختی به کیف پول برگشت خورد.", $keyboard, 'HTML');
            } elseif ($__refundNs === 'failed') {
                sendmessage($Balance_id['id'], "❌ موجودی انبار برای این محصول تمام شده است. بازگشت وجه با خطا مواجه شد؛ لطفاً با پشتیبانی در ارتباط باشید.", $keyboard, 'HTML');
            }
            return rx_pf_fail($order_id, $rxToken, 'national_stock_empty', $__refundNs);
        }
        // [zombie-rescue] قبل از تلاش جدید، اگه قبلاً تو panel یوزری برای این کاربر ساخته شده (zombie)،
        // اول بررسی کن: شاید createUser تو call قبلی موفق بوده فقط response نرسیده. اگه پیدا کردیم،
        // از همون استفاده کن (بدون ساختن یوزر جدید) — این جلوی تولید بیشتر zombie رو می‌گیره.
        $ManagePanel = rxEnsureManagePanel();
        if (!is_object($ManagePanel)) {
            if (function_exists('rx_log_event')) {
                rx_log_event('DIRECT_PAYMENT_NO_MANAGE_PANEL', 'ManagePanel unavailable; buy aborted without side effects', ['id_order' => $order_id]);
            }
            return rx_pf_abort($order_id, $rxToken, 'manage_panel_unavailable', true);
        }
        $rxReconcilable = rx_pf_panel_reconcilable($marzban_list_get);
        $rxAllowRename = true;
        $__isRetryCall = false;
        $dataoutput = null;
        if ($rxPhase === 'reconcile') {
            $rxExpectedUser = is_array($rxTargetState) ? (string) ($rxTargetState['username'] ?? '') : '';
            if (!$rxReconcilable || !is_array($rxBeforeState) || ($rxBeforeState['exists'] ?? null) !== false || $rxExpectedUser === '' || $rxExpectedUser !== (string) $username_ac) {
                return rx_pf_manual_review($order_id, $rxToken, 'buy_result_unverifiable', ['username' => (string) $username_ac]);
            }
            $rxSnap = rx_pf_panel_snapshot($ManagePanel, (string) $marzban_list_get['name_panel'], (string) $username_ac);
            if (empty($rxSnap['ok'])) {
                return rx_pf_defer($order_id, $rxToken, 'buy_panel_read_failed: ' . (string) ($rxSnap['error'] ?? ''));
            }
            if (!empty($rxSnap['exists'])) {
                $dataoutput = rx_pf_adopt_created($rxSnap['raw']);
            } elseif (!rx_pf_mark_applying($order_id, $rxToken)) {
                return rx_pf_result('already_processing', 'ownership_lost');
            } else {
                $rxAllowRename = false;
            }
        } else {
            $rxBeforeState = ['username' => (string) $username_ac, 'exists' => null];
            if ($rxReconcilable) {
                $rxSnap = rx_pf_panel_snapshot($ManagePanel, (string) $marzban_list_get['name_panel'], (string) $username_ac);
                if (empty($rxSnap['ok'])) {
                    return rx_pf_abort($order_id, $rxToken, 'buy_panel_read_failed', true);
                }
                $rxBeforeState['exists'] = !empty($rxSnap['exists']);
            }
            $rxTargetState = ['username' => (string) $username_ac, 'panel' => (string) $marzban_list_get['name_panel']];
            if (!rx_pf_prepare($order_id, $rxToken, $rxBeforeState, $rxTargetState)) {
                return rx_pf_abort($order_id, $rxToken, 'fulfillment_prepare_failed', true);
            }
            try {
                $__pr2 = select("Payment_report", "crypto_check_count", "id_order", $order_id, "select");
                $__cnt = is_array($__pr2) ? (int)($__pr2['crypto_check_count'] ?? 0) : 0;
                if ($__cnt >= 1) $__isRetryCall = true;
            } catch (Throwable $__e) { /* ignore */ }
        }

        if ($__isRetryCall) {
            // در حالت retry، اول چک کن یوزر در پنل وجود داره یا نه (با همون username فاکتور)
            try {
                $__zombieCheck = $ManagePanel->DataUser($marzban_list_get['name_panel'], $username_ac);
                if (is_array($__zombieCheck) && !empty($__zombieCheck['username']) && (string)$__zombieCheck['username'] === (string)$username_ac) {
                    // یوزر تو پنل هست! یعنی createUser قبلی واقعاً موفق بوده، فقط bot جواب نگرفته.
                    // از همون استفاده کن.
                    $dataoutput = $__zombieCheck;
                    $dataoutput['status'] = 'successful';
                    if (empty($dataoutput['configs']) && !empty($dataoutput['links'])) {
                        $dataoutput['configs'] = is_array($dataoutput['links']) ? $dataoutput['links'] : explode("\n", (string)$dataoutput['links']);
                    }
                }
            } catch (Throwable $__e) { /* fail-open */ }
        }

        if (empty($dataoutput) || empty($dataoutput['username'])) {
            try {
                $dataoutput = $ManagePanel->createUser($marzban_list_get['name_panel'], $info_product['code_product'], $username_ac, $datac, $rxAllowRename);
            } catch (Throwable $rxPanelError) {
                return rx_pf_reconcile_later($order_id, $rxToken, 'buy_panel_exception: ' . $rxPanelError->getMessage());
            }
            if (!empty($dataoutput['renamed_from'])) {
                $username_ac = rx_adopt_created_username($dataoutput, $username_ac, $get_invoice['id_invoice'] ?? null);
                try { update("Payment_report", "id_invoice", "getconfigafterpay|" . $username_ac, "id_order", $order_id); } catch (Throwable $__e2) {}
                rx_notify_username_renamed($Balance_id['id'], $dataoutput, $marzban_list_get);
            }
        }
        if (empty($dataoutput['username']) && $rxReconcilable && is_array($rxBeforeState) && ($rxBeforeState['exists'] ?? null) === false) {
            $rxSnap = rx_pf_panel_snapshot($ManagePanel, (string) $marzban_list_get['name_panel'], (string) $username_ac);
            if (empty($rxSnap['ok'])) {
                return rx_pf_reconcile_later($order_id, $rxToken, 'buy_result_unknown: ' . (string) ($rxSnap['error'] ?? ''));
            }
            if (!empty($rxSnap['exists'])) {
                $dataoutput = rx_pf_adopt_created($rxSnap['raw']);
            }
        }
        if ($dataoutput['username'] == null) {
            $dataoutput['msg'] = rx_panel_error_text($dataoutput['msg'] ?? null, $dataoutput['detail'] ?? null);
            $__refundCu = rx_refund_payment_once($order_id, $Balance_id['id'], $Payment_report['price'], 'بازگشت وجه - خطا در ساخت سرویس', (string)$get_invoice['id_invoice']);
            if ($__refundCu === 'duplicate') {
                return rx_pf_fail($order_id, $rxToken, 'create_failed', $__refundCu);
            }
            // پیام UI fallback اگه textbotlang در دسترس نباشه (مثلاً وقتی از cron صدا زده میشه)
            $__uiErr = isset($textbotlang['users']['sell']['ErrorConfig']) && is_string($textbotlang['users']['sell']['ErrorConfig']) && trim($textbotlang['users']['sell']['ErrorConfig']) !== ''
                ? $textbotlang['users']['sell']['ErrorConfig']
                : "❌ متاسفانه ساخت سرویس با خطا مواجه شد. مبلغ پرداختی به کیف پول شما برگشت داده شد.";
            if ($__refundCu === 'refunded') {
                sendmessage($Balance_id['id'], $__uiErr, $keyboard, 'HTML');
                sendmessage($Balance_id['id'], "💎  کاربر عزیز بدلیل ساخته نشدن سرویس مبلغ " . rxFormatToman($Payment_report['price']) . " تومان به کیف پول شما اضافه گردید.", $keyboard, 'HTML');
            } else {
                sendmessage($Balance_id['id'], "❌ ساخت سرویس با خطا مواجه شد و بازگشت وجه نیز انجام نشد؛ لطفاً با پشتیبانی در ارتباط باشید.", $keyboard, 'HTML');
            }
            $texterros = "
⭕️ خطا در ساخت کانفیگ
<blockquote>✍️ دلیل خطا : {$dataoutput['msg']}</blockquote>
<blockquote>آیدی کابر : {$Balance_id['id']}</blockquote>
<blockquote>نام کاربری کاربر : @{$Balance_id['username']}</blockquote>
<blockquote>نام پنل : {$marzban_list_get['name_panel']}</blockquote>";
            if (strlen($setting['Channel_Report']) > 0) {
                telegram('sendmessage', [
                    'chat_id' => $setting['Channel_Report'],
                    'message_thread_id' => $errorreport,
                    'text' => $texterros,
                    'parse_mode' => "HTML"
                ]);
            }
            return rx_pf_fail($order_id, $rxToken, 'create_failed', $__refundCu);
        }
        $__walletPortion = (float)$get_invoice['price_product'] - (float)($Payment_report['price'] ?? 0);
        if ($__walletPortion < 0) {
            $__walletPortion = 0;
        }
        $Balance_prims = (float)$Balance_id['Balance'] - $__walletPortion;
        if ($Balance_prims <= 0) {
            $Balance_prims = 0;
        }
        // [CRITICAL: mark invoice active EARLY]
        // اگه createUser موفق بوده، همین الان قبل از هر sendmessage/QR code generation/الخ که ممکنه hang کنه،
        // invoice رو active علامت بزن. این جلوی retry بعدی توسط cron رو می‌گیره حتی اگه پیام تلگرام hang کنه.
        $__doneNote = '[service-created at ' . date('Y-m-d H:i:s') . ' username=' . $dataoutput['username'] . ']';
        $rxStatements = [
            ["UPDATE user SET Balance = GREATEST(Balance - ?, 0) WHERE id = ?", [$__walletPortion, $Balance_id['id']]],
            ["UPDATE Payment_report SET dec_not_confirmed = CASE WHEN dec_not_confirmed IS NULL OR dec_not_confirmed = '' THEN ? ELSE CONCAT(dec_not_confirmed, ' | ', ?) END WHERE id_order = ?", [$__doneNote, $__doneNote, $order_id]],
        ];
        if (!empty($get_invoice['id_invoice'])) {
            $rxStatements[] = ["UPDATE invoice SET Status = 'active' WHERE id_invoice = ?", [$get_invoice['id_invoice']]];
        }
        $rxCompletion = rx_pf_complete($order_id, $rxToken, ['username' => (string) $dataoutput['username'], 'renamed_from' => $dataoutput['renamed_from'] ?? null], $rxStatements);
        if ($rxCompletion !== 'completed') {
            return rx_pf_completion_outcome($order_id, $rxToken, $rxCompletion);
        }
        $Shoppinginfo = json_encode([
            'inline_keyboard' => [
                [
                    ['text' => "📚 مشاهده آموزش استفاده ", 'callback_data' => "helpbtn"],
                ]
            ]
        ]);
        $output_config_link = "";
        $config = "";
        if ($marzban_list_get['config'] == "onconfig" && is_array($dataoutput['configs'])) {
            foreach ($dataoutput['configs'] as $link) {
                $config .= "\n" . $link;
            }
        }
        $output_config_link = $marzban_list_get['sublink'] == "onsublink" ? rxResolveConnectionLink($marzban_list_get, $dataoutput['subscription_url'], $dataoutput['file_ext'] ?? null) : "";
        $rxAfterPayTpl = $marzban_list_get['type'] == "Manualsale" ? $datatextbot['textmanual'] : $datatextbot['textafterpay'];
        $rxAfterPayTpl = $marzban_list_get['type'] == "WGDashboard" ? $datatextbot['text_wgdashboard'] : $rxAfterPayTpl;
        if (intval($get_invoice['Service_time']) == 0)
            $get_invoice['Service_time'] = $textbotlang['users']['stateus']['Unlimited'];
        if (intval($get_invoice['Volume']) == 0)
            $get_invoice['Volume'] = $textbotlang['users']['stateus']['Unlimited'];
        $textcreatuser = str_replace('{username}', "<code>" . guardDisplayUsername($dataoutput['username'], $marzban_list_get) . "</code>", $rxAfterPayTpl);
        $textcreatuser = str_replace('{name_service}', $get_invoice['name_product'], $textcreatuser);
        $textcreatuser = str_replace('{location}', $marzban_list_get['name_panel'], $textcreatuser);
        $textcreatuser = str_replace('{day}', $get_invoice['Service_time'], $textcreatuser);
        $textcreatuser = str_replace('{volume}', $get_invoice['Volume'], $textcreatuser);
        $textcreatuser = applyConnectionPlaceholders($textcreatuser, $output_config_link, $config);
        if (intval($get_invoice['Volume']) == 0) {
            $textcreatuser = str_replace('گیگابایت', "", $textcreatuser);
        }
        if ($marzban_list_get['type'] == "Manualsale") {
            $textcreatuser = str_replace('{password}', $dataoutput['subscription_url'], $textcreatuser);
            update("invoice", "user_info", $dataoutput['subscription_url'], "id_invoice", $get_invoice['id_invoice']);
        }
        sendMessageService($marzban_list_get, $dataoutput['configs'], $output_config_link, $dataoutput['username'], $Shoppinginfo, $textcreatuser, $get_invoice['id_invoice'], $get_invoice['id_user'], $image);
        $partsdic = explode("_", $Balance_id['Processing_value_four']);
        if ($partsdic[0] == "dis") {
            $SellDiscountlimit = select("DiscountSell", "*", "codeDiscount", $partsdic[1], "select");
            $value = intval($SellDiscountlimit['usedDiscount']) + 1;
            update("DiscountSell", "usedDiscount", $value, "codeDiscount", $partsdic[1]);
            $stmt = $pdo->prepare("INSERT INTO Giftcodeconsumed (id_user,code) VALUES (:id_user,:code)");
            $stmt->bindParam(':id_user', $Balance_id['id']);
            $stmt->bindParam(':code', $partsdic[1]);
            $stmt->execute();
            $text_report = "⭕️ یک کاربر با نام کاربری @{$Balance_id['username']}  و آیدی عددی {$Balance_id['id']} از کد تخفیف {$partsdic[1]} استفاده کرد.";
            if (strlen($setting['Channel_Report']) > 0) {
                telegram('sendmessage', [
                    'chat_id' => $setting['Channel_Report'],
                    'parse_mode' => 'HTML',
                    'message_thread_id' => $otherreport,
                    'text' => $text_report,
                ]);
            }
        }
        $affiliateCommissionPaid = payAffiliateCommissionForPurchase($Balance_id['id'], $Balance_id['affiliates'] ?? null, (float) $Payment_report['price']);
        if ($affiliateCommissionPaid !== null) {
            $result = number_format($affiliateCommissionPaid);
            $dateacc = date('Y/m/d H:i:s');
            $textadd = faoxima_render_text(faoxima_textbot_get('dyn_purchase_affiliate_commission_user_tpl', "🎁  پرداخت پورسانت

        مبلغ {amount} تومان به حساب شما از طرف  زیر مجموعه تان به کیف پول شما واریز گردید"), ['amount' => $result]);
            $textreportport = "
مبلغ $result به کاربر {$Balance_id['affiliates']} برای پورسانت از کاربر {$Balance_id['id']} واریز گردید
<blockquote>تایم : $dateacc</blockquote>";
            if (strlen($setting['Channel_Report']) > 0) {
                telegram('sendmessage', [
                    'chat_id' => $setting['Channel_Report'],
                    'message_thread_id' => $porsantreport,
                    'text' => $textreportport,
                    'parse_mode' => "HTML"
                ]);
            }
            sendmessage($Balance_id['affiliates'], $textadd, null, 'HTML');
        }
        if ($marzban_list_get['MethodUsername'] == "متن دلخواه + عدد ترتیبی" || $marzban_list_get['MethodUsername'] == "نام کاربری + عدد به ترتیب" || $marzban_list_get['MethodUsername'] == "آیدی عددی+عدد ترتیبی" || $marzban_list_get['MethodUsername'] == "متن دلخواه نماینده + عدد ترتیبی") {
            $value = intval($Balance_id['number_username']) + 1;
            update("user", "number_username", $value, "id", $Balance_id['id']);
            if ($marzban_list_get['MethodUsername'] == "متن دلخواه + عدد ترتیبی" || $marzban_list_get['MethodUsername'] == "متن دلخواه نماینده + عدد ترتیبی") {
                $value = intval($setting['numbercount']) + 1;
                update("setting", "numbercount", $value);
            }
        }
        $balanceformatsell = select("user", "Balance", "id", $get_invoice['id_user'], "select")['Balance'];
        $balanceformatsell = number_format($balanceformatsell, 0);
        $balancebefore = number_format($Balance_id['Balance'], 0);
        $rxFmtInvoicePriceProduct = rxFormatToman($get_invoice['price_product']);
        $rxFmtPaymentReportPrice = rxFormatToman($Payment_report['price']);
        $timejalali = jdate('Y/m/d H:i:s');
        $textonebuy = "";
        if ($countinvoice == 1) {
            $textonebuy = faoxima_textbot_get('dyn_purchase_first_buy_flag', "📌 خرید اول کاربر");
        }
        // [fallback] اگه textbotlang در cron context کامل لود نشده، text رو با مقدار default پر کن تا تلگرام reject نکنه
        $__mngBtnText = '👤 مدیریت کاربر';
        if (isset($textbotlang['Admin']['ManageUser']['mangebtnuser']) && is_string($textbotlang['Admin']['ManageUser']['mangebtnuser']) && trim($textbotlang['Admin']['ManageUser']['mangebtnuser']) !== '') {
            $__mngBtnText = $textbotlang['Admin']['ManageUser']['mangebtnuser'];
        }
        $Response = json_encode([
            'inline_keyboard' => [
                [
                    ['text' => $__mngBtnText, 'callback_data' => 'manageuser_' . $Balance_id['id']],
                ],
            ]
        ]);
        $text_report = "📣 جزئیات ساخت اکانت در ربات بعد پرداخت ثبت شد .

$textonebuy
<blockquote>▫️آیدی عددی کاربر : <code>{$Balance_id['id']}</code></blockquote>
<blockquote>▫️نام کاربری کاربر :@{$Balance_id['username']}</blockquote>
<blockquote>▫️نام کاربری کانفیگ :" . guardDisplayUsername($username_ac, $marzban_list_get) . "</blockquote>
<blockquote>▫️لوکیشن سرویس : {$get_invoice['Service_location']}</blockquote>
<blockquote>▫️زمان خریداری شده :{$get_invoice['Service_time']} روز</blockquote>
<blockquote>▫️نام محصول خریداری شده :{$get_invoice['name_product']}</blockquote>
<blockquote>▫️حجم خریداری شده : {$get_invoice['Volume']} GB</blockquote>
<blockquote>▫️موجودی قبل خرید : $balancebefore تومان</blockquote>
<blockquote>▫️موجودی بعد خرید : $balanceformatsell تومان</blockquote>
<blockquote>▫️کد پیگیری: {$get_invoice['id_invoice']}</blockquote>
<blockquote>▫️نوع کاربر : {$Balance_id['agent']}</blockquote>
<blockquote>▫️شماره تلفن کاربر : {$Balance_id['number']}</blockquote>
<blockquote>▫️قیمت محصول : {$rxFmtInvoicePriceProduct} تومان</blockquote>
<blockquote>▫️قیمت نهایی : {$rxFmtPaymentReportPrice} تومان</blockquote>
<blockquote>▫️زمان خرید : $timejalali</blockquote>";
        if (strlen($setting['Channel_Report']) > 0) {
            rx_sendTopicReport([
                'chat_id' => $setting['Channel_Report'],
                'message_thread_id' => $buyreport,
                'text' => $text_report,
                'parse_mode' => "HTML",
                'reply_markup' => $Response
            ], ['flow' => 'direct_payment', 'order_id' => (string) ($get_invoice['id_invoice'] ?? ''), 'user_id' => (string) ($Balance_id['id'] ?? '')]);
        }
        if (function_exists('faoxima_public_purchase_log_event')) {
            faoxima_public_purchase_log_event('new_sub', [
                'user_id'    => $Balance_id['id'],
                'amount'     => $get_invoice['name_product'],
                'price'      => number_format((float)$Payment_report['price']),
                'panel_name' => $marzban_list_get['name_panel'] ?? '',
                'category'   => $info_product['category'] ?? '',
            ], $setting);
        }
        if (intval($setting['scorestatus']) == 1 and !in_array($Balance_id['id'], $admin_ids)) {
            sendmessage($Balance_id['id'], faoxima_textbot_get('dyn_purchase_score_earned_1', "📌شما 1 امتیاز جدید کسب کردید."), null, 'html');
            $scorenew = $Balance_id['score'] + 1;
            update("user", "score", $scorenew, "id", $Balance_id['id']);
        }
        update("invoice", "Status", "active", "username", $get_invoice['username']);
        if ($Payment_report['Payment_Method'] == "cart to cart" or $Payment_report['Payment_Method'] == "arze digital offline") {
            update("invoice", "Status", "active", "id_invoice", $get_invoice['id_invoice']);
            $rxFmtBalanceBeforeBuy = rxFormatToman($Balance_id['Balance']);
            $textconfrom = "✅ پرداخت تایید شده
🛍خرید سرویس
▫️نام کاربری کانفیگ :" . guardDisplayUsername($username_ac, $marzban_list_get) . "
▫️لوکیشن سرویس : {$get_invoice['Service_location']}
👤 شناسه کاربر: <code>{$Balance_id['id']}</code>
🛒 کد پیگیری پرداخت: {$Payment_report['id_order']}
⚜️ نام کاربری: @{$Balance_id['username']}
💎 موجودی قبل خرید  : {$rxFmtBalanceBeforeBuy}
💸 مبلغ پرداختی: $format_price_cart تومان
✍️ توضیحات : {$paymentNote}

";
            Editmessagetext($_receipt_chat_id, $message_id, $textconfrom, $Confirm_pay, 'HTML', $_receipt_report_thread > 0 ? $_receipt_report_thread : null);
        }
    } elseif ($steppay[0] == "getextenduser") {
        $balanceformatsell = number_format(select("user", "Balance", "id", $Balance_id['id'], "select")['Balance'], 0);
        $partsdic = explode("%", $steppay[1]);
        $usernamepanel = $partsdic[0];
        $sql = "SELECT * FROM service_other WHERE username = :username  AND value  LIKE CONCAT('%', :value, '%') AND id_user = :id_user ";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':username', $usernamepanel, PDO::PARAM_STR);
        $stmt->bindParam(':value', $partsdic[1], PDO::PARAM_STR);
        $stmt->bindParam(':id_user', $Balance_id['id']);
        $stmt->execute();
        $data_order = $stmt->fetch(PDO::FETCH_ASSOC);
        $service_other = $data_order;
        if ($service_other == false) {
            sendmessage($Balance_id['id'], '❌ خطایی در هنگام تمدید رخ داده با پشتیبانی در ارتباط باشید', $keyboard, 'HTML');
            return rx_pf_abort($order_id, $rxToken, 'renewal_service_other_not_found', true);
        }
        $service_other = json_decode($service_other['value'], true);
        $codeproduct = rxRenewalNormalizeProductCode($service_other['code_product'] ?? '');
        $rxReservationSel = is_array($service_other['reservation'] ?? null) ? $service_other['reservation'] : [];
        $nameloc = false;
        try {
            $rxInvoiceStmt = $pdo->prepare("SELECT * FROM invoice WHERE username = :username AND id_user = :id_user ORDER BY time_sell DESC LIMIT 1");
            $rxInvoiceStmt->execute([':username' => $usernamepanel, ':id_user' => $Balance_id['id']]);
            $nameloc = $rxInvoiceStmt->fetch(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            $nameloc = false;
        }
        if (!is_array($nameloc)) {
            $nameloc = select("invoice", "*", "username", $usernamepanel, "select");
        }
        $marzban_list_get = select("marzban_panel", "*", "name_panel", $nameloc['Service_location'], "select");
        if ($codeproduct == "custom_volume") {
            $prodcut['code_product'] = "custom_volume";
            $prodcut['name_product'] = $nameloc['name_product'];
            $prodcut['price_product'] = $data_order['price'];
            $prodcut['Service_time'] = $service_other['Service_time'];
            $prodcut['Volume_constraint'] = $service_other['volumebuy'];
        } else {
            $stmt = $pdo->prepare("SELECT * FROM product WHERE (FIND_IN_SET(:loc, Location) > 0 OR Location = '/all') AND (agent = '{$Balance_id['agent']}' OR agent = 'all') AND code_product = '$codeproduct'");
            $stmt->execute([':loc' => (string) $nameloc['Service_location']]);
            $prodcut = $stmt->fetch(PDO::FETCH_ASSOC);
        }
        if (!is_array($prodcut)) {
            $__refundPr = rx_refund_payment_once($Payment_report['id_order'], $Balance_id['id'], $Payment_report['price'], 'بازگشت وجه - محصول تمدید در دسترس نیست', (string)($nameloc['id_invoice'] ?? ''));
            if ($__refundPr === 'refunded') {
                sendmessage($Balance_id['id'], "❌ محصول این تمدید دیگر در دسترس نیست؛ مبلغ پرداختی به کیف پول شما بازگردانده شد.", $keyboard, 'HTML');
            } elseif ($__refundPr === 'failed') {
                sendmessage($Balance_id['id'], "❌ محصول این تمدید دیگر در دسترس نیست و بازگشت وجه با خطا مواجه شد؛ لطفاً با پشتیبانی در ارتباط باشید.", $keyboard, 'HTML');
            }
            return rx_pf_fail($order_id, $rxToken, 'renewal_product_unavailable', $__refundPr);
        }
        $fxOrderValue = json_decode((string) ($data_order['value'] ?? ''), true);
        if (is_array($fxOrderValue) && isset($fxOrderValue['pricing_snapshot']) && is_numeric($data_order['price'] ?? null)) {
            $prodcut['price_product'] = $data_order['price'];
        }
        $rxWasTestService = $nameloc['name_product'] == "سرویس تست";
        $dateacc = date('Y/m/d H:i:s');
        $rxStatements = [];
        if (function_exists('nmPanelNationalEnabled') && nmPanelNationalEnabled($marzban_list_get)) {
            if ($rxPhase === 'reconcile') {
                return rx_pf_manual_review($order_id, $rxToken, 'national_stock_renewal_unverifiable', ['username' => (string) $nameloc['username']]);
            }
            if (!rx_pf_prepare($order_id, $rxToken, null, ['national_stock' => true])) {
                return rx_pf_abort($order_id, $rxToken, 'fulfillment_prepare_failed', true);
            }
            $stockNew = function_exists('nmStockReserveForProduct') ? nmStockReserveForProduct($marzban_list_get, $prodcut, $Balance_id['id'], $nameloc['id_invoice'], 'paid_extend_national_stock') : false;
            if (!is_array($stockNew) || (string)($stockNew['content'] ?? '') === '') {
                if (is_array($stockNew) && function_exists('nmStockReleaseReservation')) nmStockReleaseReservation($stockNew);
                $__refundSt = rx_refund_payment_once($Payment_report['id_order'], $Balance_id['id'], $Payment_report['price'], 'بازگشت وجه - موجودی انبار تمام شده', (string)($nameloc['id_invoice'] ?? ''));
                if ($__refundSt === 'refunded') {
                    sendmessage($Balance_id['id'], "❌ موجودی انبار برای این محصول تمام شده است؛ مبلغ پرداختی به کیف پول شما بازگردانده شد.", $keyboard, 'HTML');
                } elseif ($__refundSt === 'failed') {
                    sendmessage($Balance_id['id'], "❌ موجودی انبار برای این محصول تمام شده است و بازگشت وجه با خطا مواجه شد؛ لطفاً با پشتیبانی در ارتباط باشید.", $keyboard, 'HTML');
                }
                return rx_pf_fail($order_id, $rxToken, 'national_stock_empty', $__refundSt);
            }
            update("user", "Balance", 0, "id", $Balance_id['id']);
            update("invoice", "name_product", $prodcut['name_product'], "id_invoice", $nameloc['id_invoice']);
            update("invoice", "price_product", $prodcut['price_product'], "id_invoice", $nameloc['id_invoice']);
            update("invoice", "Volume", $prodcut['Volume_constraint'], "id_invoice", $nameloc['id_invoice']);
            update("invoice", "Service_time", $prodcut['Service_time'], "id_invoice", $nameloc['id_invoice']);
            update("invoice", "Status", "active", "id_invoice", $nameloc['id_invoice']);
            update("invoice", "time_sell", time(), "id_invoice", $nameloc['id_invoice']);
            update("invoice", "user_info", $stockNew['content'], "id_invoice", $nameloc['id_invoice']);
            try { update("invoice", "source_panel_code", $marzban_list_get['code_panel'], "id_invoice", $nameloc['id_invoice']); } catch (Throwable $e) {}
            $invoiceNew = array_merge((array)$nameloc, ['name_product' => $prodcut['name_product'], 'price_product' => $prodcut['price_product'], 'Volume' => $prodcut['Volume_constraint'], 'Service_time' => $prodcut['Service_time'], 'time_sell' => time(), 'user_info' => $stockNew['content'], 'source_panel_code' => $marzban_list_get['code_panel']]);
            if (function_exists('nmStockDeliverConfig')) nmStockDeliverConfig($stockNew, $invoiceNew, '✅ تمدید سرویس از انبار شبکه‌ملی با موفقیت انجام شد');
            $extend = ['status' => true, 'stock' => true];
        } else {
            $ManagePanel = rxEnsureManagePanel();
            if (!is_object($ManagePanel)) {
                if (function_exists('rx_log_event')) {
                    rx_log_event('DIRECT_PAYMENT_NO_MANAGE_PANEL', 'ManagePanel unavailable; extend aborted without side effects', ['id_order' => $order_id]);
                }
                return rx_pf_abort($order_id, $rxToken, 'manage_panel_unavailable', true);
            }
            $DataUserOut = $ManagePanel->DataUser($nameloc['Service_location'], $nameloc['username']);
            $Balance_Low_user = 0;
            $rxRenewMode = rxRenewalMode($marzban_list_get['Methodextend'] ?? '');
            if (rxReservationStoredSelection($rxReservationSel) !== null) {
                $rxRenewMode = rxRenewalMode('رزرو اشتراک');
            }
            $rxQueuedRenewal = is_array($rxRenewMode) && !empty($rxRenewMode['queued']) && (string) ($rxReservationSel['trigger'] ?? '') !== 'immediate';
            $rxPolicy = is_array($rxRenewMode) ? (string) ($rxRenewMode['policy'] ?? '') : '';
            $rxResetUsage = is_array($rxRenewMode) && !empty($rxRenewMode['reset_usage']);
            if (is_array($rxRenewMode) && !empty($rxRenewMode['queued'])) {
                $rxPolicy = (string) ($rxReservationSel['policy'] ?? 'reset_all');
                $rxResetUsage = !empty($rxReservationSel['reset_usage']) && rxRenewalPolicyAllowsUsageReset($rxPolicy);
            }
            $rxExtendOptions = [
                'source' => 'payment',
                'ref' => $order_id,
                'id_user' => $Balance_id['id'],
                'price' => $Payment_report['price'],
                'reservation' => array_merge($rxReservationSel, ['payment_ref' => $order_id]),
            ];
            $rxReconcilable = !$rxQueuedRenewal && is_array($rxRenewMode) && ($marzban_list_get['type'] ?? '') !== 'Manualsale'
                && (rx_pf_panel_reconcilable($marzban_list_get) || ($marzban_list_get['type'] ?? '') === 'WGDashboard');
            $rxSnap = rx_pf_snapshot_from_datauser($DataUserOut, (string) ($marzban_list_get['type'] ?? ''));
            $rxApply = true;
            $rxAfterState = null;
            if ($rxPhase === 'reconcile') {
                if ($rxQueuedRenewal) {
                    if (!rx_pf_mark_applying($order_id, $rxToken)) {
                        return rx_pf_result('already_processing', 'ownership_lost');
                    }
                } elseif (!$rxReconcilable || !is_array($rxBeforeState) || !is_array($rxTargetState)) {
                    return rx_pf_manual_review($order_id, $rxToken, 'renewal_result_unverifiable', ['username' => (string) $nameloc['username']]);
                } else {
                    $rxClass = rx_pf_classify($rxSnap, $rxBeforeState, $rxTargetState);
                    if ($rxClass === 'unknown') {
                        return rx_pf_defer($order_id, $rxToken, 'renewal_panel_read_failed: ' . (string) ($rxSnap['error'] ?? ''));
                    }
                    if ($rxClass === 'ambiguous') {
                        return rx_pf_manual_review($order_id, $rxToken, 'renewal_panel_state_ambiguous', ['username' => (string) $nameloc['username']]);
                    }
                    if ($rxClass === 'target') {
                        $rxApply = false;
                        $extend = ['status' => true, 'reconciled' => true];
                        $rxAfterState = rx_pf_limits($rxSnap);
                        $ManagePanel->rxRenewalLocalSuccess($marzban_list_get, (string) $nameloc['username'], (string) $nameloc['id_invoice']);
                    } elseif (!rx_pf_mark_applying($order_id, $rxToken)) {
                        return rx_pf_result('already_processing', 'ownership_lost');
                    }
                }
            } else {
                $rxBeforeState = null;
                $rxTargetState = null;
                if ($rxRenewMode === null) {
                    return rx_pf_manual_review($order_id, $rxToken, 'unknown_renewal_method: ' . (string) ($marzban_list_get['Methodextend'] ?? ''), ['username' => (string) $nameloc['username']]);
                }
                if ($rxReconcilable) {
                    if (empty($rxSnap['ok'])) {
                        return rx_pf_abort($order_id, $rxToken, 'renewal_panel_read_failed', true);
                    }
                    if (!empty($rxSnap['exists'])) {
                        $rxPlan = rxRenewalPlanForSnapshot($rxSnap, $marzban_list_get, (string) $nameloc['username'], $rxPolicy, $rxResetUsage, $prodcut['Volume_constraint'], $prodcut['Service_time'], (string) $rxRenewMode['method']);
                        if (empty($rxPlan['ok'])) {
                            $extend = ['status' => false, 'code' => (string) ($rxPlan['reason'] ?? 'renewal_refused'), 'no_mutation' => true, 'plan' => $rxPlan, 'msg' => 'renewal refused: ' . (string) ($rxPlan['reason'] ?? '')];
                            $rxApply = false;
                            rx_pf_log('RENEWAL_REFUSED', 'Paid renewal refused before panel mutation', ['id_order' => $order_id, 'username' => (string) $nameloc['username'], 'panel' => (string) $marzban_list_get['name_panel'], 'policy' => $rxPolicy, 'reason' => (string) ($rxPlan['reason'] ?? '')]);
                        } else {
                            $rxBeforeState = array_merge(rx_pf_limits($rxSnap), [
                                'status' => (string) ($rxSnap['status'] ?? ''),
                                'username' => (string) $nameloc['username'],
                                'panel' => (string) $marzban_list_get['name_panel'],
                                'remaining' => $rxPlan['before_remaining'],
                                'method' => $rxPlan['method'],
                                'policy' => $rxPlan['policy'],
                            ]);
                            $rxTargetState = $rxPlan;
                        }
                    }
                }
                if ($rxApply && !rx_pf_prepare($order_id, $rxToken, $rxBeforeState, $rxTargetState)) {
                    return rx_pf_abort($order_id, $rxToken, 'fulfillment_prepare_failed', true);
                }
            }
            if ($rxApply) {
                try {
                    $extend = $ManagePanel->extend($marzban_list_get['Methodextend'], $prodcut['Volume_constraint'], $prodcut['Service_time'], $nameloc['username'], $prodcut['code_product'], $marzban_list_get['code_panel'], $rxTargetState, $rxExtendOptions);
                } catch (Throwable $rxPanelError) {
                    return rx_pf_reconcile_later($order_id, $rxToken, 'renewal_panel_exception: ' . $rxPanelError->getMessage());
                }
            }
            if (rxRenewalIsPending($extend)) {
                return rx_pf_reconcile_later($order_id, $rxToken, 'renewal_result_unverified: ' . (string) ($extend['operation_id'] ?? '') . ' ' . (is_scalar($extend['msg'] ?? null) ? (string) $extend['msg'] : ''));
            }
            if (($extend['code'] ?? '') === 'renewal_in_progress' || (($extend['code'] ?? '') === 'panel_read_failed' && !empty($extend['no_mutation']))) {
                return rx_pf_defer($order_id, $rxToken, 'renewal_deferred: ' . (string) $extend['code']);
            }
            if (($extend['status'] ?? false) == false && empty($extend['no_mutation']) && is_array($rxBeforeState) && is_array($rxTargetState)) {
                $rxPostSnap = rx_pf_panel_snapshot($ManagePanel, (string) $nameloc['Service_location'], (string) $nameloc['username'], (string) ($marzban_list_get['type'] ?? ''));
                $rxClass = rx_pf_classify($rxPostSnap, $rxBeforeState, $rxTargetState);
                if ($rxClass === 'target') {
                    $extend = ['status' => true, 'reconciled' => true];
                    $rxAfterState = rx_pf_limits($rxPostSnap);
                    $ManagePanel->rxRenewalLocalSuccess($marzban_list_get, (string) $nameloc['username'], (string) $nameloc['id_invoice']);
                } else {
                    return rx_pf_reconcile_later($order_id, $rxToken, 'renewal_result_unknown: ' . (is_scalar($extend['msg'] ?? null) ? (string) $extend['msg'] : ''));
                }
            }
            if (!empty($extend['status']) && empty($extend['queued']) && is_array($rxTargetState) && $rxAfterState === null) {
                $rxVerify = is_array($extend['rx_renewal'] ?? null) ? $extend['rx_renewal'] : null;
                if ($rxVerify === null || empty($rxVerify['verified']) || !is_array($rxVerify['after'] ?? null)) {
                    return rx_pf_reconcile_later($order_id, $rxToken, 'renewal_result_unverified');
                }
                $rxAfterState = $rxVerify['after'];
            }
        if ($extend['status'] == false) {
            $__refundEx = rx_refund_payment_once($Payment_report['id_order'], $Balance_id['id'], $Payment_report['price'], 'بازگشت وجه - خطا در تمدید سرویس', (string)($nameloc['id_invoice'] ?? ''));
            if ($__refundEx === 'duplicate') {
                return rx_pf_fail($order_id, $rxToken, 'renewal_failed', $__refundEx);
            }
            if ($__refundEx === 'refunded') {
                sendmessage($Balance_id['id'], $textbotlang['users']['sell']['ErrorConfig'], $keyboard, 'HTML');
                sendmessage($Balance_id['id'], "💎  کاربر عزیز بدلیل تمدید نشدن سرویس مبلغ " . rxFormatToman($Payment_report['price']) . " تومان به کیف پول شما اضافه گردید.", $keyboard, 'HTML');
            } else {
                sendmessage($Balance_id['id'], "❌ تمدید سرویس با خطا مواجه شد و بازگشت وجه نیز انجام نشد؛ لطفاً با پشتیبانی در ارتباط باشید.", $keyboard, 'HTML');
            }
            $rxTopupExtendMsg = rxRenewalFailureText($extend, faoxima_textbot_get('dyn_errors_renewal_support_error', "❌خطایی در تمدید سرویس رخ داده با پشتیبانی در ارتباط باشید"));
            if (($extend['code'] ?? '') === 'manual_stock_empty') {
                $rxTopupExtendMsg = "❌ موجودی انبار برای این محصول تمام شده است.";
            }
            $extend['msg'] = rx_panel_error_text($extend['msg'] ?? null, $extend['detail'] ?? null);
            $textreports = "
        خطای تمدید سرویس
<blockquote>نام پنل : {$marzban_list_get['name_panel']}</blockquote>
<blockquote>نام کاربری سرویس : {$nameloc['username']}</blockquote>
<blockquote>کد پیگیری پرداخت : {$order_id}</blockquote>
<blockquote>کد خطا : " . htmlspecialchars((string) ($extend['code'] ?? ''), ENT_QUOTES, 'UTF-8') . "</blockquote>
<blockquote>دلیل خطا : {$extend['msg']}</blockquote>";
            sendmessage($nameloc['id_user'], $rxTopupExtendMsg, null, 'HTML');
            if (strlen($setting['Channel_Report']) > 0) {
                telegram('sendmessage', [
                    'chat_id' => $setting['Channel_Report'],
                    'message_thread_id' => $errorreport,
                    'text' => $textreports,
                    'parse_mode' => "HTML"
                ]);
            }
            return rx_pf_fail($order_id, $rxToken, 'renewal_failed', $__refundEx);
        }
            $rxStatements[] = ["UPDATE user SET Balance = ? WHERE id = ?", [$Balance_Low_user, $Balance_id['id']]];
        }
        $rxCompletion = rx_pf_complete($order_id, $rxToken, ['operation' => 'getextenduser', 'panel' => $extend, 'target' => $rxTargetState ?? null], $rxStatements);
        if ($rxCompletion !== 'completed') {
            return rx_pf_completion_outcome($order_id, $rxToken, $rxCompletion);
        }
        if ($rxWasTestService) {
            update("invoice", "name_product", $prodcut['name_product'], "id_invoice", $nameloc['id_invoice']);
            update("invoice", "price_product", $prodcut['price_product'], "id_invoice", $nameloc['id_invoice']);
        }

        MiniDiscount::logSale([
            'id_user' => $Balance_id['id'],
            'id_invoice' => $nameloc['id_invoice'] ?? null,
            'Service_location' => $nameloc['Service_location'],
            'kind' => 'renewal',
            'name_product' => $prodcut['name_product'] ?? null,
            'amount' => $Payment_report['price'],
            'source' => 'bot',
        ]);
        update("service_other", "output", json_encode($extend), "id", $data_order['id']);
        update("service_other", "status", "paid", "id", $data_order['id']);
        $partsdic = explode("_", $Balance_id['Processing_value_four']);
        if ($partsdic[0] == "dis") {
            $SellDiscountlimit = select("DiscountSell", "*", "codeDiscount", $partsdic[1], "select");
            $value = intval($SellDiscountlimit['usedDiscount']) + 1;
            update("DiscountSell", "usedDiscount", $value, "codeDiscount", $partsdic[1]);
            $stmt = $pdo->prepare("INSERT INTO Giftcodeconsumed (id_user,code) VALUES (:id_user,:code)");
            $stmt->bindParam(':id_user', $Balance_id['id']);
            $stmt->bindParam(':code', $partsdic[1]);
            $stmt->execute();
            $text_report = "⭕️ یک کاربر با نام کاربری @{$Balance_id['username']}  و آیدی عددی {$Balance_id['id']} از کد تخفیف {$partsdic[1]} استفاده کرد.";
            if (strlen($setting['Channel_Report']) > 0) {
                telegram('sendmessage', [
                    'chat_id' => $setting['Channel_Report'],
                    'parse_mode' => 'HTML',
                    'message_thread_id' => $otherreport,
                    'text' => $text_report,
                ]);
            }
        }
        $keyboardextendfnished = json_encode([
            'inline_keyboard' => [
                [
                    ['text' => $textbotlang['users']['stateus']['backlist'], 'callback_data' => "backorder"],
                ],
                [
                    ['text' => $textbotlang['users']['stateus']['backservice'], 'callback_data' => "product_" . $nameloc['id_invoice']],
                ]
            ]
        ]);
        if ($Balance_id['agent'] == "f") {
            $valurcashbackextend = select("shopSetting", "*", "Namevalue", "chashbackextend", "select")['value'];
        } else {
            $valurcashbackextend = json_decode(select("shopSetting", "*", "Namevalue", "chashbackextend_agent", "select")['value'], true)[$Balance_id['agenr']];
        }
        $renewCashbackEligible = !function_exists('rx_shopCashbackEligible')
            || rx_shopCashbackEligible("chashbackextend", $Balance_id['register'] ?? null, "getextenduser", $Balance_id['id'] ?? null, $Payment_report['id_order'] ?? null);
        if ($renewCashbackEligible && intval($valurcashbackextend) != 0) {
            $result = (int) floor(($prodcut['price_product'] * $valurcashbackextend) / 100);
            if (rx_cashback_credit_once($Payment_report['id_order'] ?? '', $Balance_id['id'], $result, 'chashbackextend', 'هدیه بازگشت وجه تمدید سرویس') === 'credited') {
                sendmessage($Balance_id['id'], "تبریک 🎉
📌 به عنوان هدیه تمدید مبلغ " . rxFormatToman($result) . " تومان حساب شما شارژ گردید", null, 'HTML');
            }
        }
        $priceproductformat = number_format($prodcut['price_product']);
        if (!empty($extend['queued'])) {
            $rxQueuedSuccessTpl = (string) ($extend['reservation']['confirmation'] ?? rxRenewalText('reservation_confirmed'));
            $textextend = "$rxQueuedSuccessTpl

▫️نام سرویس : $usernamepanel
▫️نام محصول : {$prodcut['name_product']}
▫️مبلغ تمدید $priceproductformat تومان
";
        } else {
            $textextend = "✅ تمدید برای سرویس شما با موفقیت صورت گرفت

▫️نام سرویس : $usernamepanel
▫️نام محصول : {$prodcut['name_product']}
▫️مبلغ تمدید $priceproductformat تومان
";
            if (is_array($rxBeforeState ?? null) && is_array($rxAfterState ?? null)) {
                $textextend .= "\n" . rxRenewalResultText($rxBeforeState, $rxAfterState);
            } elseif (($rxOutcomeText = rxRenewalOutcomeText($extend)) !== '') {
                $textextend .= "\n" . $rxOutcomeText;
            }
        }
        sendmessage($Balance_id['id'], $textextend, $keyboardextendfnished, 'HTML');
        if (intval($setting['scorestatus']) == 1 and !in_array($Balance_id['id'], $admin_ids)) {
            sendmessage($Balance_id['id'], faoxima_textbot_get('dyn_purchase_score_earned_2', "📌شما 2 امتیاز جدید کسب کردید."), null, 'html');
            $scorenew = $Balance_id['score'] + 2;
            update("user", "score", $scorenew, "id", $Balance_id['id']);
        }
        $timejalali = jdate('Y/m/d H:i:s');
        $text_report = "📣 جزئیات تمدید اکانت در ربات شما ثبت شد .

<blockquote>▫️آیدی عددی کاربر : <code>{$Balance_id['id']}</code></blockquote>
<blockquote>▫️نام کاربری کاربر : @{$Balance_id['username']}</blockquote>
<blockquote>▫️نام کاربری کانفیگ :$usernamepanel</blockquote>
<blockquote>▫️موقعیت سرویس سرویس : {$nameloc['Service_location']}</blockquote>
<blockquote>▫️نام محصول : {$prodcut['name_product']}</blockquote>
<blockquote>▫️حجم محصول : {$prodcut['Volume_constraint']}</blockquote>
<blockquote>▫️زمان محصول : {$prodcut['Service_time']}</blockquote>
<blockquote>▫️مبلغ تمدید : $priceproductformat تومان</blockquote>
<blockquote>▫️موجودی قبل از خرید : $balanceformatsell تومان</blockquote>
<blockquote>▫️زمان خرید : $timejalali</blockquote>";
        if (strlen($setting['Channel_Report']) > 0) {
            telegram('sendmessage', [
                'chat_id' => $setting['Channel_Report'],
                'message_thread_id' => $otherservice,
                'text' => $text_report,
                'parse_mode' => "HTML"
            ]);
        }
        if (function_exists('faoxima_public_purchase_log_event')) {
            faoxima_public_purchase_log_event('renewal', [
                'user_id'    => $Balance_id['id'],
                'amount'     => $prodcut['name_product'],
                'price'      => $priceproductformat,
                'panel_name' => $marzban_list_get['name_panel'] ?? '',
                'category'   => $prodcut['category'] ?? '',
            ], $setting);
        }
        if (empty($extend['queued']) && (string) ($nameloc['Status'] ?? '') !== 'disablebyadmin') {
            update("invoice", "Status", "active", "id_invoice", $nameloc['id_invoice']);
        }
        if ($Payment_report['Payment_Method'] == "cart to cart" or $Payment_report['Payment_Method'] == "arze digital offline") {

            $rxFmtBalanceBeforeExtend = rxFormatToman($Balance_id['Balance']);
            $textconfrom = "✅ پرداخت تایید شده
🔋 تمدید سرویس
🪪 نام کاربری کانفیگ : $usernamepanel
🛍 نام محصول : {$prodcut['name_product']}
🌏 نام لوکیشن : {$nameloc['Service_location']}
👤 شناسه کاربر: <code>{$Balance_id['id']}</code>
🛒 کد پیگیری پرداخت: {$Payment_report['id_order']}
⚜️ نام کاربری: @{$Balance_id['username']}
💎 موجودی قبل تمدید  : {$rxFmtBalanceBeforeExtend}
💸 مبلغ پرداختی: $format_price_cart تومان
✍️ توضیحات : {$paymentNote}

";
            Editmessagetext($_receipt_chat_id, $message_id, $textconfrom, $Confirm_pay, 'HTML', $_receipt_report_thread > 0 ? $_receipt_report_thread : null);
        }
    } elseif ($steppay[0] == "getextravolumeuser") {
        $steppay = explode("%", $steppay[1]);
        $volume = $steppay[1];
        $nameloc = select("invoice", "*", "username", $steppay[0], "select");
        $marzban_list_get = select("marzban_panel", "*", "name_panel", $nameloc['Service_location'], "select");
        $Balance_Low_user = 0;
        $inboundid = $marzban_list_get['inboundid'];
        if ($nameloc['inboundid'] != null) {
            $inboundid = $nameloc['inboundid'];
        }
        $ManagePanel = rxEnsureManagePanel();
        if (!is_object($ManagePanel)) {
            if (function_exists('rx_log_event')) {
                rx_log_event('DIRECT_PAYMENT_NO_MANAGE_PANEL', 'ManagePanel unavailable; extra volume aborted without side effects', ['id_order' => $order_id]);
            }
            return rx_pf_abort($order_id, $rxToken, 'manage_panel_unavailable', true);
        }
        $DataUserOut = $ManagePanel->DataUser($nameloc['Service_location'], $steppay[0]);
        $rxReconcilable = rx_pf_panel_reconcilable($marzban_list_get);
        $rxSnap = rx_pf_snapshot_from_datauser($DataUserOut);
        $rxApply = true;
        if ($rxPhase === 'reconcile') {
            if (!$rxReconcilable || !is_array($rxBeforeState) || !is_array($rxTargetState)) {
                return rx_pf_manual_review($order_id, $rxToken, 'extra_volume_result_unverifiable', ['username' => (string) $nameloc['username']]);
            }
            $rxClass = rx_pf_classify($rxSnap, $rxBeforeState, $rxTargetState);
            if ($rxClass === 'unknown') {
                return rx_pf_defer($order_id, $rxToken, 'extra_volume_panel_read_failed: ' . (string) ($rxSnap['error'] ?? ''));
            }
            if ($rxClass === 'ambiguous') {
                return rx_pf_manual_review($order_id, $rxToken, 'extra_volume_panel_state_ambiguous', ['username' => (string) $nameloc['username']]);
            }
            if ($rxClass === 'target') {
                $rxApply = false;
                $extra_volume = ['status' => true, 'reconciled' => true];
            } elseif (!rx_pf_mark_applying($order_id, $rxToken)) {
                return rx_pf_result('already_processing', 'ownership_lost');
            }
        } else {
            $rxBeforeState = null;
            $rxTargetState = null;
            if ($rxReconcilable) {
                if (empty($rxSnap['ok'])) {
                    return rx_pf_abort($order_id, $rxToken, 'extra_volume_panel_read_failed', true);
                }
                if (!empty($rxSnap['exists'])) {
                    $rxBeforeState = rx_pf_limits($rxSnap);
                    $rxTargetState = rx_pf_extra_volume_target($rxBeforeState, $volume);
                }
            }
            if (!rx_pf_prepare($order_id, $rxToken, $rxBeforeState, $rxTargetState)) {
                return rx_pf_abort($order_id, $rxToken, 'fulfillment_prepare_failed', true);
            }
        }
        if (is_array($rxBeforeState) && is_array($DataUserOut)) {
            $DataUserOut['data_limit'] = $rxBeforeState['data_limit'] ?? ($DataUserOut['data_limit'] ?? null);
            $DataUserOut['expire'] = $rxBeforeState['expire'] ?? ($DataUserOut['expire'] ?? null);
        }
        $data_for_database = json_encode(array(
            'volume_value' => $volume,
            'old_volume' => $DataUserOut['data_limit'],
            'expire_old' => $DataUserOut['expire']
        ));
        $dateacc = date('Y/m/d H:i:s');
        $type = "extra_user";
        if ($rxApply) {
            try {
                $extra_volume = $ManagePanel->extra_volume($nameloc['username'], $marzban_list_get['code_panel'], $volume, $rxTargetState);
            } catch (Throwable $rxPanelError) {
                return rx_pf_reconcile_later($order_id, $rxToken, 'extra_volume_panel_exception: ' . $rxPanelError->getMessage());
            }
        }
        if (($extra_volume['status'] ?? false) == false && is_array($rxBeforeState) && is_array($rxTargetState)) {
            $rxClass = rx_pf_classify(rx_pf_panel_snapshot($ManagePanel, (string) $nameloc['Service_location'], (string) $steppay[0]), $rxBeforeState, $rxTargetState);
            if ($rxClass === 'target') {
                $extra_volume = ['status' => true, 'reconciled' => true];
            } elseif ($rxClass !== 'before') {
                return rx_pf_reconcile_later($order_id, $rxToken, 'extra_volume_result_unknown: ' . (is_scalar($extra_volume['msg'] ?? null) ? (string) $extra_volume['msg'] : ''));
            }
        }
        if ($extra_volume['status'] == false) {
            $__refundVx = rx_refund_payment_once($Payment_report['id_order'], $Balance_id['id'], $Payment_report['price'], 'بازگشت وجه - خطا در خرید حجم اضافه', (string)($nameloc['id_invoice'] ?? ''));
            if ($__refundVx === 'duplicate') {
                return rx_pf_fail($order_id, $rxToken, 'extra_volume_failed', $__refundVx);
            }
            $extra_volume['msg'] = rx_panel_error_text($extra_volume['msg'] ?? null, $extra_volume['detail'] ?? null);
            $textreports = "خطای خرید حجم اضافه
<blockquote>نام پنل : {$marzban_list_get['name_panel']}</blockquote>
<blockquote>نام کاربری سرویس : {$nameloc['username']}</blockquote>
<blockquote>دلیل خطا : {$extra_volume['msg']}</blockquote>";
            sendmessage($nameloc['id_user'], faoxima_textbot_get('dyn_errors_extra_volume_purchase_error', "❌خطایی در خرید حجم اضافه سرویس رخ داده با پشتیبانی در ارتباط باشید"), null, 'HTML');
            if ($__refundVx === 'refunded') {
                sendmessage($nameloc['id_user'], "💎  کاربر عزیز بدلیل انجام نشدن خرید حجم اضافه مبلغ " . rxFormatToman($Payment_report['price']) . " تومان به کیف پول شما اضافه گردید.", null, 'HTML');
            }
            if (strlen($setting['Channel_Report']) > 0) {
                telegram('sendmessage', [
                    'chat_id' => $setting['Channel_Report'],
                    'message_thread_id' => $errorreport,
                    'text' => $textreports,
                    'parse_mode' => "HTML"
                ]);
            }
            return rx_pf_fail($order_id, $rxToken, 'extra_volume_failed', $__refundVx);
        }
        $rxCompletion = rx_pf_complete($order_id, $rxToken, ['operation' => 'getextravolumeuser', 'panel' => $extra_volume, 'target' => $rxTargetState], [["UPDATE user SET Balance = ? WHERE id = ?", [$Balance_Low_user, $Balance_id['id']]]]);
        if ($rxCompletion !== 'completed') {
            return rx_pf_completion_outcome($order_id, $rxToken, $rxCompletion);
        }
        MiniDiscount::logSale([
            'id_user' => $Balance_id['id'],
            'id_invoice' => $nameloc['id_invoice'] ?? null,
            'Service_location' => $nameloc['Service_location'],
            'kind' => 'volume',
            'name_product' => $nameloc['name_product'] ?? null,
            'amount' => $Payment_report['price'],
            'source' => 'bot',
        ]);
        $stmt = $pdo->prepare("INSERT IGNORE INTO service_other (id_user, username,value,type,time,price,output) VALUES (:id_user,:username,:value,:type,:time,:price,:output)");
        $stmt->bindParam(':id_user', $Balance_id['id']);
        $stmt->bindParam(':username', $steppay[0]);
        $stmt->bindParam(':value', $data_for_database);
        $stmt->bindParam(':type', $type);
        $stmt->bindParam(':time', $dateacc);
        $stmt->bindParam(':price', $Payment_report['price']);
        $stmt->bindParam(':output', json_encode($extra_volume));
        $stmt->execute();
        $keyboardextrafnished = json_encode([
            'inline_keyboard' => [
                [
                    ['text' => $textbotlang['users']['stateus']['backservice'], 'callback_data' => "product_" . $nameloc['id_invoice']],
                ]
            ]
        ]);
        $volumesformat = number_format($Payment_report['price'], 0);
        $rxFmtBalanceBeforeVolume = rxFormatToman($Balance_id['Balance']);
        if (intval($setting['scorestatus']) == 1 and !in_array($Balance_id['id'], $admin_ids)) {
            sendmessage($Balance_id['id'], faoxima_textbot_get('dyn_purchase_score_earned_1', "📌شما 1 امتیاز جدید کسب کردید."), null, 'html');
            $scorenew = $Balance_id['score'] + 1;
            update("user", "score", $scorenew, "id", $Balance_id['id']);
        }
        $textvolume = "✅ افزایش حجم برای سرویس شما با موفقیت صورت گرفت
 
▫️نام سرویس  : {$steppay[0]}
▫️حجم اضافه : $volume گیگ

▫️مبلغ افزایش حجم : $volumesformat تومان";
        sendmessage($Balance_id['id'], $textvolume, $keyboardextrafnished, 'HTML');
        $volumes = $volume;
        if ($Payment_report['Payment_Method'] == "cart to cart" or $Payment_report['Payment_Method'] == "arze digital offline") {
            $textconfrom = "✅ پرداخت تایید شده
🔋 خرید حجم اضافه
🛍 حجم خریداری شده  : $volumes گیگ
👤 نام کاربری کانفیگ {$steppay[0]}
👤 شناسه کاربر: <code>{$Balance_id['id']}</code>
🛒 کد پیگیری پرداخت: {$Payment_report['id_order']}
⚜️ نام کاربری: @{$Balance_id['username']}
💎 موجودی قبل ازافزایش موجودی : {$rxFmtBalanceBeforeVolume}
💸 مبلغ پرداختی: $format_price_cart تومان
";
            Editmessagetext($_receipt_chat_id, $message_id, $textconfrom, $Confirm_pay, 'HTML', $_receipt_report_thread > 0 ? $_receipt_report_thread : null);
        }
        update("invoice", "Status", "active", "id_invoice", $nameloc['id_invoice']);
        $text_report = "⭕️ یک کاربر حجم اضافه خریده است

<blockquote>🪪 آیدی عددی : {$Balance_id['id']}</blockquote>
<blockquote>🛍 حجم خریداری شده  : $volumes گیگ</blockquote>
<blockquote>💰 مبلغ پرداختی : " . rxFormatToman($Payment_report['price']) . " تومان</blockquote>
<blockquote>👤 نام کاربری کانفیگ {$steppay[0]}</blockquote>
<blockquote>موجودی کاربر قبل خرید : {$rxFmtBalanceBeforeVolume}</blockquote>";
        if (strlen($setting['Channel_Report']) > 0) {
            telegram('sendmessage', [
                'chat_id' => $setting['Channel_Report'],
                'message_thread_id' => $otherservice,
                'text' => $text_report,
                'parse_mode' => "HTML"
            ]);
        }
        if (function_exists('faoxima_public_purchase_log_event')) {
            faoxima_public_purchase_log_event('volume_topup', [
                'user_id' => $Balance_id['id'],
                'amount'  => $volumes,
                'price'   => $volumesformat,
            ], $setting);
        }
    } elseif ($steppay[0] == "getextratimeuser") {
        $steppay = explode("%", $steppay[1]);
        $tmieextra = $steppay[1];
        $nameloc = select("invoice", "*", "username", $steppay[0], "select");
        $marzban_list_get = select("marzban_panel", "*", "name_panel", $nameloc['Service_location'], "select");
        $Balance_Low_user = 0;
        $inboundid = $marzban_list_get['inboundid'];
        if ($nameloc['inboundid'] != false) {
            $inboundid = $nameloc['inboundid'];
        }
        $ManagePanel = rxEnsureManagePanel();
        if (!is_object($ManagePanel)) {
            if (function_exists('rx_log_event')) {
                rx_log_event('DIRECT_PAYMENT_NO_MANAGE_PANEL', 'ManagePanel unavailable; extra time aborted without side effects', ['id_order' => $order_id]);
            }
            return rx_pf_abort($order_id, $rxToken, 'manage_panel_unavailable', true);
        }
        $DataUserOut = $ManagePanel->DataUser($nameloc['Service_location'], $steppay[0]);
        $rxReconcilable = rx_pf_panel_reconcilable($marzban_list_get);
        $rxSnap = rx_pf_snapshot_from_datauser($DataUserOut);
        $rxApply = true;
        if ($rxPhase === 'reconcile') {
            if (!$rxReconcilable || !is_array($rxBeforeState) || !is_array($rxTargetState)) {
                return rx_pf_manual_review($order_id, $rxToken, 'extra_time_result_unverifiable', ['username' => (string) $nameloc['username']]);
            }
            $rxClass = rx_pf_classify($rxSnap, $rxBeforeState, $rxTargetState);
            if ($rxClass === 'unknown') {
                return rx_pf_defer($order_id, $rxToken, 'extra_time_panel_read_failed: ' . (string) ($rxSnap['error'] ?? ''));
            }
            if ($rxClass === 'ambiguous') {
                return rx_pf_manual_review($order_id, $rxToken, 'extra_time_panel_state_ambiguous', ['username' => (string) $nameloc['username']]);
            }
            if ($rxClass === 'target') {
                $rxApply = false;
                $extra_time = ['status' => true, 'reconciled' => true];
            } elseif (!rx_pf_mark_applying($order_id, $rxToken)) {
                return rx_pf_result('already_processing', 'ownership_lost');
            }
        } else {
            $rxBeforeState = null;
            $rxTargetState = null;
            if ($rxReconcilable) {
                if (empty($rxSnap['ok'])) {
                    return rx_pf_abort($order_id, $rxToken, 'extra_time_panel_read_failed', true);
                }
                if (!empty($rxSnap['exists'])) {
                    $rxBeforeState = rx_pf_limits($rxSnap);
                    $rxTargetState = rx_pf_extra_time_target($rxBeforeState, $tmieextra, time());
                }
            }
            if (!rx_pf_prepare($order_id, $rxToken, $rxBeforeState, $rxTargetState)) {
                return rx_pf_abort($order_id, $rxToken, 'fulfillment_prepare_failed', true);
            }
        }
        if (is_array($rxBeforeState) && is_array($DataUserOut)) {
            $DataUserOut['data_limit'] = $rxBeforeState['data_limit'] ?? ($DataUserOut['data_limit'] ?? null);
            $DataUserOut['expire'] = $rxBeforeState['expire'] ?? ($DataUserOut['expire'] ?? null);
        }
        $data_for_database = json_encode(array(
            'day' => $tmieextra,
            'old_volume' => $DataUserOut['data_limit'],
            'expire_old' => $DataUserOut['expire']
        ));
        $dateacc = date('Y/m/d H:i:s');
        $type = "extra_time_user";
        $timeservice = $DataUserOut['expire'] - time();
        $day = floor($timeservice / 86400);
        if ($rxApply) {
            try {
                $extra_time = $ManagePanel->extra_time($nameloc['username'], $marzban_list_get['code_panel'], $tmieextra, $rxTargetState);
            } catch (Throwable $rxPanelError) {
                return rx_pf_reconcile_later($order_id, $rxToken, 'extra_time_panel_exception: ' . $rxPanelError->getMessage());
            }
        }
        if (($extra_time['status'] ?? false) == false && is_array($rxBeforeState) && is_array($rxTargetState)) {
            $rxClass = rx_pf_classify(rx_pf_panel_snapshot($ManagePanel, (string) $nameloc['Service_location'], (string) $steppay[0]), $rxBeforeState, $rxTargetState);
            if ($rxClass === 'target') {
                $extra_time = ['status' => true, 'reconciled' => true];
            } elseif ($rxClass !== 'before') {
                return rx_pf_reconcile_later($order_id, $rxToken, 'extra_time_result_unknown: ' . (is_scalar($extra_time['msg'] ?? null) ? (string) $extra_time['msg'] : ''));
            }
        }
        if ($extra_time['status'] == false) {
            $__refundEt = rx_refund_payment_once($Payment_report['id_order'], $Payment_report['id_user'], $Payment_report['price'], 'بازگشت وجه - خطا در خرید زمان اضافه', (string)($nameloc['id_invoice'] ?? ''));
            if ($__refundEt === 'duplicate') {
                return rx_pf_fail($order_id, $rxToken, 'extra_time_failed', $__refundEt);
            }
            if ($__refundEt === 'refunded') {
                sendmessage($Payment_report['id_user'], "💎  کاربر عزیز بدلیل انجام نشدن خرید زمان اضافه مبلغ " . rxFormatToman($Payment_report['price']) . " تومان به کیف پول شما اضافه گردید.", null, 'HTML');
            }
            $extra_time['msg'] = rx_panel_error_text($extra_time['msg'] ?? null, $extra_time['detail'] ?? null);
            $textreports = "خطای خرید حجم اضافه
<blockquote>نام پنل : {$marzban_list_get['name_panel']}</blockquote>
<blockquote>نام کاربری سرویس : {$nameloc['username']}</blockquote>
<blockquote>دلیل خطا : {$extra_time['msg']}</blockquote>";
            sendmessage($from_id, faoxima_textbot_get('dyn_errors_extra_volume_purchase_error', "❌خطایی در خرید حجم اضافه سرویس رخ داده با پشتیبانی در ارتباط باشید"), null, 'HTML');
            if (strlen($setting['Channel_Report']) > 0) {
                telegram('sendmessage', [
                    'chat_id' => $setting['Channel_Report'],
                    'message_thread_id' => $errorreport,
                    'text' => $textreports,
                    'parse_mode' => "HTML"
                ]);
            }
            return rx_pf_fail($order_id, $rxToken, 'extra_time_failed', $__refundEt);
        }
        $rxCompletion = rx_pf_complete($order_id, $rxToken, ['operation' => 'getextratimeuser', 'panel' => $extra_time, 'target' => $rxTargetState], [["UPDATE user SET Balance = ? WHERE id = ?", [$Balance_Low_user, $nameloc['id_user']]]]);
        if ($rxCompletion !== 'completed') {
            return rx_pf_completion_outcome($order_id, $rxToken, $rxCompletion);
        }
        MiniDiscount::logSale([
            'id_user' => $Balance_id['id'],
            'id_invoice' => $nameloc['id_invoice'] ?? null,
            'Service_location' => $nameloc['Service_location'],
            'kind' => 'time',
            'name_product' => $nameloc['name_product'] ?? null,
            'amount' => $Payment_report['price'],
            'source' => 'bot',
        ]);
        $stmt = $pdo->prepare("INSERT IGNORE INTO service_other (id_user, username,value,type,time,price,output) VALUES (:id_user,:username,:value,:type,:time,:price,:output)");
        $stmt->bindParam(':id_user', $Balance_id['id']);
        $stmt->bindParam(':username', $steppay[0]);
        $stmt->bindParam(':value', $data_for_database);
        $stmt->bindParam(':type', $type);
        $stmt->bindParam(':time', $dateacc);
        $stmt->bindParam(':price', $Payment_report['price']);
        $stmt->bindParam(':output', json_encode($extra_time));
        $stmt->execute();
        $keyboardextrafnished = json_encode([
            'inline_keyboard' => [
                [
                    ['text' => $textbotlang['users']['stateus']['backservice'], 'callback_data' => "product_" . $nameloc['id_invoice']],
                ]
            ]
        ]);
        $volumesformat = number_format($Payment_report['price']);
        $rxFmtBalanceBeforeTime = rxFormatToman($Balance_id['Balance']);
        if (intval($setting['scorestatus']) == 1 and !in_array($Balance_id['id'], $admin_ids)) {
            sendmessage($Balance_id['id'], faoxima_textbot_get('dyn_purchase_score_earned_1', "📌شما 1 امتیاز جدید کسب کردید."), null, 'html');
            $scorenew = $Balance_id['score'] + 1;
            update("user", "score", $scorenew, "id", $Balance_id['id']);
        }
        $textextratime = "✅ افزایش زمان برای سرویس شما با موفقیت صورت گرفت

▫️نام سرویس : {$steppay[0]}
▫️زمان اضافه : $tmieextra روز

▫️مبلغ افزایش زمان : $volumesformat تومان";
        sendmessage($Balance_id['id'], $textextratime, $keyboardextrafnished, 'HTML');
        if ($Payment_report['Payment_Method'] == "cart to cart" or $Payment_report['Payment_Method'] == "arze digital offline") {
            $volumes = $tmieextra;
            $textconfrom = "✅ پرداخت تایید شده
🔋 خرید زمان اضافه
🛍 زمان خریداری شده  : $volumes روز
👤 نام کاربری کانفیگ {$steppay[0]}
👤 شناسه کاربر: <code>{$Balance_id['id']}</code>
🛒 کد پیگیری پرداخت: {$Payment_report['id_order']}
⚜️ نام کاربری: @{$Balance_id['username']}
💎 موجودی قبل ازافزایش موجودی : {$rxFmtBalanceBeforeTime}
💸 مبلغ پرداختی: $format_price_cart تومان
";
            Editmessagetext($_receipt_chat_id, $message_id, $textconfrom, $Confirm_pay, 'HTML', $_receipt_report_thread > 0 ? $_receipt_report_thread : null);
        }
        update("invoice", "Status", "active", "id_invoice", $nameloc['id_invoice']);
        $text_report = "⭕️ یک کاربر زمان اضافه خریده است

<blockquote>🪪 آیدی عددی : {$Balance_id['id']}</blockquote>
<blockquote>🛍 زمان خریداری شده  : $volumes روز</blockquote>
<blockquote>💰 مبلغ پرداختی : " . rxFormatToman($Payment_report['price']) . " تومان</blockquote>
<blockquote>👤 نام کاربری کانفیگ {$steppay[0]}</blockquote>";
        if (strlen($setting['Channel_Report']) > 0) {
            telegram('sendmessage', [
                'chat_id' => $setting['Channel_Report'],
                'parse_mode' => 'HTML',
                'message_thread_id' => $otherservice,
                'text' => $text_report,
            ]);
        }
        if (function_exists('faoxima_public_purchase_log_event')) {
            faoxima_public_purchase_log_event('time_extra', [
                'user_id' => $Balance_id['id'],
                'amount'  => $tmieextra,
                'price'   => $volumesformat,
            ], $setting);
        }
    } else {
        $__chargeBonus = isset($Payment_report['charge_bonus']) ? intval($Payment_report['charge_bonus']) : 0;
        $__paidAmount = intval($Payment_report['price']);
        $__creditAmount = $__paidAmount + $__chargeBonus;
        $Balance_confrim = intval($Balance_id['Balance']) + $__creditAmount;
        $__pm = (string) ($Payment_report['Payment_Method'] ?? '');
        if (stripos($__pm, 'crypto') !== false || stripos($__pm, 'arze digital') !== false || stripos($__pm, 'plisio') !== false || stripos($__pm, 'nowpayment') !== false || stripos($__pm, 'digitaltron') !== false) {
            $__wlCategory = 'topup_crypto';
        } elseif (stripos($__pm, 'cart to cart') !== false || stripos($__pm, 'carttocart') !== false) {
            $__wlCategory = 'topup_card';
        } else {
            $__wlCategory = 'topup_gateway';
        }
        $rxCredit = rx_pf_wallet_credit($order_id, $rxToken, $Payment_report['id_user'], $__creditAmount, $__wlCategory, $__pm);
        if ($rxCredit === 'already_completed') {
            return rx_pf_result('already_completed', 'wallet_already_credited');
        }
        if ($rxCredit !== 'credited') {
            if (function_exists('rx_log_event')) {
                rx_log_event('WALLET_CREDIT_FAILED', 'DirectPayment wallet credit failed; nothing was credited', [
                    'id_order' => $Payment_report['id_order'],
                    'id_user' => $Payment_report['id_user'],
                    'amount' => $__creditAmount,
                    'outcome' => $rxCredit,
                ]);
            }
            if ($rxCredit === 'not_owner' || $rxCredit === 'invalid_state') {
                return rx_pf_result('already_processing', 'wallet_' . $rxCredit);
            }
            return rx_pf_abort($order_id, $rxToken, 'wallet_credit_failed', true);
        }
        update("Payment_report", "at_updated", date('Y/m/d H:i:s'), "id_order", $Payment_report['id_order']);
        update("user", "Processing_value_four", "", "id", $Payment_report['id_user']);

        $__chargeDiscountCode = trim((string)($Payment_report['discount_code'] ?? ''));
        $__chargeDiscountAlreadyConsumed = (string)($Payment_report['discount_consumed'] ?? '') === '1';
        if ($__chargeDiscountCode !== '' && !$__chargeDiscountAlreadyConsumed && class_exists('MiniDiscount')) {
            update("Payment_report", "discount_consumed", "1", "id_order", $Payment_report['id_order']);
            MiniDiscount::markSellUsed($__chargeDiscountCode, $Balance_id);
            MiniDiscount::logOrderDiscount([
                'id_user' => $Payment_report['id_user'],
                'code' => $__chargeDiscountCode,
                'kind' => 'sell',
                'value_type' => null,
                'value_raw' => null,
                'price_before' => (float)($Payment_report['price_before_discount'] ?? 0),
                'discount_amount' => (float)($Payment_report['discount_amount'] ?? 0),
                'price_after' => $__paidAmount,
                'section' => 'charge',
            ]);
        }
        $format_price_cart = number_format($__paidAmount, 0);
        if ($Payment_report['Payment_Method'] == "cart to cart" or $Payment_report['Payment_Method'] == "arze digital offline") {
            $rxFmtBalanceBeforeTopup = rxFormatToman($Balance_id['Balance']);
            $textconfrom = "⭕️ یک پرداخت جدید انجام شده است
افزایش موجودی.
👤 شناسه کاربر: <code>{$Balance_id['id']}</code>
🛒 کد پیگیری پرداخت: {$Payment_report['id_order']}
⚜️ نام کاربری: @{$Balance_id['username']}
💸 مبلغ پرداختی: $format_price_cart تومان
💎 موجودی قبل ازافزایش موجودی : {$rxFmtBalanceBeforeTopup}
✍️ توضیحات : {$paymentNote}";
            Editmessagetext($_receipt_chat_id, $message_id, $textconfrom, $Confirm_pay, 'HTML', $_receipt_report_thread > 0 ? $_receipt_report_thread : null);
        }
        $__creditFmt = number_format($__creditAmount, 0);
        sendmessage($Payment_report['id_user'], "💎 کاربر گرامی مبلغ {$__creditFmt} تومان به کیف پول شما واریز گردید با تشکراز پرداخت شما.

🛒 کد پیگیری شما: {$Payment_report['id_order']}", null, 'HTML');
        if (function_exists('faoxima_public_purchase_log_event')) {
            faoxima_public_purchase_log_event('wallet_deposit', [
                'user_id' => $Payment_report['id_user'],
                'amount'  => $__creditFmt,
                'price'   => $__creditFmt,
            ], $setting);
        }
    }
    return rx_pf_result('completed');
}

if (!function_exists('rxReferralRegister')) {
    function rxReferralRegister($inviteeId, $inviterId): string
    {
        global $pdo;
        $inviteeId = trim((string) $inviteeId);
        $inviterId = trim((string) $inviterId);
        if (!($pdo instanceof PDO) || !ctype_digit($inviteeId) || !ctype_digit($inviterId) || $inviteeId === $inviterId) {
            return 'invalid';
        }
        if ($pdo->inTransaction()) {
            return 'failed';
        }
        try {
            $pdo->beginTransaction();
            $exists = $pdo->prepare("SELECT id FROM user WHERE id IN (:a, :b) FOR UPDATE");
            $exists->execute([':a' => $inviteeId, ':b' => $inviterId]);
            if (count($exists->fetchAll(PDO::FETCH_COLUMN)) !== 2) {
                $pdo->rollBack();
                return 'invalid';
            }
            $claim = $pdo->prepare("UPDATE user SET affiliates = :inviter WHERE id = :invitee AND (affiliates IS NULL OR affiliates = 0 OR affiliates = '')");
            $claim->execute([':inviter' => $inviterId, ':invitee' => $inviteeId]);
            if ($claim->rowCount() < 1) {
                $pdo->rollBack();
                return 'already_referred';
            }
            $count = $pdo->prepare("UPDATE user SET affiliatescount = CAST(COALESCE(NULLIF(affiliatescount, ''), '0') AS UNSIGNED) + 1 WHERE id = :inviter");
            $count->execute([':inviter' => $inviterId]);
            $report = $pdo->prepare("INSERT INTO reagent_report (user_id, get_gift, time, reagent) VALUES (:user_id, 0, :time, :reagent)
                                     ON DUPLICATE KEY UPDATE reagent = IF(get_gift = 0, VALUES(reagent), reagent), time = IF(get_gift = 0, VALUES(time), time)");
            $report->execute([':user_id' => $inviteeId, ':time' => date('Y/m/d H:i:s'), ':reagent' => $inviterId]);
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('rxReferralRegister failed for invitee ' . $inviteeId . ': ' . $e->getMessage());
            return 'failed';
        }
        if (function_exists('clearSelectCacheRow')) {
            clearSelectCacheRow('user', 'id', $inviteeId);
            clearSelectCacheRow('user', 'id', $inviterId);
        }
        if (function_exists('clearSelectCache')) {
            clearSelectCache('reagent_report');
        }
        return 'registered';
    }
}

if (!function_exists('rxReferralGiftPayout')) {
    function rxReferralGiftPayout($inviteeId): array
    {
        global $pdo;
        $inviteeId = trim((string) $inviteeId);
        if (!($pdo instanceof PDO) || !ctype_digit($inviteeId)) {
            return ['status' => 'unavailable'];
        }
        if ($pdo->inTransaction()) {
            return ['status' => 'failed', 'reason' => 'nested_transaction'];
        }
        try {
            $gateStmt = $pdo->query("SELECT * FROM affiliates LIMIT 1");
            $gate = $gateStmt ? $gateStmt->fetch(PDO::FETCH_ASSOC) : false;
            if (!is_array($gate) || ($gate['Discount'] ?? '') === 'offDiscountaffiliates') {
                return ['status' => 'disabled'];
            }
            $userStmt = $pdo->prepare("SELECT * FROM user WHERE id = :id LIMIT 1");
            $userStmt->execute([':id' => $inviteeId]);
            $invitee = $userStmt->fetch(PDO::FETCH_ASSOC);
            if (!is_array($invitee)) {
                return ['status' => 'not_referred'];
            }
            $declaredInviter = trim((string) ($invitee['affiliates'] ?? ''));
            if ($declaredInviter === '' || !ctype_digit($declaredInviter) || $declaredInviter === '0' || $declaredInviter === $inviteeId) {
                return ['status' => 'not_referred'];
            }
            $userStmt->execute([':id' => $declaredInviter]);
            if (!is_array($userStmt->fetch(PDO::FETCH_ASSOC))) {
                return ['status' => 'not_referred'];
            }
            $reagentStmt = $pdo->prepare("SELECT * FROM reagent_report WHERE user_id = :id LIMIT 1");
            $reagentStmt->execute([':id' => $inviteeId]);
            $reagent = $reagentStmt->fetch(PDO::FETCH_ASSOC);
            if (!is_array($reagent)) {
                $seed = $pdo->prepare("INSERT IGNORE INTO reagent_report (user_id, get_gift, time, reagent) VALUES (:user_id, 0, :time, :reagent)");
                $seed->execute([':user_id' => $inviteeId, ':time' => date('Y/m/d H:i:s'), ':reagent' => $declaredInviter]);
                if (function_exists('clearSelectCache')) {
                    clearSelectCache('reagent_report');
                }
                $reagentStmt->execute([':id' => $inviteeId]);
                $reagent = $reagentStmt->fetch(PDO::FETCH_ASSOC);
                if (!is_array($reagent)) {
                    return ['status' => 'not_referred'];
                }
            }
            if (!empty($reagent['get_gift'])) {
                return ['status' => 'already'];
            }
            if (($gate['require_phone_verified'] ?? '') === 'on_require_phone' && ($invitee['number'] ?? 'none') !== 'confrim number by admin') {
                return ['status' => 'phone_required'];
            }
            $minAgeHours = (int) ($gate['min_account_age_hours'] ?? 0);
            if ($minAgeHours > 0 && !empty($invitee['register']) && $invitee['register'] !== 'none') {
                if ((time() - (int) $invitee['register']) / 3600 < $minAgeHours) {
                    return ['status' => 'too_new'];
                }
            }
            $amount = intval($gate['price_Discount'] ?? 0) / 2;
            if ($amount <= 0) {
                return ['status' => 'no_amount'];
            }
        } catch (Throwable $e) {
            error_log('rxReferralGiftPayout precheck failed for invitee ' . $inviteeId . ': ' . $e->getMessage());
            return ['status' => 'failed', 'reason' => 'precheck'];
        }

        $dailyCap = (int) ($gate['daily_referral_cap'] ?? 0);
        $monthlyCap = (int) ($gate['monthly_referral_cap'] ?? 0);
        try {
            $pdo->beginTransaction();
            $lockReagent = $pdo->prepare("SELECT get_gift, reagent FROM reagent_report WHERE user_id = :id FOR UPDATE");
            $lockReagent->execute([':id' => $inviteeId]);
            $locked = $lockReagent->fetch(PDO::FETCH_ASSOC);
            if (!is_array($locked)) {
                $pdo->rollBack();
                return ['status' => 'not_referred'];
            }
            if (!empty($locked['get_gift'])) {
                $pdo->rollBack();
                return ['status' => 'already'];
            }
            $inviterId = trim((string) $locked['reagent']);
            if ($inviterId === '' || $inviterId === $inviteeId) {
                $pdo->rollBack();
                return ['status' => 'not_referred'];
            }
            $lockUsers = $pdo->prepare("SELECT id, Balance FROM user WHERE id = :id FOR UPDATE");
            $lockUsers->execute([':id' => $inviterId]);
            $inviterRow = $lockUsers->fetch(PDO::FETCH_ASSOC);
            $lockUsers->execute([':id' => $inviteeId]);
            $inviteeRow = $lockUsers->fetch(PDO::FETCH_ASSOC);
            if (!is_array($inviterRow) || !is_array($inviteeRow)) {
                $pdo->rollBack();
                return ['status' => 'not_referred'];
            }
            if ($dailyCap > 0) {
                $capStmt = $pdo->prepare("SELECT COUNT(*) FROM affiliate_referral_claims WHERE reagent = :reagent AND claim_date = :today");
                $capStmt->execute([':reagent' => $inviterId, ':today' => date('Y-m-d')]);
                if ((int) $capStmt->fetchColumn() >= $dailyCap) {
                    $pdo->rollBack();
                    return ['status' => 'cap_daily'];
                }
            }
            if ($monthlyCap > 0) {
                $capStmt = $pdo->prepare("SELECT COUNT(*) FROM affiliate_referral_claims WHERE reagent = :reagent AND claim_date >= :monthstart");
                $capStmt->execute([':reagent' => $inviterId, ':monthstart' => date('Y-m-01')]);
                if ((int) $capStmt->fetchColumn() >= $monthlyCap) {
                    $pdo->rollBack();
                    return ['status' => 'cap_monthly'];
                }
            }
            $mark = $pdo->prepare("UPDATE reagent_report SET get_gift = 1 WHERE user_id = :id AND get_gift = 0");
            $mark->execute([':id' => $inviteeId]);
            if ($mark->rowCount() !== 1) {
                $pdo->rollBack();
                return ['status' => 'already'];
            }
            $claim = $pdo->prepare("INSERT INTO affiliate_referral_claims (reagent, invitee_id, claim_type, claim_date, time) VALUES (:reagent, :invitee_id, 'start_gift', :claim_date, :time)");
            $claim->execute([
                ':reagent' => $inviterId,
                ':invitee_id' => $inviteeId,
                ':claim_date' => date('Y-m-d'),
                ':time' => date('Y/m/d H:i:s'),
            ]);
            if (!function_exists('balance_atomic_credit') || !function_exists('wallet_ledger_record')) {
                throw new RuntimeException('wallet helpers unavailable');
            }
            if (!balance_atomic_credit($inviterId, $amount)) {
                throw new RuntimeException('inviter credit failed');
            }
            if (!wallet_ledger_record($inviterId, 'credit', $amount, 'referral_gift', 'هدیه عضویت زیرمجموعه', null, 'user', $inviteeId)) {
                throw new RuntimeException('inviter ledger failed');
            }
            if (!balance_atomic_credit($inviteeId, $amount)) {
                throw new RuntimeException('invitee credit failed');
            }
            if (!wallet_ledger_record($inviteeId, 'credit', $amount, 'referral_gift', 'هدیه عضویت', null, 'user', $inviterId)) {
                throw new RuntimeException('invitee ledger failed');
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if (function_exists('clearSelectCacheRow')) {
                clearSelectCacheRow('user', 'id', $inviteeId);
                if (isset($inviterId)) {
                    clearSelectCacheRow('user', 'id', $inviterId);
                }
            }
            if ($e instanceof PDOException && (string) $e->getCode() === '23000') {
                return ['status' => 'already'];
            }
            error_log('rxReferralGiftPayout failed for invitee ' . $inviteeId . ': ' . $e->getMessage());
            return ['status' => 'failed', 'reason' => 'transaction'];
        }
        if (function_exists('clearSelectCacheRow')) {
            clearSelectCacheRow('user', 'id', $inviteeId);
            clearSelectCacheRow('user', 'id', $inviterId);
        }
        if (function_exists('clearSelectCache')) {
            clearSelectCache('reagent_report');
        }
        return [
            'status' => 'paid',
            'invitee' => $inviteeId,
            'inviter' => $inviterId,
            'amount' => $amount,
            'invitee_balance_before' => (float) $inviteeRow['Balance'],
            'invitee_balance_after' => (float) $inviteeRow['Balance'] + $amount,
            'inviter_balance_before' => (float) $inviterRow['Balance'],
            'inviter_balance_after' => (float) $inviterRow['Balance'] + $amount,
            'invitee_username' => (string) ($invitee['username'] ?? ''),
        ];
    }
}

if (!function_exists('rxReferralGiftNotify')) {
    function rxReferralGiftNotify(array $result): void
    {
        if (($result['status'] ?? '') !== 'paid') {
            return;
        }
        $texts = isset($GLOBALS['datatextbot']) && is_array($GLOBALS['datatextbot']) ? $GLOBALS['datatextbot'] : [];
        $inviteeId = (string) $result['invitee'];
        $inviterId = (string) $result['inviter'];
        if (function_exists('sendmessage')) {
            try {
                sendmessage($inviterId, $texts['dyn_affiliates_extra_gift_credited_inviter'] ?? "🎉 یک نفر با معرفی شما وارد شد! هدیه به حساب شما واریز شد.", null, 'html');
            } catch (Throwable $e) {
                error_log('rxReferralGiftNotify inviter message failed: ' . $e->getMessage());
            }
            try {
                sendmessage($inviteeId, $texts['dyn_affiliates_extra_gift_activated'] ?? "🎉 هدیه عضویت برای شما فعال شد!", null, 'html');
            } catch (Throwable $e) {
                error_log('rxReferralGiftNotify invitee message failed: ' . $e->getMessage());
            }
        }
        if (!function_exists('telegram')) {
            return;
        }
        $setting = isset($GLOBALS['setting']) && is_array($GLOBALS['setting']) ? $GLOBALS['setting'] : null;
        if ($setting === null && function_exists('select')) {
            try {
                $setting = select("setting", "*", null, null, "select");
            } catch (Throwable $e) {
                $setting = null;
            }
        }
        $channel = is_array($setting) ? (string) ($setting['Channel_Report'] ?? '') : '';
        if ($channel === '') {
            return;
        }
        $fmt = function ($value) {
            return function_exists('rxFormatToman') ? rxFormatToman($value) : number_format((float) $value, 0);
        };
        $username = htmlspecialchars((string) ($result['invitee_username'] ?? ''), ENT_QUOTES, 'UTF-8');
        $report = "🎁 پرداخت هدیه عضویت
<blockquote> -آیدی عددی : {$inviteeId}</blockquote>
<blockquote> - نام کاربری : @{$username}</blockquote>
<blockquote> - آیدی عددی معرف : {$inviterId}</blockquote>
<blockquote> - موجودی زیرمجموعه قبل از هدیه : {$fmt($result['invitee_balance_before'])}</blockquote>
<blockquote> - موجودی زیرمجموعه بعد از هدیه : {$fmt($result['invitee_balance_after'])}</blockquote>
<blockquote>  - موجودی معرف قبل از هدیه : {$fmt($result['inviter_balance_before'])}</blockquote>
<blockquote> - موجودی معرف بعد از هدیه : {$fmt($result['inviter_balance_after'])}</blockquote>
 ";
        try {
            telegram('sendmessage', [
                'chat_id' => $channel,
                'message_thread_id' => $GLOBALS['porsantreport'] ?? null,
                'text' => $report,
                'parse_mode' => "HTML"
            ]);
        } catch (Throwable $e) {
            error_log('rxReferralGiftNotify report failed: ' . $e->getMessage());
        }
    }
}
