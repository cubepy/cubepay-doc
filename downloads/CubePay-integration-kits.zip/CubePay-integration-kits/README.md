# بسته‌های اتصال CubePay

[راهنمای شروع فارسی](https://github.com/cubepy/cubepay-doc/blob/main/docs/INTEGRATION-KITS.md) · [English quick start](https://github.com/cubepy/cubepay-doc/blob/main/en/docs/INTEGRATION-KITS.md)

| زبان | فایل‌ها و شروع کار |
|---|---|
| PHP | [PHP 8.1+](https://github.com/cubepy/cubepay-doc/blob/main/integrations/kits/php/README.md) |
| Python | [Python 3.10+](https://github.com/cubepy/cubepay-doc/blob/main/integrations/kits/python/README.md) |
| Node.js | [Node.js 22.13+](https://github.com/cubepy/cubepay-doc/blob/main/integrations/kits/node/README.md) |

[دانلود ZIP هر سه بسته](https://github.com/cubepy/cubepay-doc/raw/refs/heads/main/downloads/CubePay-integration-kits.zip) · [راهنمای فنی فارسی و قرارداد تحویل](https://github.com/cubepy/cubepay-doc/blob/main/integrations/kits/README-fa.md)

فقط درگاه کارت‌به‌کارت عادی؛ نصب روی سرور فروشگاه یا ربات. این بسته‌ها افزونهٔ نصب‌شدنی داخل ربات تلگرام یا اپ گوشی نیستند. اتصال منطق تحویل سفارش به برنامهٔ شما لازم است.
